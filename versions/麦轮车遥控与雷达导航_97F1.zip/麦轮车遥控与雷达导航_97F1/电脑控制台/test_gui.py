"""Own-widget tests only: simulated data, no COM enumeration or real serial."""
import time,types,tkinter as tk,unittest
from controller import App

class GuiTests(unittest.TestCase):
 def setUp(self):
  self.root=tk.Tk();self.root.withdraw();self.app=App(self.root,demo=True,enumerate_ports=False);self.root.update_idletasks()
 def tearDown(self):
  self.assertIsNone(self.app.link.thread);self.root.destroy()
 def click_at(self,x,y):
  c=self.app.worlds[-1];self.app.draw_world(c);ox,oy,scale,*_=c._world_transform
  self.app.map_click(c,types.SimpleNamespace(x=ox+x*scale,y=oy-y*scale))
 def test_click_selects_without_autostart(self):
  self.click_at(100,110);self.assertEqual(self.app.goal_y.get(),'110');self.assertFalse(self.app.task['active'])
 def test_armed_click_starts_goal(self):
  self.app.click_go.set(True);self.click_at(100,110)
  self.assertTrue(self.app.task['active']);self.assertEqual(self.app.task['goal_y_cm'],110)
 def test_invalid_position_does_not_start(self):
  self.app.click_go.set(True);self.click_at(5,110);self.assertFalse(self.app.task['active'])
  self.app.task['pose']=False;self.click_at(100,110);self.assertFalse(self.app.task['active'])
 def test_manual_accepts_only_manual_running(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic()
  self.assertTrue(a.available('manual'));a.task['active']=True;self.assertFalse(a.available('manual'))
  a.task['manual']=True;self.assertTrue(a.available('manual'))
 def test_focus_loss_disarms(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic();a.current='radar';a.manual_armed.set(True)
  a.held_input=types.SimpleNamespace(foreground=lambda:False,mask=lambda:1);a.link.set_drive(1);a.poll_drive()
  self.assertFalse(a.manual_armed.get());self.assertEqual(a.link.drive_state[0],0)
 def test_manual_without_any_field_or_pose(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic()
  a.task.update(calibrated=False,pose=False,can_go=False,width_cm=0,height_cm=0,near=True,radar=False)
  self.assertTrue(a.available('manual'))
  a.render();self.assertEqual(a.variable('radar_state').get(),'有效扫描')
  a.show('radar');a.draw_world(a.radar_canvas)
  self.assertFalse(a.task['active']);self.assertIsNone(a.link.thread)

if __name__=='__main__':unittest.main(verbosity=2)
