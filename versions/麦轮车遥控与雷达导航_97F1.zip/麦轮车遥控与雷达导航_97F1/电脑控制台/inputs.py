"""Read held keys/side buttons only while this console owns foreground focus."""
import sys

class HeldInput:
 def __init__(self,root):
  self.root=root;self.keys=set();self.user32=None
  if sys.platform=='win32':
   import ctypes
   from ctypes import wintypes
   self.user32=ctypes.WinDLL('user32',use_last_error=True)
   self.user32.GetForegroundWindow.restype=wintypes.HWND
   self.user32.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];self.user32.GetAncestor.restype=wintypes.HWND
   self.user32.GetAsyncKeyState.argtypes=[ctypes.c_int];self.user32.GetAsyncKeyState.restype=ctypes.c_short
  else:
   root.bind('<KeyPress>',lambda e:self.keys.add(e.keysym.lower()),add='+')
   root.bind('<KeyRelease>',lambda e:self.keys.discard(e.keysym.lower()),add='+')
 def foreground(self):
  if self.user32:
   hwnd=self.user32.GetAncestor(self.root.winfo_id(),2)
   return hwnd==self.user32.GetForegroundWindow()
  return self.root.focus_displayof() is not None
 def mask(self):
  if not self.foreground():return 0
  focus=self.root.focus_get()
  if focus is not None and focus.winfo_class() in ('Entry','TEntry','TSpinbox','Text','TCombobox'):return 0
  if self.user32:
   codes=[ord('W'),ord('S'),ord('A'),ord('D'),6,5]
   return sum(1<<i for i,key in enumerate(codes) if self.user32.GetAsyncKeyState(key)&0x8000)
  return sum(1<<i for i,key in enumerate(['w','s','a','d','e','q']) if key in self.keys)
