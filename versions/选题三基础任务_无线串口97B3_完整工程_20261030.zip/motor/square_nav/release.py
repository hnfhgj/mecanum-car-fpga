"""Offline release guard/package. Never opens a port or programs hardware."""
from pathlib import Path
import argparse, hashlib, json, re, shutil, zipfile, stat
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PROJECT=ROOT/'square_navigation.gprj'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()

def copy_artifact(source,destination,immutable=False):
    if destination.exists():
        if sha(source)==sha(destination):return
        assert not immutable,'Immutable artifact changed: '+str(destination)
        destination.chmod(destination.stat().st_mode | stat.S_IWRITE)
    shutil.copy2(source,destination)

def tree():
    return ET.fromstring(PROJECT.read_text(encoding='utf-8-sig').replace('version="1"','version="1.0"'))

def inputs():
    paths=[]
    for ref in tree().findall('.//FileList/File'):
        if ref.get('enable')!='1':continue
        p=Path(ref.get('path'))
        paths.append(p if p.is_absolute() else ROOT/p)
    paths += [ROOT/'src/imu660ra_config.hex',ROOT/'src/dl1b_config.hex']
    return {str(p.resolve().relative_to(ROOT)).replace('\\','/'):sha(p) for p in paths}

def publish():
    current=inputs()
    assert current==json.loads((HERE/'inputs.json').read_text()),'Source/constraint/ROM changed since snapshot'
    pnr=ROOT/'impl/pnr'; base='square_navigation'
    fs=pnr/(base+'.fs'); report=(pnr/(base+'.rpt.txt')).read_text(encoding='utf-8-sig')
    timing=(pnr/(base+'_tr_content.html')).read_text(encoding='utf-8-sig')
    for kind in ('Setup','Hold'):
        m=re.search(r'Numbers of '+kind+r' Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>',timing)
        assert m and m[1]=='0',kind+' violations'
    assert 'PASS: square_navigation setup/hold violations zero' in (HERE/'build_final.log').read_text(encoding='utf-8-sig')
    expected=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;', (ROOT/'n10_build/lidar_board.cst').read_text(encoding='utf-8-sig')))
    assert len(expected)==len(set(expected.values()))==53
    fitted={}
    for line in report.splitlines():
        c=[s.strip() for s in line.split('|')]
        if len(c)>4 and c[0] in expected:
            assert c[3]=='Y','Auto-assigned pin'
            fitted[c[0]]=c[2].split('/')[0]
    assert fitted==expected,'Pin report mismatch'
    with fs.open() as f: header=''.join(next(f) for _ in range(18))
    assert '//Device-package: GW5AT-60B-PBGA484A' in header
    code=re.search(r'//UserCode:\s+0x([0-9A-Fa-f]+)',header)[1]
    assert all((ROOT/p).stat().st_mtime<=fs.stat().st_mtime for p in current),'Bitstream older than input'
    checks={
        'project_test_console.log':['PASS: square world projection 121'],
        'frame_test_console.log':['PASS: square frame RTL'],
        'map_test_console.log':['PASS: square map 8192'],
        'route_test_console.log':['PASS: square BFS'],
        'control_ui_test_console.log':['PASS: square drive','PASS: square UI'],
        'detour_test_console.log':['PASS: square map + BFS closed loop detour'],
        'renderer_test_console.log':['PASS square menu renderer'],
        'top_test_console.log':['PASS square navigation top elaborates'],
        'integration_test_console.log':['PASS: full frame + retained synchronous scan + map + BFS integration'],
        'cadence_test_console.log':['PASS: 10Hz scan cadence localization/map/planner/drive freshness'],
    }
    for log,markers in checks.items():
        text=(HERE/log).read_text(encoding='utf-8-sig')
        assert all(m in text for m in markers),log+' missing PASS'
        assert not re.search(r'\*\* (?:Fatal|Error)',text),log+' simulation failed'
        assert 'Errors: 0, Warnings: 0' in text,log+' unclean simulation'
    old=ROOT/'pillar_nav/release/navigation_4E72.fs'
    assert sha(old)=='DA107B04D7DCD069398D75146DD43F6A51EF86ACBBEC076F80D0C9DE8F7FD422'
    out=HERE/'release';out.mkdir(exist_ok=True)
    name='square_'+code[-4:]+'.fs'
    copy_artifact(fs,out/name,immutable=True)
    backup=out/'previous_flash_4E72.fs'
    if backup.exists():assert sha(backup)==sha(old),'Previous Flash backup changed'
    else:shutil.copy2(old,backup)
    copy_artifact(pnr/(base+'.rpt.txt'),out/'pnr.txt')
    copy_artifact(pnr/(base+'_tr_content.html'),out/'timing.html')
    resources={}
    for label in ('Logic','Register','BSRAM','DSP'):
        m=re.search(r'^\s*'+label+r'\s+\|.*$',report,re.M)
        if m:resources[label]=m[0].strip()
    manifest=dict(firmware=name,userCode='0x'+code,sha256=sha(out/name),ports=53,
                  setup=0,hold=0,resources=resources,hardwareProgrammed=False,
                  vehicle_mm=dict(front=150,rear=150,left=80,right=80,circumradius=170,
                                  margin=100,clearance=270),
                  hardwareMotionTested=False,verifiedUTC=datetime.now(timezone.utc).isoformat(),
                  previousFlash='previous_flash_4E72.fs',previousSHA256=sha(old),inputs=current,
                  assumptions='See square_nav/设计与验证状态.md; chassis dimensions supplied by user; mounting and physical navigation unverified')
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k!='inputs'},ensure_ascii=False,indent=2))

def package():
    out=HERE/'release';assert (out/'manifest.json').exists(),'No approved release'
    manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
    assert inputs()==manifest['inputs'],'Sources changed after publication'
    archive=ROOT.parent/'方框定位避障_工程_20261029.zip'
    paths={ROOT/p for p in inputs()}
    paths.update(p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.v','.do','.tcl','.json','.md','.txt','.png','.log','.hex','.ps1'))
    paths.update(p for p in out.iterdir() if p.is_file())
    # Build verification and the optional generator use these non-project files.
    paths.update(ROOT/p for p in ('pillar_nav/timing_check.tcl',
        'pillar_nav/pillar_nav_top.v','pillar_nav/nav_renderer.v','pillar_nav/tests/renderer_tb.v'))
    old_xml=ET.fromstring((ROOT/'pillar_navigation.gprj').read_text(encoding='utf-8-sig').replace('version="1"','version="1.0"'))
    for ref in old_xml.findall('.//FileList/File'):
        p=Path(ref.get('path'));p=p if p.is_absolute() else ROOT/p
        paths.add(p)
        ref.set('path',p.resolve().relative_to(ROOT).as_posix())
    xml=tree()
    for ref in xml.findall('.//FileList/File'):
        p=Path(ref.get('path'));p=p if p.is_absolute() else ROOT/p
        ref.set('path',p.resolve().relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,'motor/'+p.resolve().relative_to(ROOT).as_posix())
        z.writestr('motor/square_navigation.gprj',ET.tostring(xml,encoding='utf-8',xml_declaration=True))
        z.writestr('motor/pillar_navigation.gprj',ET.tostring(old_xml,encoding='utf-8',xml_declaration=True))
        z.write(ROOT.parent/'方框定位避障_操作说明.md','方框定位避障_操作说明.md')
        audit=ROOT.parent/'选题三_基础任务差距与验收清单.md'
        if audit.exists():z.write(audit,audit.name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert hashlib.sha256(z.read('motor/square_nav/release/'+manifest['firmware'])).hexdigest().upper()==manifest['sha256']
        for path,digest in manifest['inputs'].items():
            assert hashlib.sha256(z.read('motor/'+path)).hexdigest().upper()==digest,path
        for ref in xml.findall('.//FileList/File'):
            assert 'motor/'+ref.get('path') in z.namelist(),ref.get('path')
        for ref in old_xml.findall('.//FileList/File'):
            assert 'motor/'+ref.get('path') in z.namelist(),ref.get('path')
    print('Portable project archive:',archive,'SHA256:',sha(archive))
    print('PASS archive source/firmware hashes, both project references, CRC; bytes:',archive.stat().st_size)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--snapshot',action='store_true')
    parser.add_argument('--publish',action='store_true');parser.add_argument('--package',action='store_true');args=parser.parse_args()
    if args.snapshot:
        (HERE/'inputs.json').write_text(json.dumps(inputs(),indent=2),encoding='utf-8');print('Saved source/constraint/ROM hashes')
    if args.publish:publish()
    if args.package:package()
