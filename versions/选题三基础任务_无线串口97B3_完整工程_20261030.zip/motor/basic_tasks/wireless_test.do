onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/wireless_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/uart_tx.v src/uart_rx.v src/speed_pid.v src/wheel_speed_loop.v basic_tasks/basic_wheel_speed_loop.v basic_tasks/wireless_uart_bridge.v basic_tasks/wireless_test.v
foreach test {wireless_uart_tb feedback_disabled_tb} {
 vsim -onfinish stop -voptargs=+acc -lib $lib $test
 run -all
 if {[examine -radix unsigned /$test/passed] != 1} {quit -code 1 -f}
 quit -sim
}
quit -code 0 -f
