"""Offline build/release/package guard. Never opens hardware or starts motion."""
from pathlib import Path
import importlib.util,json,re,hashlib,zipfile,argparse,xml.etree.ElementTree as ET
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
spec=importlib.util.spec_from_file_location('square_release',ROOT/'square_nav/release.py')
shared=importlib.util.module_from_spec(spec);spec.loader.exec_module(shared)
shared.HERE=HERE;shared.PROJECT=ROOT/'basic_tasks.gprj'
inputs=shared.inputs;sha=shared.sha;copy_artifact=shared.copy_artifact

def publish():
    current=inputs()
    assert current==json.loads((HERE/'inputs.json').read_text(encoding='utf-8')),'Inputs changed during build'
    pnr=ROOT/'impl/pnr';name='basic_tasks'
    report=(pnr/(name+'.rpt.txt')).read_text(encoding='utf-8-sig')
    timing=(pnr/(name+'_tr_content.html')).read_text(encoding='utf-8-sig')
    for kind in ('Setup','Hold'):
        match=re.search(r'Numbers of '+kind+r' Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>',timing)
        assert match and match[1]=='0',kind+' timing violations'
    assert 'PASS: basic_tasks setup/hold violations zero' in (HERE/'build_final.log').read_text(encoding='utf-8-sig')
    expected=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;', (HERE/'wireless_board.cst').read_text(encoding='utf-8-sig')))
    baseline=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;', (ROOT/'n10_build/lidar_board.cst').read_text(encoding='utf-8-sig')))
    assert len(baseline)==53 and all(expected.get(p)==v for p,v in baseline.items())
    assert {p:v for p,v in expected.items() if p not in baseline}==dict(wireless_tx='F18',wireless_rx='E18',wireless_rts='F19')
    fitted={}
    for line in report.splitlines():
        fields=[f.strip() for f in line.split('|')]
        if len(fields)>4 and fields[0] in expected:
            assert fields[3]=='Y','Unconstrained IO'
            fitted[fields[0]]=fields[2].split('/')[0]
    assert len(expected)==len(set(expected.values()))==56 and fitted==expected,'Physical pin mismatch'
    checks={
        'unit_test_console.log':['PASS basic directional clearance','PASS basic six movements','PASS basic ordered four waypoints'],
        'control_test_console.log':['PASS basic task menu real buttons','PASS basic nav distance-dependent speed'],
        'top_test_console.log':['PASS basic tasks top elaboration'],
        'renderer_test_console.log':['PASS basic task menu renderer'],
        'integration_test_console.log':['PASS basic four-point map/planner/clearance/nav integration'],
        'wireless_test_console.log':['PASS wireless UART:', 'PASS feedback lock removed:'],
        'wireless_stream_test_console.log':['PASS wired/wireless 400 real telemetry bytes match'],
    }
    for file,markers in checks.items():
        log=(HERE/file).read_text(encoding='utf-8-sig')
        assert all(s in log for s in markers),file+' missing PASS'
        assert not re.search(r'\*\* (?:Fatal|Error)',log),file+' failed'
        assert 'Errors: 0, Warnings: 0' in log,file+' warnings/errors'
    previous=ROOT/'square_nav/release/manifest.json'
    old_manifest=json.loads(previous.read_text(encoding='utf-8'))
    assert old_manifest['userCode']=='0x0000E1CC'
    assert all((current.get(p)==h if p!='n10_build/lidar_board.cst' else sha(ROOT/p)==h) for p,h in old_manifest['inputs'].items()),'Released shared RTL changed'
    old=ROOT/'pillar_nav/release/navigation_4E72.fs'
    assert sha(old)=='DA107B04D7DCD069398D75146DD43F6A51EF86ACBBEC076F80D0C9DE8F7FD422'
    e1cc=ROOT/'square_nav/release/square_E1CC.fs'
    assert sha(e1cc)=='309CAE815CBFBC0493933A3EAF9DB7B703A186BAAA3F7B57C9BA667975B1062F'
    fs=pnr/(name+'.fs')
    with fs.open(encoding='ascii') as handle:header=''.join(next(handle) for _ in range(18))
    assert '//Device-package: GW5AT-60B-PBGA484A' in header
    code=re.search(r'//UserCode:\s+0x([0-9A-Fa-f]+)',header)[1].upper()
    assert code.upper()=='000097B3','Unexpected candidate UserCode'
    assert all((ROOT/p).stat().st_mtime<=fs.stat().st_mtime for p in current),'Stale bitstream'
    out=HERE/'release';out.mkdir(exist_ok=True)
    current_flash=out/'basic_97A2.fs'
    assert sha(current_flash)=='8B21622C23AC5E3EA6340A3361F84E00A16A5BB85E5409088F5A51BE85E4D27A'
    copy_artifact(current_flash,out/'previous_flash_97A2.fs',immutable=True)
    filename='basic_'+code[-4:]+'.fs'
    copy_artifact(fs,out/filename,immutable=True)
    copy_artifact(old,out/'previous_flash_4E72.fs',immutable=True)
    copy_artifact(e1cc,out/'previous_candidate_E1CC.fs',immutable=True)
    copy_artifact(previous,out/'previous_candidate_E1CC.json')
    copy_artifact(pnr/(name+'.rpt.txt'),out/'pnr.txt')
    copy_artifact(pnr/(name+'_tr_content.html'),out/'timing.html')
    resources={}
    for label in ('Logic','Register','BSRAM','DSP'):
        match=re.search(r'^\s*'+label+r'\s+\|.*$',report,re.M)
        if match:resources[label]=match[0].strip()
    manifest=dict(firmware=filename,userCode='0x'+code,sha256=sha(fs),inputs=current,ports=56,
                  setup=0,hold=0,resources=resources,hardwareProgrammed=False,hardwareMotionTested=False,
                  previousFlash='0x000097A2',wirelessBaud=115200,
                  wirelessPins=dict(tx='P7-37/F18',rx='P7-38/E18',rts='P7-39/F19'),encoderFeedbackGuard=False,
                  vehicle_mm=dict(front=150,rear=150,left=80,right=80,circumradius=170,margin=100,clearance=270),
                  slowdown=dict(distance_mm=[700,550,400,270],speed_counts_per_10ms=[60,45,30,15,0]),
                  waypointCount=4,verifiedUTC=datetime.now(timezone.utc).isoformat())
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k!='inputs'},ensure_ascii=False,indent=2))

def package():
    out=HERE/'release';manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
    assert inputs()==manifest['inputs'],'Source changed after release'
    paths={ROOT/p for p in inputs()}
    paths.update(p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.v','.py','.do','.tcl','.txt','.json','.log','.png','.hex','.md','.ps1'))
    paths.update(p for p in out.iterdir() if p.is_file())
    paths.update(ROOT/p for p in ('pillar_nav/timing_check.tcl','square_nav/release.py'))
    projects=[]
    for file in ('basic_tasks.gprj','square_navigation.gprj'):
        tree=ET.fromstring((ROOT/file).read_text(encoding='utf-8-sig').replace('version="1"','version="1.0"'))
        for ref in tree.findall('.//FileList/File'):
            p=Path(ref.get('path'));p=p if p.is_absolute() else ROOT/p
            ref.set('path',p.resolve().relative_to(ROOT).as_posix());paths.add(p)
        projects.append((file,tree))
    archive=ROOT.parent/'选题三基础任务_无线串口97B3_完整工程_20261030.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,'motor/'+p.resolve().relative_to(ROOT).as_posix())
        for name,tree in projects:z.writestr('motor/'+name,ET.tostring(tree,encoding='utf-8',xml_declaration=True))
        for doc in ('基础任务菜单_操作说明.md','选题三_基础任务差距与验收清单.md','逐飞无线串口V2.4接线与使用_97B3.md'):
            z.write(ROOT.parent/doc,doc)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert hashlib.sha256(z.read('motor/basic_tasks/release/'+manifest['firmware'])).hexdigest().upper()==manifest['sha256']
        for p,h in manifest['inputs'].items():assert hashlib.sha256(z.read('motor/'+p)).hexdigest().upper()==h,p
        for _,tree in projects:
            for ref in tree.findall('.//FileList/File'):assert 'motor/'+ref.get('path') in z.namelist()
    print('PASS portable basic-task archive, source/firmware hashes and CRC:',archive,'bytes:',archive.stat().st_size)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for flag in ('snapshot','publish','package'):parser.add_argument('--'+flag,action='store_true')
    args=parser.parse_args()
    if args.snapshot:(HERE/'inputs.json').write_text(json.dumps(inputs(),indent=2),encoding='utf-8');print('Saved build input hashes')
    if args.publish:publish()
    if args.package:package()
