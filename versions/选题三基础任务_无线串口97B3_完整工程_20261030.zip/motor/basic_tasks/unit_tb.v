`timescale 1ns/1ps
module basic_clearance_tb;
 reg clk=0,rst=0,bad=0,pv=0;reg signed [15:0] f=0,l=0;reg [15:0] a=0,r=0;
 wire fresh,nearby,update;wire [15:0] fm,bm,lm,rm;wire [6:0] fl,bl,ll,rl;
 integer passed=0,i,j,front=1000,back=1000,side_l=1000,side_r=1000;
 real theta,df,dl,d,t;
 always #10 clk=~clk;
 basic_clearance #(.CLK_HZ(10000)) dut(clk,rst,bad,pv,f,l,a,r,fresh,nearby,update,fm,bm,lm,rm,fl,bl,ll,rl);
 task scan;begin
  for(i=0;i<450;i=i+1)begin
   theta=i*0.8*3.141592653589793/180;df=$cos(theta);dl=-$sin(theta);d=10000;
   if(df>0.00001)begin t=front/df;if(t<d)d=t;end
   if(df< -0.00001)begin t=-back/df;if(t<d)d=t;end
   if(dl>0.00001)begin t=side_l/dl;if(t<d)d=t;end
   if(dl< -0.00001)begin t=-side_r/dl;if(t<d)d=t;end
   @(negedge clk);pv=1;a=i*80;r=$rtoi(d);f=$rtoi(d*df);l=$rtoi(d*dl);
   @(negedge clk);pv=0;
  end
 end endtask
 task sample(input integer distance,expected);begin
  front=distance;repeat(3)scan();
  if(!fresh || fl!=expected || bl!=60 || (distance>270 && (ll!=60 || rl!=60)))
   $fatal(1,"Directional clearance mismatch d=%d lim=%d %d %d %d",distance,fl,bl,ll,rl);
 end endtask
 initial begin
  #51;rst=1;sample(900,60);sample(620,45);sample(480,30);sample(350,15);sample(250,0);
  if(!nearby)$fatal(1,"Near obstacle did not stop");
  front=1000;back=350;repeat(3)scan();if(fl!=60 || bl!=15)$fatal(1,"Rear sector not independent");
  back=1000;side_l=480;side_r=620;repeat(3)scan();if(ll!=30 || rl!=45)$fatal(1,"Lateral sectors failed");
  repeat(2600)@(negedge clk);if(fresh || fl || bl || ll || rl)$fatal(1,"Stale scan accepted");
  bad=1;@(negedge clk);bad=0;if(fresh)$fatal(1,"Bad stream accepted");
  passed=1;$display("PASS basic directional clearance 60/45/30/15/0, front/rear/sides/near/stale/bad");$finish;
 end
endmodule

module basic_demo_tb;
 reg clk=0,rst=0,tick=1,start=0,stop=0,slow=0,imu=1,ready=1,fault=0,rangeok=1,nearby=0;
 reg [2:0] kind=0;reg [6:0] fl=60,bl=60;reg signed [15:0] yaw=0,turn=0;
 wire run,en;wire signed [15:0] target,lf,rf,lb,rb;wire [3:0] status;wire slowed,stopped;
 integer passed=0,n;
 always #10 clk=~clk;
 basic_demo #(.MOVE_TICKS(30),.SLOW_TICKS(60),.SPIN_TICKS(80),.ARM_TICKS(20)) dut(
  clk,rst,tick,start,stop,kind,slow,imu,ready,fault,rangeok,nearby,fl,bl,yaw,turn,run,en,target,lf,rf,lb,rb,status,slowed,stopped);
 task launch(input integer k);begin
  kind=k;@(negedge clk);start=1;@(negedge clk);start=0;repeat(4)@(negedge clk);
 end endtask
 task halt;begin stop=1;@(negedge clk);stop=0;repeat(3)@(negedge clk);if(run || lf || rf || lb || rb)$fatal(1,"Stop failed");end endtask
 initial begin
  #51;rst=1;repeat(3)@(negedge clk);if(run || lf || rf)$fatal(1,"Boot motion");
  launch(0);if(lf!=60 || rf!=60 || lb!=60 || rb!=60)$fatal(1,"Forward");halt();
  launch(1);if(lf!=-60 || rf!=-60)$fatal(1,"Reverse");halt();
  turn=20;launch(2);if(target!=1500 || lf!=10 || rf!=50 || lb!=10 || rb!=50)$fatal(1,"Moving left");halt();
  turn=-20;launch(3);if(target!=-1500 || lf!=50 || rf!=10)$fatal(1,"Moving right");halt();
  turn=20;launch(4);if(target!=3000 || lf!=-20 || rf!=20)$fatal(1,"Spin left");yaw=3000;
  repeat(23)@(negedge clk);if(run || status!=5)$fatal(1,"Spin completion");yaw=0;turn=-20;
  launch(5);if(target!=-3000 || lf!=20 || rf!=-20)$fatal(1,"Spin right");halt();
  turn=0;slow=1;launch(0);
  fl=45;repeat(3)@(negedge clk);if(lf!=45 || !slowed)$fatal(1,"First slowdown");
  fl=30;repeat(3)@(negedge clk);if(lf!=30)$fatal(1,"Second slowdown");
  fl=15;repeat(3)@(negedge clk);if(lf!=15)$fatal(1,"Third slowdown");
  fl=0;repeat(3)@(negedge clk);if(run || lf || !stopped || status!=8)$fatal(1,"Obstacle stop");
  rangeok=0;fl=60;launch(0);if(run || status!=2)$fatal(1,"Blind approach started");
  rangeok=1;slow=0;ready=0;launch(0);repeat(22)@(negedge clk);if(run || status!=6)$fatal(1,"Arming timeout");
  ready=1;launch(0);repeat(32)@(negedge clk);if(run || status!=5)$fatal(1,"Timed movement did not finish");
  launch(0);fault=1;repeat(3)@(negedge clk);if(run || lf || rf)$fatal(1,"Wheel fault not stopped");
  passed=1;$display("PASS basic six movements, heading targets, approach slowdown/stop, reject, timeout, cancel/fault");$finish;
 end
endmodule

module basic_mission_tb;
 reg clk=0,rst=0,single=0,route=0,stop=0,can=1,navrun=0;reg [3:0] ns=0;
 wire run,go,change;wire [15:0] x,y;wire [1:0] idx;wire mode;wire [3:0] status;
 integer passed=0,n,cycles,go_count=0;
 always #10 clk=~clk;
 always @(posedge clk)if(go)go_count=go_count+1;
 basic_mission #(.CLK_HZ(20)) dut(clk,rst,single,route,stop,16'd900,16'd1200,
  {16'd500,16'd1500,16'd1500,16'd500},{16'd1500,16'd1500,16'd500,16'd500},
  can,navrun,ns,run,go,change,x,y,idx,mode,status);
 task next_go;begin cycles=0;while(!go && cycles<30)begin @(negedge clk);cycles=cycles+1;end
  if(!go)$fatal(1,"No launch");navrun=1;ns=4;@(negedge clk);end endtask
 task arrive;begin repeat(3)@(negedge clk);navrun=0;ns=5;@(negedge clk);end endtask
 initial begin
  #51;rst=1;@(negedge clk);route=1;@(negedge clk);route=0;
  for(n=0;n<4;n=n+1)begin
   next_go();if(idx!=n)$fatal(1,"Point order");
   if(x!=(n==0 || n==3?500:1500) || y!=(n<2?500:1500))$fatal(1,"Wrong waypoint");
   arrive();
  end
  repeat(4)@(negedge clk);if(run || status!=5 || go_count!=4)$fatal(1,"Route completion");
  single=1;@(negedge clk);single=0;next_go();if(mode || x!=900 || y!=1200)$fatal(1,"Single target");
  stop=1;@(negedge clk);stop=0;repeat(2)@(negedge clk);if(run || status!=7)$fatal(1,"Mission cancel");
  navrun=0;can=0;single=1;@(negedge clk);single=0;repeat(110)@(negedge clk);if(run || status!=6)$fatal(1,"Readiness timeout");
  passed=1;$display("PASS basic ordered four waypoints, distinct target registers, single/cancel/readiness timeout");$finish;
 end
endmodule
