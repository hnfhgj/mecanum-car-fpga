"""Isolated basic-task project. Does not edit released square-nav sources."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
s=(root/'square_nav/square_nav_top.v').read_text(encoding='utf-8-sig')
def replace(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a))
    s=s.replace(a,b)
replace('module square_nav_top #(', 'module basic_tasks_top #(')
replace(' wire active,fresh,can_go;wire [3:0] nav_status;', ''' wire active,fresh,can_go;wire [3:0] nav_status;
 wire [2:0] group_id,motion_selection;wire slow_test,demo_start,single_start,route_start;
 wire [15:0] user_x,user_y;wire [63:0] points_x,points_y;wire [1:0] edit_index,point_index;
 wire mission_running,nav_active,nav_go,goal_change,route_mode,demo_running;
 wire [3:0] mission_status,demo_status;wire demo_heading_enable,slow_seen,stop_seen;
 wire signed [15:0] nav_targets[0:3],demo_targets[0:3];
 wire signed [15:0] demo_yaw,demo_turn,demo_target,demo_left,demo_right;
 wire demo_heading_ready,demo_heading_fault;
 wire range_fresh,range_near,range_update;
 wire [15:0] front_mm,back_mm,left_mm,right_mm;
 wire [6:0] front_limit,back_limit,left_limit,right_limit;
 reg [31:0] imu_age;
 wire imu_fresh=imu_age<12500000;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)imu_age<=32'hffffffff;
  else if(attitude_valid)imu_age<=0;
  else if(imu_age!=32'hffffffff)imu_age<=imu_age+1'b1;
 end
 assign active=demo_running || mission_running || nav_active;
 assign targets[0]=demo_running?demo_targets[0]:(mission_running?nav_targets[0]:16'sd0);
 assign targets[1]=demo_running?demo_targets[1]:(mission_running?nav_targets[1]:16'sd0);
 assign targets[2]=demo_running?demo_targets[2]:(mission_running?nav_targets[2]:16'sd0);
 assign targets[3]=demo_running?demo_targets[3]:(mission_running?nav_targets[3]:16'sd0);
''')
a=s.index(' square_ui ui(');b=s.index(' wire map_busy',a)
s=s[:a]+''' basic_ui ui(.clk(clk),.rst_n(rst_n),.key_n(key_n),.active(active),.calibrated(calibrated),
  .width_mm(width_mm),.height_mm(height_mm),.page(page),.group_id(group_id),.menu_view(menu_view),.cursor(cursor),
  .motion_selection(motion_selection),.slow_test(slow_test),.demo_start(demo_start),
  .single_start(single_start),.route_start(route_start),.stop_pulse(stop_pulse),.calibrate_pulse(calibrate_pulse),
  .target_x(user_x),.target_y(user_y),.points_x(points_x),.points_y(points_y),.edit_index(edit_index),
  .gain_selection(gain_selection),.heading_kp(heading_kp),.heading_kd(heading_kd));
 basic_clearance ranges(.clk(clk),.rst_n(rst_n),.bad(stream_bad),.point_valid(point_valid),
  .forward_mm(point_x),.left_mm(point_y),.angle_cdeg(point_angle),.range_mm(point_range),
  .fresh(range_fresh),.near_stop(range_near),.scan_update(range_update),.front_mm(front_mm),.back_mm(back_mm),
  .left_distance(left_mm),.right_mm(right_mm),.front_limit(front_limit),.back_limit(back_limit),
  .left_limit(left_limit),.right_limit(right_limit));
 basic_mission mission(.clk(clk),.rst_n(rst_n),.start_single(single_start && !demo_running),
  .start_route(route_start && !demo_running),.stop(stop_pulse || calibrate_pulse || demo_running),
  .single_x(user_x),.single_y(user_y),.points_x(points_x),.points_y(points_y),
  .can_go(can_go),.nav_active(nav_active),.nav_status(nav_status),.running(mission_running),.nav_go(nav_go),
  .goal_change(goal_change),.target_x(target_x),.target_y(target_y),.point_index(point_index),
  .route_mode(route_mode),.status(mission_status));
''' +s[b:]
replace('.cancel(stream_bad || calibrate_pulse || stop_pulse || go_pulse)',
        '.cancel(stream_bad || calibrate_pulse || stop_pulse || nav_go || goal_change || demo_running)')
replace('.new_goal(go_pulse || calibrate_pulse)', '.new_goal(nav_go || goal_change || calibrate_pulse)')
# No unused implicit go net remains in the task project.
replace('wire calibrate_pulse,go_pulse,stop_pulse;', 'wire calibrate_pulse,stop_pulse;')
replace('.imu_ready(attitude_ready && imu_init)', '.imu_ready(attitude_ready && imu_init && imu_fresh)')
replace(' square_drive control(', ' basic_nav_drive control(')
replace('.calibrate(calibrate_pulse),.go(go_pulse),.stop(stop_pulse),.page(page)',
        '.calibrate(calibrate_pulse),.go(nav_go),.stop(stop_pulse || demo_running),.tick(ticks[0]),.page(page)')
replace('.near_obstacle(near_obstacle),.heading_ready(heading_ready && !heading_fault)',
        '.clearance_fresh(range_fresh),.front_limit(front_limit),.back_limit(back_limit),.left_limit(left_limit),.right_limit(right_limit),\n  .near_obstacle(near_obstacle || range_near),.heading_ready(heading_ready && !heading_fault)')
replace('.active(active),.fresh(fresh),.can_go(can_go)', '.active(nav_active),.fresh(fresh),.can_go(can_go)')
replace('.lf_target(targets[0]),.rf_target(targets[1]),.lb_target(targets[2]),.rb_target(targets[3])',
        '.lf_target(nav_targets[0]),.rf_target(nav_targets[1]),.lb_target(nav_targets[2]),.rb_target(nav_targets[3])')
replace(' genvar w;', ''' heading_hold #(.MAX_TURN(80),.DYNAMIC_GAINS(1),.QUIET_SAMPLES(20)) demo_heading(
  .clk(clk),.rst_n(rst_n && demo_heading_enable),.tick(ticks[0]),.angle_valid(attitude_valid),
  .imu_ready(attitude_ready && imu_init && imu_fresh),.quiet(quiet),.hold_turn(1'b0),.yaw(yaw),
  .base_speed(16'sd0),.target_yaw(demo_target),.relative_yaw(demo_yaw),.turn(demo_turn),
  .left_target(demo_left),.right_target(demo_right),.ready(demo_heading_ready),.fault(demo_heading_fault),
  .kp_live(heading_kp),.kd_live(heading_kd));
 basic_demo demo(.clk(clk),.rst_n(rst_n),.tick(ticks[0]),.start(demo_start && !mission_running),
  .stop(stop_pulse || calibrate_pulse),.selection(motion_selection),.slow_test(slow_test),
  .imu_ready(attitude_ready && imu_init && imu_fresh && !demo_heading_fault),.heading_ready(demo_heading_ready),
  .wheel_fault(|faults),.range_fresh(range_fresh),.near_stop(range_near),.front_limit(front_limit),.back_limit(back_limit),
  .relative_yaw(demo_yaw),.turn(demo_turn),.running(demo_running),.heading_enable(demo_heading_enable),
  .target_yaw(demo_target),.lf_target(demo_targets[0]),.rf_target(demo_targets[1]),
  .lb_target(demo_targets[2]),.rb_target(demo_targets[3]),.status(demo_status),.slow_seen(slow_seen),.stop_seen(stop_seen));
 genvar w;''')
a=s.index(' square_renderer overlay(');b=s.index(' uart_enc_debug ',a)
s=s[:a]+''' basic_renderer overlay(.clk(clk),.rst_n(rst_n),.frame_start(lidar_frame_start),.pixel_x(lidar_x),.pixel_y(lidar_y),
  .raw_pixel(raw_pixel),.menu_view(menu_view),.group_id(group_id),.cursor(cursor),.demo_status(demo_status),
  .mission_status(mission_status),.edit_index(edit_index),.point_index(point_index),.route_mode(route_mode),
  .camera_ready(frame_valid && init_done),.imu_ready(attitude_ready && imu_init && imu_fresh),
  .range_ready(range_fresh),.calibrated(calibrated),.near_stop(range_near),.slow_seen(slow_seen),.stop_seen(stop_seen),
  .pose_x(pose_x),.pose_y(pose_y),.demo_yaw(demo_yaw),.demo_target(demo_target),
  .target_x(mission_running?target_x:user_x),.target_y(mission_running?target_y:user_y),
  .width_mm(width_mm),.height_mm(height_mm),.front_mm(front_mm),.back_mm(back_mm),.left_mm(left_mm),.right_mm(right_mm),
  .points_x(points_x),.points_y(points_y),.front_limit(front_limit),.pixel(nav_pixel));
 wire [7:0] flags={demo_running,mission_running,calibrated,range_fresh,fresh,can_go,active,heading_ready};
 wire [167:0] diagnostics={24'h425401,flags,{demo_status,mission_status},
  {group_id,route_mode,point_index,2'd0},{4'd0,cursor},pose_x,pose_y,pose_yaw,target_x,target_y,front_mm,back_mm};
''' +s[b:]
# Existing telemetry and monitor pages show the controller currently driving.
s=s.replace('.heading_turn(turn)', '.heading_turn(demo_running?demo_turn:turn)')
# The replacement above also touched the nav-controller input: restore it there.
s=s.replace('.wheel_fault(|faults),.heading_turn(demo_running?demo_turn:turn)', '.wheel_fault(|faults),.heading_turn(turn)')
s=s.replace('.heading_fault(heading_fault)', '.heading_fault(demo_running?demo_heading_fault:heading_fault)')
(root/'basic_tasks/basic_tasks_top.v').write_text(s,encoding='utf-8')
xml=ET.fromstring((root/'square_navigation.gprj').read_text(encoding='utf-8-sig').replace('version="1"','version="1.0"'))
files=xml.find('FileList')
for name in ('basic_clearance','basic_mission','basic_demo','basic_ui','basic_nav_drive','basic_renderer','basic_tasks_top'):
    ET.SubElement(files,'File',{'path':f'basic_tasks/{name}.v','type':'file.verilog','enable':'1'})
ET.ElementTree(xml).write(root/'basic_tasks.gprj',encoding='utf-8',xml_declaration=True)
sources=[f.get('path') for f in files if f.get('type')=='file.verilog' and f.get('enable')=='1']
do='''onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/top_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib '''+' '.join('{'+v+'}' for v in sources)+'''
vsim -voptargs=+acc -gUSE_EXTERNAL_OSC=1 -lib $lib basic_tasks_top
force -freeze /basic_tasks_top/clk 0 0ns,1 10ns -repeat 20ns
force -freeze /basic_tasks_top/rst_n 0
force -freeze /basic_tasks_top/key_n 1111
run 100ns
force -freeze /basic_tasks_top/rst_n 1
run 1000ns
foreach pin {lf_pwm rf_pwm lb_pwm rb_pwm} {
 if {[examine -radix unsigned /basic_tasks_top/$pin] != 0} {error "Unexpected boot motor output"}
}
if {[examine -radix unsigned /basic_tasks_top/group_id] != 0} {error "Not in root task menu"}
puts "PASS basic tasks top elaboration; root menu and all boot PWM zero"
quit -code 0 -f
'''
(root/'basic_tasks/elaborate.do').write_text(do,encoding='utf-8')
print('Created basic_tasks.gprj and top; all original square-nav sources preserved')
