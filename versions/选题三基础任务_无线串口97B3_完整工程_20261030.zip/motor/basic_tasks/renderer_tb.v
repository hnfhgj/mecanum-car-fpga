`timescale 1ns/1ps
module basic_renderer_tb;
 reg clk=0,rst=0,fs=0,menu=1;reg [7:0] x=0;reg [6:0] y=0;reg [2:0] group_id=0;
 wire [15:0] pixel;integer passed=0,g,i,j,fd;
 always #10 clk=~clk;
 basic_renderer dut(clk,rst,fs,x,y,16'h1234,menu,group_id,4'd1,
  4'd5,4'd4,2'd1,2'd2,1'b1,1'b1,1'b1,1'b1,1'b1,1'b0,1'b1,1'b0,
  16'sd900,16'sd700,16'sd1500,16'sd3000,
  16'd1000,16'd1500,16'd2000,16'd2000,16'd350,16'd1000,16'd1000,16'd620,
  {16'd500,16'd1500,16'd1500,16'd500},{16'd1500,16'd1500,16'd500,16'd500},7'd30,pixel);
 task row(input integer n);begin x=0;y=n*8;repeat(3)@(negedge clk);end endtask
 initial begin
  #51;rst=1;
  for(g=0;g<6;g=g+1)begin
   group_id=g;@(negedge clk);fs=1;@(negedge clk);fs=0;repeat(300)@(negedge clk);
   row(0);if(g==0 && dut.line!={"BASIC TASK MENU",{5{8'h20}}})$fatal(1,"Root title");
   if(g==3)begin row(6);if(dut.line[159-2*8-:24]!="035" || dut.line[159-8*8-:24]!="100")$fatal(1,"Distance units");
    row(8);if(dut.line[159-12*8-:24]!="030")$fatal(1,"Speed units");end
   if(g==5)begin row(2);if(dut.line[159-8*8-:8]!="2")$fatal(1,"Edited point index");
    row(3);if(dut.line[159-10*8-:24]!="150")$fatal(1,"Point coordinates");end
   if(g==2)begin row(1);if(dut.line!="ENDED / CHECK RESULT")$fatal(1,"Demo claims pass rather than ended");end
   fd=$fopen($sformatf("basic_tasks/task_menu_%0d.hex",g),"w");
   for(j=0;j<128;j=j+1)for(i=0;i<160;i=i+1)begin x=i;y=j;repeat(3)@(negedge clk);$fwrite(fd,"%04x\n",pixel);end
   $fclose(fd);
  end
  menu=0;fs=1;@(negedge clk);fs=0;repeat(5)@(negedge clk);if(pixel!=16'h1234)$fatal(1,"Raw radar view");
  passed=1;$display("PASS basic task menu renderer six screens, numeric units, ordered point editor, raw view");$finish;
 end
endmodule
