`timescale 1ns/1ps
module wireless_uart_tb;
 reg clk=0,rst=0,valid=0,rx=1,rts=1;reg [7:0] data;
 wire tx;wire [7:0] out;wire received,frame_error;
 integer passed=0,n=0,k;reg [7:0] actual[0:255];
 always #5 clk=~clk;
 wireless_uart_bridge #(.CLK_HZ(1000),.BAUD(100),.ADDRESS_BITS(5)) dut(clk,rst,data,valid,rx,rts,tx);
 n10_uart_rx #(.CLK_HZ(1000),.BAUD(100)) check_rx(clk,rst,tx,out,received,frame_error);
 always @(posedge clk)begin
  if(received)begin actual[n]=out;n=n+1;end
  if(frame_error)$fatal(1,"Wireless framing error");
 end
 task push(input [7:0] c);begin @(negedge clk);data=c;valid=1;@(negedge clk);valid=0;end endtask
 task line(input [7:0] c);begin push(c);push(10);end endtask
 task host(input [7:0] c);integer b;begin
  @(negedge clk);rx=0;repeat(10)@(negedge clk);
  for(b=0;b<8;b=b+1)begin rx=c[b];repeat(10)@(negedge clk);end
  rx=1;repeat(15)@(negedge clk);
 end endtask
 task wait_bytes(input integer target);integer t;begin
  t=0;while(n<target && t<10000)begin @(negedge clk);t=t+1;end
  if(n!=target)$fatal(1,"Expected %0d received %0d",target,n);
 end endtask
 initial begin
  #31;rst=1;line("A");line("B");repeat(200)@(negedge clk);
  if(n || !tx)$fatal(1,"RTS high did not hold transmission");
  rts=0;wait_bytes(4);
  if(actual[0]!="A" || actual[1]!=10 || actual[2]!="B" || actual[3]!=10)$fatal(1,"Ordered telemetry");
  // A partial line must not become visible until LF commits it.
  push("C");repeat(200)@(negedge clk);if(n!=4)$fatal(1,"Partial line leaked");
  push(10);wait_bytes(6);
  host("?");wait_bytes(21);
  if(actual[6]!="W" || actual[14]!=" " || actual[15]!="O" || actual[16]!="K" || actual[19]!=13 || actual[20]!=10)$fatal(1,"Reply framing");
  host("P");line("D");repeat(300)@(negedge clk);if(n!=21)$fatal(1,"Pause failed");
  host("R");line("E");wait_bytes(23);if(actual[21]!="E" || actual[22]!=10)$fatal(1,"Resume failed");
  repeat(130)@(negedge clk);rts=1;repeat(4)@(negedge clk);
  // Fill 32 bytes while blocked. Extra lines must drop as units.
  for(k=0;k<20;k=k+1)line("F");
  if(!dut.overflow || dut.count!=32)$fatal(1,"Bounded queue did not report overflow");
  rts=0;wait_bytes(55);for(k=23;k<55;k=k+2)if(actual[k]!="F" || actual[k+1]!=10)$fatal(1,"Overflow damaged committed line");
  line("G");wait_bytes(57);if(actual[55]!="G")$fatal(1,"Queue did not recover");
  host("?");wait_bytes(72);if(actual[66]!="D" || actual[69]!="P")$fatal(1,"Loss status missing");
  push(10);wait_bytes(73);if(actual[72]!=10)$fatal(1,"Synchronous RAM one-byte line failed");
  passed=1;$display("PASS wireless UART: RTS pause, whole-line FIFO, overflow/recovery, receive commands and replies");$finish;
 end
 initial begin #3000000;$fatal(1,"Wireless test timed out");end
endmodule

module feedback_disabled_tb;
 reg clk=0,rst=0;reg signed [15:0] target=0,raw=0;
 wire fault,old_fault;wire signed [15:0] duty;wire [3:0] reason;
 integer passed=0;
 always #5 clk=~clk;
 basic_wheel_speed_loop #(.FIXED_ENCODER_SIGN(1),.NO_FEEDBACK_GUARD(0),.START_RAMP_STEP(15),.START_TICKS(6),.NO_FEEDBACK_TICKS(8)) dut(
  .clk(clk),.rst_n(rst),.enable(1'b1),.tick(1'b1),.target(target),.raw_speed(raw),.fault(fault),.command(duty),.fault_reason(reason),.measured(),.running(),.encoder_reverse(),.calibration_done(),.kp_live(0),.ki_live(0),.kd_live(0));
 wheel_speed_loop #(.FIXED_ENCODER_SIGN(1),.START_RAMP_STEP(15),.START_TICKS(6),.NO_FEEDBACK_TICKS(8)) old(
  .clk(clk),.rst_n(rst),.enable(1'b1),.tick(1'b1),.target(target),.raw_speed(raw),.fault(old_fault),.command(),.fault_reason(),.measured(),.running(),.encoder_reverse(),.calibration_done(),.kp_live(0),.ki_live(0),.kd_live(0));
 initial begin
  #31;rst=1;repeat(15)@(negedge clk);target=60;
  repeat(80)@(negedge clk);if(!old_fault || fault)$fatal(1,"Dropout lock not reproduced/removed");
  target=0;repeat(20)@(negedge clk);if(duty!=0)$fatal(1,"Idle PWM not zero");
  target=60;raw=-20;repeat(80)@(negedge clk);if(fault)$fatal(1,"Reverse feedback still locks");
  target=0;raw=0;repeat(20)@(negedge clk);target=-60;
  repeat(50)@(negedge clk);if(fault)$fatal(1,"Repeated reverse test blocked");
  target=0;repeat(5)@(negedge clk);if(duty!=0)$fatal(1,"Stop output nonzero");
  passed=1;$display("PASS feedback lock removed: original fails dropout, new repeats starts and reversals without latch");$finish;
 end
endmodule
