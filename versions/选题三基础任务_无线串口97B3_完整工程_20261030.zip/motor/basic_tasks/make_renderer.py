from pathlib import Path
root=Path(__file__).resolve().parent.parent
old=(root/'square_nav/square_renderer.v').read_text(encoding='utf-8-sig')
body=old[old.index(' reg [7:0] x;'):old.index(' function [7:0] hexchar')]
body=body.replace('[0:7]','[0:15]').replace('m<8','m<16').replace('convert_index==7','convert_index==15')
body=body.replace(' reg [7:0] x;', ''' reg [2:0] group_q;reg [1:0] edit_q,point_q;
 reg cam_q,imu_q,range_q,cal_q,near_q,slow_q,stop_q,route_q,yaw_negative,target_negative;
 reg [7:0] x;''')
body=body.replace('if(!rst_n)begin x<=0;', '''if(!rst_n)begin group_q<=0;edit_q<=0;point_q<=0;cam_q<=0;imu_q<=0;range_q<=0;cal_q<=0;
   near_q<=0;slow_q<=0;stop_q<=0;route_q<=0;yaw_negative<=0;target_negative<=0;x<=0;''')
a=body.index('    menu<=menu_view;');b=body.index('   end else if(converting)',a)
body=body[:a]+'''    menu<=menu_view;field<=cursor;group_q<=group_id;edit_q<=edit_index;point_q<=point_index;
    cam_q<=camera_ready;imu_q<=imu_ready;range_q<=range_ready;cal_q<=calibrated;
    near_q<=near_stop;slow_q<=slow_seen;stop_q<=stop_seen;route_q<=route_mode;
    fr_status<=(group_id==2 || group_id==3)?demo_status:mission_status;
    numbers[0]<=pose_x<0?-pose_x:pose_x;numbers[1]<=pose_y<0?-pose_y:pose_y;
    numbers[2]<=target_x;numbers[3]<=target_y;numbers[4]<=width_mm;numbers[5]<=height_mm;
    numbers[6]<=front_mm;numbers[7]<=back_mm;numbers[8]<=left_mm;numbers[9]<=right_mm;
    numbers[10]<=demo_yaw<0?-demo_yaw:demo_yaw;numbers[11]<=demo_target<0?-demo_target:demo_target;
    numbers[12]<=points_x[edit_index*16+:16];numbers[13]<=points_y[edit_index*16+:16];
    numbers[14]<={9'd0,front_limit};numbers[15]<=0;
    yaw_negative<=demo_yaw<0;target_negative<=demo_target<0;
    convert_index<=0;convert_bit<=0;work<=0;converting<=1;
    binary<=pose_x<0?-pose_x:pose_x;
''' +body[b:]
header='''// Twenty columns, sixteen rows; snapshot numbers at display frame boundary.
module basic_renderer(input wire clk,rst_n,frame_start,input wire [7:0] pixel_x,input wire [6:0] pixel_y,
 input wire [15:0] raw_pixel,input wire menu_view,input wire [2:0] group_id,input wire [3:0] cursor,
 input wire [3:0] demo_status,mission_status,input wire [1:0] edit_index,point_index,input wire route_mode,
 input wire camera_ready,imu_ready,range_ready,calibrated,near_stop,slow_seen,stop_seen,
 input wire signed [15:0] pose_x,pose_y,demo_yaw,demo_target,
 input wire [15:0] target_x,target_y,width_mm,height_mm,front_mm,back_mm,left_mm,right_mm,
 input wire [63:0] points_x,points_y,input wire [6:0] front_limit,output reg [15:0] pixel);
'''
# Old unused snapshot registers are harmless and swept; they simplify reuse of
# the verified two-stage glyph / BCD pipeline without editing released sources.
tail=''' function [7:0] digit(input [3:0] v);begin digit=8'd48+v;end endfunction
 function [23:0] cm(input [19:0] v);begin cm={digit(v[15:12]),digit(v[11:8]),digit(v[7:4])};end endfunction
 function [23:0] deg(input [19:0] v);begin deg={digit(v[19:16]),digit(v[15:12]),digit(v[11:8])};end endfunction
 function [23:0] integer3(input [19:0] v);begin integer3={digit(v[11:8]),digit(v[7:4]),digit(v[3:0])};end endfunction
 reg [159:0] line;reg [7:0] character;reg [2:0] font_x,font_y;
 reg [7:0] character_q;reg [2:0] font_x_q,font_y_q;reg menu_q,selected_q;
 wire glyph;wire [3:0] row=y[6:3];
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin character_q<=32;font_x_q<=0;font_y_q<=0;menu_q<=0;selected_q<=0;end
  else begin character_q<=character;font_x_q<=font_x;font_y_q<=font_y;menu_q<=menu;
   selected_q<=row>=2 && row==field+1;end
 end
 tft180_font font(.ascii(character_q),.x(font_x_q),.y(font_y_q),.pixel(glyph));
 always @*begin
  line="                    ";
  case(group_q)
'''
def line(s):
    assert len(s)<=20,(s,len(s))
    return 'line="'+s.ljust(20)+'";'
def numeric(s,fields):
    result=line(s)
    for token,expr in fields.items():
        i=s.index(token)
        result+=f'line[159-{i}*8-:24]={expr};'
    return 'begin '+result+'end'
tables={
0:{0:'BASIC TASK MENU',2:'1 SENSOR DISPLAY',3:'2 MOTION TESTS',4:'3 OBSTACLE TESTS',5:'4 NAVIGATION',6:'5 HEADING P/D',7:'6 LIVE RADAR',8:'BODY:30X16 CM',11:'NO AUTO START',12:'SELECT ONE TASK'},
1:{0:'TASK1 SENSORS',2:'1 CAMERA',3:'2 ANGLES/ENC/TOF',4:'3 RAW IMU',5:'4 CONTROL MONITOR',6:'5 BACK',9:'VIEW THEN S1 BACK'},
2:{0:'TASK2 MOTION',2:'1 FORWARD 4S',3:'2 REVERSE 4S',4:'3 MOVING LEFT',5:'4 MOVING RIGHT',6:'5 SPIN LEFT 30DEG',7:'6 SPIN RIGHT 30DEG',8:'7 BACK',10:'TURN15 SPIN30 DEG',11:'4 WHEEL SPEED PID'},
3:{0:'TASK3 OBSTACLE',2:'1 LIVE DISTANCES',3:'2 APPROACH SLOW/STOP',4:'3 BYPASS: NAV MENU',5:'4 BACK',11:'700/550/400/270MM',12:'LIMIT 60/45/30/15/0'},
4:{0:'TASK4 NAVIGATION',2:'1 CALIBRATE FRAME',5:'4 GO SINGLE',6:'5 EDIT 4 POINTS',7:'6 RUN 4 POINTS',8:'7 BACK'},
5:{0:'EDIT ORDERED POINTS',5:'4 BACK',6:'FIXED COUNT:4',7:'STEP:5CM',8:'EDIT THEN RUN 4',10:'BODY ENVELOPE:27CM'},
}
for group,rows in tables.items():
    tail+=f'   {group}:case(row)\n'
    for row,s in rows.items():tail+=f'    {row}:begin {line(s)}end\n'
    if group==0:
        tail+='    9:begin '+line('CAM:0 IMU:0 LDR:0')+'line[159-4*8-:8]=cam_q?"1":"0";line[159-10*8-:8]=imu_q?"1":"0";line[159-16*8-:8]=range_q?"1":"0";end\n'
        tail+='    10:begin '+line('FRAME:0 RANGE:0')+'line[159-6*8-:8]=cal_q?"1":"0";line[159-14*8-:8]=range_q?"1":"0";end\n'
    if group==2:
        tail+='    9:'+numeric('YAW:+DDD TO:+EEE',{'DDD':'deg(bcd[10])','EEE':'deg(bcd[11])'}).replace('end','line[159-4*8-:8]=yaw_negative?"-":"+";line[159-12*8-:8]=target_negative?"-":"+";end')+'\n'
    if group==3:
        tail+='    6:'+numeric('F:FFF B:BBB CM',{'FFF':'cm(bcd[6])','BBB':'cm(bcd[7])'})+'\n'
        tail+='    7:'+numeric('L:LLL R:RRR CM',{'LLL':'cm(bcd[8])','RRR':'cm(bcd[9])'})+'\n'
        tail+='    8:'+numeric('FRONT LIMIT:SSS',{'SSS':'integer3(bcd[14])'})+'\n'
        tail+='    9:begin '+line('SLOW:0 STOP:0')+'line[159-5*8-:8]=slow_q?"1":"0";line[159-12*8-:8]=stop_q?"1":"0";end\n'
        tail+='    10:begin '+line('RANGE:0 NEAR:0')+'line[159-6*8-:8]=range_q?"1":"0";line[159-13*8-:8]=near_q?"1":"0";end\n'
    if group==4:
        for row,s,fields in [(3,'2 GOAL X:XXX CM',{'XXX':'cm(bcd[2])'}),(4,'3 GOAL Y:YYY CM',{'YYY':'cm(bcd[3])'}),
                              (9,'POS XXX YYY CM',{'XXX':'cm(bcd[0])','YYY':'cm(bcd[1])'}),
                              (10,'TGT XXX YYY CM',{'XXX':'cm(bcd[2])','YYY':'cm(bcd[3])'}),
                              (11,'BOX WWW HHH CM',{'WWW':'cm(bcd[4])','HHH':'cm(bcd[5])'})]:
            tail+=f'    {row}:'+numeric(s,fields)+'\n'
        tail+='    12:begin '+line('WP:1/4  HOLD +Y')+'line[159-3*8-:8]=digit({2\'d0,point_q}+1\'b1);if(!route_q)'+line('SINGLE TARGET +Y')+'end\n'
    if group==5:
        tail+='    2:begin '+line('1 POINT:1 OF 4')+'line[159-8*8-:8]=digit({2\'d0,edit_q}+1\'b1);end\n'
        tail+='    3:'+numeric('2 POINT X:XXX CM',{'XXX':'cm(bcd[12])'})+'\n'
        tail+='    4:'+numeric('3 POINT Y:YYY CM',{'YYY':'cm(bcd[13])'})+'\n'
    tail+='    default:begin end\n   endcase\n'
tail+='''   default:begin end
  endcase
  if(row==1)case(fr_status)
'''
for state,text in {0:'IDLE / SELECT',1:'WAIT READY / ARMING',2:'NOT READY',4:'RUNNING',5:'ENDED / CHECK RESULT',6:'FAULT / NO FIX',7:'STOPPED',8:'OBSTACLE STOP'}.items():
    tail+=f'   {state}:begin {line(text)}end\n'
tail+='''   default:begin end
  endcase
'''
for row,text in {13:'S1 BACK / STOP',14:'S2 NEXT S3 ENTER/+',15:'S4 MINUS / STOP'}.items():tail+=f'  if(row=={row})begin {line(text)}end\n'
tail+='''  character=x<160?line[(19-x[7:3])*8+:8]:8'd32;font_x=x[2:0];font_y=y[2:0];
  pixel=menu_q?(glyph?(selected_q?16'hffe0:16'hffff):16'h0000):raw_pixel;
 end
endmodule
'''
(root/'basic_tasks/basic_renderer.v').write_text(header+body+tail,encoding='utf-8')
print('Created task menu renderer')
