onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/render_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/tft180_font.v basic_tasks/basic_renderer.v basic_tasks/renderer_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib basic_renderer_tb
run -all
if {[examine -radix unsigned /basic_renderer_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
