set root [file normalize [file join [file dirname [info script]] ..]]
cd $root
open_project [file join $root basic_tasks.gprj] -pn GW5AT-LV60PG484AC1/I0 -device_version B
puts [catch {run invalid_command} result]
puts $result
exit
