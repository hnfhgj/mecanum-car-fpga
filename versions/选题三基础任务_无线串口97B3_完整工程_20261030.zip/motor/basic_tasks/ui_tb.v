`timescale 1ns/1ps
module basic_ui_tb;
 reg clk=0,rst=0,active=0;reg [3:0] keys=15;
 wire [2:0] page,group_id,selection;wire menu,slow,demo,single,route,stop,cal;
 wire [3:0] cursor,gain;wire [15:0] x,y;wire [63:0] xs,ys;wire [1:0] idx;wire [31:0] kp,kd;
 integer passed=0,ndemo=0,nsingle=0,nroute=0,nstop=0,ncal=0;
 always #10 clk=~clk;
 basic_ui #(.CLK_HZ(10000)) dut(clk,rst,active,keys,1'b1,16'd2000,16'd2000,
  page,group_id,menu,cursor,selection,slow,demo,single,route,stop,cal,x,y,xs,ys,idx,gain,kp,kd);
 always @(posedge clk)begin if(demo)ndemo=ndemo+1;if(single)nsingle=nsingle+1;if(route)nroute=nroute+1;
  if(stop)nstop=nstop+1;if(cal)ncal=ncal+1;end
 task key(input integer k);begin @(negedge clk);keys[k]=0;repeat(250)@(negedge clk);keys[k]=1;repeat(250)@(negedge clk);end endtask
 initial begin
  #51;rst=1;repeat(10)@(negedge clk);
  if(page!=5 || group_id || cursor!=1 || ndemo || nsingle || nroute)$fatal(1,"Wrong boot menu");
  key(2);if(group_id!=1)$fatal(1,"Sensors submenu");key(2);if(page!=4)$fatal(1,"Camera page");
  key(0);if(page!=5 || group_id!=1)$fatal(1,"Return from sensor view");key(0);
  key(1);key(2);if(group_id!=2)$fatal(1,"Motion submenu");key(2);if(ndemo!=1 || selection || slow)$fatal(1,"Forward launch");
  active=1;key(1);key(2);if(cursor!=1 || ndemo!=1)$fatal(1,"Active menu edited/restarted");
  key(3);if(nstop!=3)$fatal(1,"S4 stop missing");active=0;
  key(1);key(2);if(selection!=1 || ndemo!=2)$fatal(1,"Reverse launch");key(0);
  key(1);key(1);key(2);if(group_id!=3)$fatal(1,"Obstacle submenu");key(1);key(2);
  if(!slow || ndemo!=3)$fatal(1,"Approach launch");key(0);
  repeat(3)key(1);key(2);if(group_id!=4)$fatal(1,"Navigation submenu");key(2);if(ncal!=1)$fatal(1,"Calibration");
  key(1);key(2);if(x!=1050)$fatal(1,"Single X edit");key(1);key(3);if(y!=950)$fatal(1,"Single Y edit");
  key(1);key(2);if(nsingle!=1)$fatal(1,"Single navigation launch");
  key(1);key(2);if(group_id!=5)$fatal(1,"Point editor");key(2);if(idx!=1)$fatal(1,"Point select");
  key(1);key(2);if(xs[31:16]!=1550 || xs[15:0]!=500)$fatal(1,"Point X independently edited");
  key(1);key(3);if(ys[31:16]!=450 || ys[15:0]!=500)$fatal(1,"Point Y independently edited");
  key(0);if(group_id!=4)$fatal(1,"Editor back");repeat(5)key(1);key(2);if(nroute!=1)$fatal(1,"Ordered route launch");
  active=1;key(0);if(group_id || page!=5)$fatal(1,"Back did not cancel to root");active=0;
  repeat(4)key(1);key(2);if(page!=1)$fatal(1,"PID settings");key(2);if(kp!=328)$fatal(1,"Heading P edit");
  key(0);if(page!=5)$fatal(1,"PID back");
  passed=1;$display("PASS basic task menu real buttons sensors/motion/avoid/nav, editable ordered points, PID, stop/interlocks");$finish;
 end
endmodule
