onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/control_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/n10_sincos.v pillar_nav/nav_math.v pillar_nav/nav_buttons.v square_nav/square_project.v basic_tasks/basic_ui.v basic_tasks/basic_nav_drive.v basic_tasks/ui_tb.v basic_tasks/nav_tb.v
foreach test {basic_ui_tb basic_nav_tb} {
 vsim -onfinish stop -voptargs=+acc -lib $lib $test
 run -all
 if {[examine -radix unsigned /$test/passed] != 1} {quit -code 1 -f}
 quit -sim
}
quit -code 0 -f
