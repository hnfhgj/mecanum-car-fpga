`timescale 1ns/1ps
// Independent ray caster / ideal 50mm plant. Real map, BFS, corridor detector,
// mission sequencer and navigation controller. Not real inertia or UART/IMU.
module basic_integration_tb;
 reg clk=0,rst=0,start_route=0,map_start=0,pu=0,pv=0,tick=0;
 reg signed [15:0] robot_x=1025,robot_y=525,point_f=0,point_l=0;
 reg [15:0] angle=0,range_mm=0;reg signed [15:0] f[0:511],l[0:511],read_f,read_l;
 wire [8:0] ra;wire mb,md,mv,map_near,we,free;wire [11:0] wa;
 wire pb,pd,found,rejected,reached;wire [1:0] direction;
 wire [15:0] tx,ty;
 wire [11:0] origin=((robot_y/50)<<6)+(robot_x/50),goal=((ty/50)<<6)+(tx/50);
 wire range_fresh,range_near,range_update;wire [15:0] fm,bm,lm,rm;wire [6:0] fl,bl,ll,rl;
 wire mission_run,go,change,route_mode,navrun,fresh,can;wire [1:0] idx;
 wire [3:0] ms,ns;wire signed [15:0] lf,rf,lb,rb;
 reg allowed[0:4095];integer passed=0,i,j,step,cycles,fd,forward_speed,left_speed,nx,ny,slow_steps=0,launches=0,max_detour=0,tick_count=0;
 real theta,dx,dy,distance,t,hit,cx,cy;
 always #10 clk=~clk;
 always @(posedge clk)begin
  read_f<=f[ra];read_l<=l[ra];if(we)allowed[wa]<=free;if(go)launches=launches+1;
  tick<=tick_count==499;if(tick_count==499)tick_count<=0;else tick_count<=tick_count+1;
 end
 basic_clearance ranges(clk,rst,1'b0,pv,point_f,point_l,angle,range_mm,
  range_fresh,range_near,range_update,fm,bm,lm,rm,fl,bl,ll,rl);
 square_map map(clk,rst,1'b0,map_start,10'd450,read_f,read_l,ra,robot_x,robot_y,16'sd9000,16'd2000,16'd2000,
  mb,md,mv,map_near,we,wa,free);
 square_grid_route #(.EXPLORE(1)) planner(clk,rst,go||change,we,wa,free,md&&mv,origin,goal,
  pb,pd,found,direction,rejected,go||change,reached);
 basic_mission mission(clk,rst,1'b0,start_route,1'b0,16'd1000,16'd1600,
  {16'd1000,16'd1500,16'd1500,16'd1000},{16'd500,16'd500,16'd1600,16'd1600},
  can,navrun,ns,mission_run,go,change,tx,ty,idx,route_mode,ms);
 basic_nav_drive nav(clk,rst,1'b0,go,1'b0,tick,3'd5,1'b1,pu,1'b1,robot_x,robot_y,16'sd9000,
  tx,ty,16'd2000,16'd2000,pd,found,reached,direction,range_fresh,fl,bl,ll,rl,map_near||range_near,
  1'b1,1'b0,16'sd0,16'sd0,navrun,fresh,can,ns,lf,rf,lb,rb);
 task vertical(input real x,input real low,input real high);begin
  if((dx<0?-dx:dx)>0.000001)begin t=(x-robot_x)/dx;hit=robot_y+t*dy;
   if(t>0 && hit>=low && hit<=high && t<distance)distance=t;end
 end endtask
 task horizontal(input real y,input real low,input real high);begin
  if((dy<0?-dy:dy)>0.000001)begin t=(y-robot_y)/dy;hit=robot_x+t*dx;
   if(t>0 && hit>=low && hit<=high && t<distance)distance=t;end
 end endtask
 task scan;begin
  for(i=0;i<450;i=i+1)begin
   theta=i*0.8*3.141592653589793/180;dx=$sin(theta);dy=$cos(theta);distance=10000;
   vertical(0,0,2000);vertical(2000,0,2000);horizontal(0,0,2000);horizontal(2000,0,2000);
   vertical(950,1050,1150);vertical(1050,1050,1150);horizontal(1050,950,1050);horizontal(1150,950,1050);
   f[i]=$rtoi(distance*$cos(theta));l[i]=-$rtoi(distance*$sin(theta));
   @(negedge clk);point_f=f[i];point_l=l[i];range_mm=$rtoi(distance);angle=i*80;pv=1;
   @(negedge clk);pv=0;
  end
 end endtask
 task pose;begin pu=1;@(negedge clk);pu=0;repeat(200)@(negedge clk);end endtask
 initial begin
  #51;rst=1;repeat(3)scan();repeat(5)pose();start_route=1;@(negedge clk);start_route=0;
  fd=$fopen("basic_tasks/integration_trace.txt","w");
  for(step=0;step<180;step=step+1)begin
   if(!mission_run && ms==5)begin
    if(launches!=4 || max_detour<300 || slow_steps==0)$fatal(1,"Missing ordered goals/detour/slowdown");
    $fclose(fd);passed=1;$display("PASS basic four-point map/planner/clearance/nav integration steps=%d slowdown_steps=%d",step,slow_steps);$finish;
   end
   if(ms==6 || ns==6)$fatal(1,"Control failed step %d idx %d xy %d %d ns %d",step,idx,robot_x,robot_y,ns);
   repeat(2)scan();pose();map_start=1;@(negedge clk);map_start=0;
   cycles=0;while(!pd && cycles<1700000)begin @(negedge clk);cycles=cycles+1;end
   if(!pd || !found || rejected || range_near || map_near)$fatal(1,"Invalid map/route at step %d",step);
   repeat(600)@(negedge clk);
   forward_speed=($signed(lf)+$signed(rf)+$signed(lb)+$signed(rb))/4;
   left_speed=(-$signed(lf)+$signed(rf)+$signed(lb)-$signed(rb))/4;
   if(forward_speed && left_speed)$fatal(1,"Unexpected diagonal grid edge");
   if((-lf+rf-lb+rb)!=0)$fatal(1,"Heading changed without heading request");
   if((forward_speed && (forward_speed<0?-forward_speed:forward_speed)<60) ||
      (left_speed && (left_speed<0?-left_speed:left_speed)<60))slow_steps=slow_steps+1;
   nx=robot_x+(left_speed>0?-50:(left_speed<0?50:0));
   ny=robot_y+(forward_speed>0?50:(forward_speed<0?-50:0));
   if(nx<270 || ny<270 || nx>1730 || ny>1730)$fatal(1,"Frame boundary crossed");
   if(!allowed[(ny/50)*64+(nx/50)])$fatal(1,"Entered unknown/occupied cell");
   cx=nx<950?950-nx:(nx>1050?nx-1050:0);cy=ny<1050?1050-ny:(ny>1150?ny-1150:0);
   if(cx*cx+cy*cy<270*270)$fatal(1,"Vehicle envelope collision");
   if(idx==0 && (nx>1025?nx-1025:1025-nx)>max_detour)max_detour=nx>1025?nx-1025:1025-nx;
   $fdisplay(fd,"%d %d %d %d %d %d %d",idx,robot_x,robot_y,lf,rf,lb,rb);
   robot_x=nx;robot_y=ny;
  end
  $fatal(1,"Ordered route did not finish");
 end
endmodule
