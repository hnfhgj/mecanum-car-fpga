param([string]$Port='', [int]$Seconds=10, [string]$LogPath='', [string]$InputLog='')
$ErrorActionPreference='Stop'
if($InputLog){$text=Get-Content -LiteralPath $InputLog -Raw -Encoding UTF8}
else {
 if(!$Port){throw 'Specify -Port or -InputLog'}
 $serial=[System.IO.Ports.SerialPort]::new($Port,115200,[System.IO.Ports.Parity]::None,8,[System.IO.Ports.StopBits]::One)
 $serial.DtrEnable=$false;$serial.RtsEnable=$false;$text=''
 try {
  $serial.Open();$watch=[System.Diagnostics.Stopwatch]::StartNew()
  while($watch.Elapsed.TotalSeconds -lt $Seconds){$text+=$serial.ReadExisting();Start-Sleep -Milliseconds 40}
  $text+=$serial.ReadExisting()
 } finally {if($serial.IsOpen){$serial.Close()};$serial.Dispose()}
}
if($LogPath){$text|Out-File -LiteralPath $LogPath -Encoding utf8}
function Word([byte[]]$Bytes,[int]$Index,[switch]$Signed){
 $v=([int]$Bytes[$Index] -shl 8)+$Bytes[$Index+1]
 if($Signed -and $v -ge 32768){$v-=65536};return $v
}
$lines=$text -split '\r?\n'
$frames=@($lines|Where-Object {$_ -match '^IO HEX=[0-9A-F]{42}$'})
"Bytes=$($text.Length) Frames=$($frames.Count)"
foreach($line in ($frames|Select-Object -Last 12)){
 $hex=$line.Substring(7);$bytes=[byte[]]::new(21)
 for($i=0;$i -lt 21;$i++){$bytes[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
 if($bytes[0] -ne 0x42 -or $bytes[1] -ne 0x54 -or $bytes[2] -ne 1){throw 'Not basic-task telemetry version 1'}
 $flags=$bytes[3]
 [pscustomobject]@{DemoState=($bytes[4] -shr 4);MissionState=($bytes[4] -band 15);
  TaskGroup=($bytes[5] -shr 5);RouteMode=[bool]($bytes[5] -band 16);Waypoint=(1+(($bytes[5] -shr 2) -band 3));
  Cursor=$bytes[6];X_mm=(Word $bytes 7 -Signed);Y_mm=(Word $bytes 9 -Signed);WorldYaw_cdeg=(Word $bytes 11 -Signed);
  TargetX_mm=(Word $bytes 13);TargetY_mm=(Word $bytes 15);Front_mm=(Word $bytes 17);Back_mm=(Word $bytes 19);
  DemoRunning=[bool]($flags -band 128);MissionRunning=[bool]($flags -band 64);Calibrated=[bool]($flags -band 32);
  RangeFresh=[bool]($flags -band 16);PoseFresh=[bool]($flags -band 8);CanGo=[bool]($flags -band 4);
  Active=[bool]($flags -band 2);HeadingReady=[bool]($flags -band 1)}|ConvertTo-Json -Compress
}
$lines|Where-Object {$_ -match '^(LF=|PID |ATT |DBG )'}|Select-Object -Last 8
