onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/top_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib {pillar_nav/nav_atan2.v} {pillar_nav/nav_attitude.v} {pillar_nav/nav_attitude_program.v} {pillar_nav/nav_buttons.v} {pillar_nav/nav_camera.v} {pillar_nav/nav_camera_capture.v} {pillar_nav/nav_control.v} {pillar_nav/nav_features.v} {pillar_nav/nav_lidar.v} {pillar_nav/nav_math.v} {pillar_nav/nav_point_stream.v} {pillar_nav/nav_pose.v} {pillar_nav/nav_renderer.v} {pillar_nav/nav_scan_core.v} {pillar_nav/nav_scan_renderer.v} {pillar_nav/nav_tft_display.v} {pillar_nav/nav_ui.v} {square_nav/square_drive.v} {square_nav/square_frame_fit.v} {square_nav/square_grid_route.v} {square_nav/square_map.v} {square_nav/square_nav_top.v} {square_nav/square_project.v} {square_nav/square_renderer.v} {square_nav/square_ui.v} {src/attitude_cordic.v} {src/camera_clock_24.v} {src/camera_dashboard_top.v} {src/dashboard_keys.v} {src/dl1b.v} {src/dl1b_config_rom.v} {src/heading_hold.v} {src/i2c_master.v} {src/imu660ra.v} {src/imu660ra_config_rom.v} {src/imu_attitude.v} {src/motor_driver.v} {src/motor_top.v} {src/n10_dashboard_top.v} {src/n10_lidar.v} {src/n10_packet_queue.v} {src/n10_project_point.v} {src/n10_scan_core.v} {src/n10_scan_ram.v} {src/n10_scan_renderer.v} {src/n10_sincos.v} {src/ov5640_camera.v} {src/ov5640_capture.v} {src/ov5640_config.v} {src/ov5640_config_rom.v} {src/ov5640_frame_ram.v} {src/ov5640_reset_sync.v} {src/quad_decoder.v} {src/speed_measure.v} {src/speed_pid.v} {src/spi_master.v} {src/tft180_display.v} {src/tft180_font.v} {src/tft180_init_rom.v} {src/uart_enc_debug.v} {src/uart_rx.v} {src/uart_tx.v} {src/wheel_speed_loop.v} {basic_tasks/basic_clearance.v} {basic_tasks/basic_mission.v} {basic_tasks/basic_demo.v} {basic_tasks/basic_ui.v} {basic_tasks/basic_nav_drive.v} {basic_tasks/basic_renderer.v} {basic_tasks/basic_tasks_top.v} {basic_tasks/basic_wheel_speed_loop.v} {basic_tasks/basic_uart_debug.v} {basic_tasks/wireless_uart_bridge.v}
vsim -voptargs=+acc -gUSE_EXTERNAL_OSC=1 -lib $lib basic_tasks_top
force -freeze /basic_tasks_top/clk 0 0ns,1 10ns -repeat 20ns
force -freeze /basic_tasks_top/rst_n 0
force -freeze /basic_tasks_top/key_n 1111
force -freeze /basic_tasks_top/wireless_rx 1
force -freeze /basic_tasks_top/wireless_rts 1
run 100ns
force -freeze /basic_tasks_top/rst_n 1
run 1000ns
foreach pin {lf_pwm rf_pwm lb_pwm rb_pwm} {
 if {[examine -radix unsigned /basic_tasks_top/$pin] != 0} {error "Unexpected boot motor output"}
}
if {[examine -radix unsigned /basic_tasks_top/group_id] != 0} {error "Not in root task menu"}
echo "PASS basic tasks top elaboration; root menu and all boot PWM zero"
quit -code 0 -f
