onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/unit_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib basic_tasks/basic_clearance.v basic_tasks/basic_demo.v basic_tasks/basic_mission.v basic_tasks/unit_tb.v
foreach test {basic_clearance_tb basic_demo_tb basic_mission_tb} {
 vsim -onfinish stop -voptargs=+acc -lib $lib $test
 run -all
 if {[examine -radix unsigned /$test/passed] != 1} {quit -code 1 -f}
 quit -sim
}
quit -code 0 -f
