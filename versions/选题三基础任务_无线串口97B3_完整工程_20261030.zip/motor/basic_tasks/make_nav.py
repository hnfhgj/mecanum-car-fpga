"""Independent task navigation core; preserves the released E1CC source."""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
s=(root/'square_nav/square_drive.v').read_text(encoding='utf-8-sig')
s=s.replace('module square_drive #(', 'module basic_nav_drive #(')
s=s.replace('input wire clk,rst_n,calibrate,go,stop,', 'input wire clk,rst_n,calibrate,go,stop,tick,')
s=s.replace(' input wire near_obstacle,heading_ready,wheel_fault,', ''' input wire clearance_fresh,
 input wire [6:0] front_limit,back_limit,left_limit,right_limit,
 input wire near_obstacle,heading_ready,wheel_fault,''')
s=s.replace(' assign fresh=', ''' wire [6:0] selected_limit=direction==0?right_limit:(direction==1?front_limit:(direction==2?left_limit:back_limit));
 assign fresh=''')
s=s.replace('&& !near_obstacle && in_bounds;', '&& !near_obstacle && clearance_fresh && in_bounds;')
s=s.replace('&& page==5;', '&& page==5 && clearance_fresh && selected_limit!=0 && !at_goal;')
s=s.replace('(pose_update && pose_ok))begin', '(pose_update && pose_ok) || tick)begin')
s=s.replace("16'sd60", "$signed({9'd0,selected_limit})")
s=s.replace('(pose_update && pose_ok))request<=1;', '(pose_update && pose_ok) || tick)request<=1;')
s=s.replace('(!fresh || wheel_fault ||', '(!fresh || !clearance_fresh || wheel_fault ||')
# Only reject a blocked movement direction once a committed route selects it.
s=s.replace('(route_done && !route_found) ||', '(route_done && !route_found) || (route_valid && selected_limit==0) ||')
(root/'basic_tasks/basic_nav_drive.v').write_text(s,encoding='utf-8')
print('Created independent distance-scaled navigation core')
