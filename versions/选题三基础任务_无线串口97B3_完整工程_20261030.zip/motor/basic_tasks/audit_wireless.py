"""Offline check of all source hashes and final wireless GPIO ownership."""
from pathlib import Path
import re,json,hashlib

r=Path(__file__).resolve().parent.parent
b=r/'basic_tasks'
def locations(p):
    return re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;',p.read_text(encoding='utf-8-sig'))
old=dict(locations(r/'n10_build/lidar_board.cst'))
pairs=locations(b/'wireless_board.cst')
pins=dict(pairs)
assert len(pins)==len(pairs)==len(set(pins.values()))==56
assert len(old)==53 and all(pins.get(n)==p for n,p in old.items())
assert {n:p for n,p in pins.items() if n not in old}==dict(wireless_tx='F18',wireless_rx='E18',wireless_rts='F19')
device=json.loads(Path('E:/Gowin/Gowin_V1.9.12.03_x64/IDE/data/device/GW5AT-60B/PBGA484A.json').read_text())
package={p['INDEX']:p for p in device['PIN_DATA']}
for pad in ['F18','E18','F19']:
    assert package[pad]['TYPE']=='I/O' and package[pad]['BANK']==2
snapshot=json.loads((b/'inputs.json').read_text())
for name,h in snapshot.items():
    assert hashlib.sha256((r/name).read_bytes()).hexdigest().upper()==h,name
baseline=json.loads((b/'release/manifest_97A2.json').read_text())
for name,h in baseline['inputs'].items():
    if name.startswith(('src/','pillar_nav/','square_nav/','n10_build/')):
        assert hashlib.sha256((r/name).read_bytes()).hexdigest().upper()==h,name
print('PASS original 53 pads unchanged; 3 unique legal BANK2 wireless pads; source snapshot matches; shared 97A2 RTL unchanged')
