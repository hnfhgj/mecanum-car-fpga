from pathlib import Path
from PIL import Image
for source in Path(__file__).resolve().parent.glob('task_menu_*.hex'):
    values=[int(v,16)for v in source.read_text(encoding='ascii').split()]
    assert len(values)==160*128
    im=Image.new('RGB',(160,128))
    im.putdata([(((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31)for v in values])
    im.resize((800,640),Image.Resampling.NEAREST).save(source.with_suffix('.png'))
print('Rendered synthetic task-menu previews')
