"""Prepare a separate next release without changing the released shared RTL."""
from pathlib import Path

r = Path(__file__).resolve().parent.parent
b = r / 'basic_tasks'

def edit(path, old, new):
    text = path.read_text(encoding='utf-8-sig')
    assert old in text, (path, old[:70])
    path.write_text(text.replace(old, new), encoding='utf-8')

text = (r/'src/wheel_speed_loop.v').read_text(encoding='utf-8-sig')
text = text.replace('module wheel_speed_loop', 'module basic_wheel_speed_loop')
text = text.replace('else if (wait_ticks>=REVERSE_WAIT_TICKS-1)',
                    'else if (NO_FEEDBACK_GUARD && wait_ticks>=REVERSE_WAIT_TICKS-1)')
text = text.replace('if(reverse_ticks>=NO_FEEDBACK_TICKS-1)',
                    'if(NO_FEEDBACK_GUARD && reverse_ticks>=NO_FEEDBACK_TICKS-1)')
text = text.replace('if (pid_out>=100 && directed_speed<=-MIN_FEEDBACK)',
                    'if (NO_FEEDBACK_GUARD && pid_out>=100 && directed_speed<=-MIN_FEEDBACK)')
(b/'basic_wheel_speed_loop.v').write_text(text, encoding='utf-8')

text = (r/'src/uart_enc_debug.v').read_text(encoding='utf-8-sig')
text = text.replace('module uart_enc_debug', 'module basic_uart_debug')
text = text.replace('output wire        uart_tx',
                    'output wire [7:0] stream_data, output wire stream_valid,\n    output wire        uart_tx')
text = text.replace('    uart_tx #(',
                    '    assign stream_data=tx_data;\n    assign stream_valid=tx_send;\n    uart_tx #(')
(b/'basic_uart_debug.v').write_text(text, encoding='utf-8')

edit(b/'basic_tasks_top.v', 'input wire lidar_rx,',
     'input wire lidar_rx,\n input wire wireless_rx,wireless_rts,output wire wireless_tx,')
edit(b/'basic_tasks_top.v', 'wheel_speed_loop #(.KP(1229)',
     'basic_wheel_speed_loop #(.NO_FEEDBACK_GUARD(0),.KP(1229)')
edit(b/'basic_tasks_top.v', ' uart_enc_debug #(.DIAGNOSTIC_ENABLE(1)) serial',
     ' wire [7:0] wireless_data;wire wireless_valid;\n wireless_uart_bridge wireless(.clk(clk),.rst_n(rst_n),.stream_data(wireless_data),.stream_valid(wireless_valid),\n  .rx(wireless_rx),.rts(wireless_rts),.tx(wireless_tx));\n basic_uart_debug #(.DIAGNOSTIC_ENABLE(1)) serial')
edit(b/'basic_tasks_top.v', '.diagnostic_bits(diagnostics),.uart_tx(uart_tx));',
     '.diagnostic_bits(diagnostics),.stream_data(wireless_data),.stream_valid(wireless_valid),.uart_tx(uart_tx));')

text = (r/'n10_build/lidar_board.cst').read_text(encoding='utf-8-sig')
text += '''
// SEEKFREE V2.4: RX->P7-37, TX->P7-38, RTS->P7-39.
IO_LOC "wireless_tx" F18;
IO_LOC "wireless_rx" E18;
IO_LOC "wireless_rts" F19;
IO_PORT "wireless_tx" IO_TYPE=LVCMOS33 PULL_MODE=UP DRIVE=4 BANK_VCCIO=3.3;
IO_PORT "wireless_rx" IO_TYPE=LVCMOS33 PULL_MODE=UP BANK_VCCIO=3.3;
IO_PORT "wireless_rts" IO_TYPE=LVCMOS33 PULL_MODE=UP BANK_VCCIO=3.3;
'''
(b/'wireless_board.cst').write_text(text, encoding='utf-8')
edit(r/'basic_tasks.gprj', '<FileList>', '''<FileList>
        <File path="basic_tasks/basic_wheel_speed_loop.v" type="file.verilog" enable="1"/>
        <File path="basic_tasks/basic_uart_debug.v" type="file.verilog" enable="1"/>
        <File path="basic_tasks/wireless_uart_bridge.v" type="file.verilog" enable="1"/>''')
edit(r/'basic_tasks.gprj', 'path="n10_build/lidar_board.cst"', 'path="basic_tasks/wireless_board.cst"')
edit(b/'build.tcl', 'run all', 'set_option -user_code 000097B3\nrun all')
edit(b/'elaborate.do', '{basic_tasks/basic_tasks_top.v}',
     '{basic_tasks/basic_tasks_top.v} {basic_tasks/basic_wheel_speed_loop.v} {basic_tasks/basic_uart_debug.v} {basic_tasks/wireless_uart_bridge.v}')
edit(b/'elaborate.do', 'force -freeze /basic_tasks_top/key_n 1111',
     'force -freeze /basic_tasks_top/key_n 1111\nforce -freeze /basic_tasks_top/wireless_rx 1\nforce -freeze /basic_tasks_top/wireless_rts 1')
print('Prepared next release, 97A2 release files untouched')
