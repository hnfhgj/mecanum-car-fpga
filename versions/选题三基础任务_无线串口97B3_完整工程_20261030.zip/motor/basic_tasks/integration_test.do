onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/integration_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/n10_sincos.v pillar_nav/nav_math.v square_nav/square_project.v square_nav/square_map.v square_nav/square_grid_route.v basic_tasks/basic_clearance.v basic_tasks/basic_mission.v basic_tasks/basic_nav_drive.v basic_tasks/integration_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib basic_integration_tb
run -all
if {[examine -radix unsigned /basic_integration_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
