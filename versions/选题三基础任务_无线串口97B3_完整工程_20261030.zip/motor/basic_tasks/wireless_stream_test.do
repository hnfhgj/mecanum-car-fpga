onerror {quit -code 1 -f}
set lib [file normalize basic_tasks/wireless_stream_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/uart_tx.v src/uart_rx.v basic_tasks/basic_uart_debug.v basic_tasks/wireless_uart_bridge.v basic_tasks/wireless_stream_test.v
vsim -onfinish stop -voptargs=+acc -lib $lib wireless_stream_tb
run -all
if {[examine -radix unsigned /wireless_stream_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
