import queue,struct,time,unittest
from protocol import *
from transport import Link

FIXTURE='425402F1546042FF9C01F4232803E803E807D003E805DC07D009C409C43997F0'

class ProtocolTests(unittest.TestCase):
 def test_frame(self):
  p=encode(35,INFO,FIRMWARE)
  self.assertEqual(p,bytes.fromhex('A55A01230E97F000000000B90D0A'))
  self.assertEqual(len(p),14)
 def test_bounds(self):
  for v in [-1,65536,1.2]:
   with self.assertRaises(ValueError):encode(1,GOAL,v)
 def test_units(self):
  self.assertEqual(cm_to_mm('123.4'),1234)
  for v in ['nan','Infinity','1.23','-1','text','6553.6']:
   with self.assertRaises(ValueError):cm_to_mm(v)
 def test_speed(self):
  self.assertEqual([speed_level(str(v)) for v in range(25,151,25)],list(range(1,7)))
  for v in [0,100.0,'abc',151]:
   with self.assertRaises(ValueError):speed_level(v)
 def test_telemetry(self):
  kind,t=parse_line('IO HEX='+FIXTURE)
  self.assertEqual(kind,'task');self.assertEqual(t['firmware'],FIRMWARE)
  self.assertEqual((t['x_cm'],t['y_cm'],t['yaw_deg']),(-10,50,90))
  self.assertEqual((t['left_cm'],t['right_cm'],t['width_cm'],t['height_cm']),(150,200,250,250))
  self.assertEqual(t['speed_percent'],100);self.assertTrue(t['near']==False)
 def test_malformed(self):
  for s in ['IO HEX='+FIXTURE[:-2],'IO HEX=425401'+FIXTURE[6:],'@gg:00']:
   self.assertEqual(parse_line(s)[0],'text')
 def test_sensors(self):
  self.assertEqual(parse_line('ATT R=+00123 P=-00456 Y=+00999 OK=1')[1],dict(R=1.23,P=-4.56,Y=9.99,ready=True))
  kind,w=parse_line('LF=+00123 V=-00004 RF=+00002 V=+00003 LB=-00001 V=+00004 RB=+00000 V=-00002')
  self.assertEqual(kind,'wheels');self.assertEqual(w['LF'],dict(count=123,speed=-4))
 def test_queue_reject(self):
  q=CommandQueue();q.add([(GOAL,500,600,0),(GO,0,0,0)]);p=q.next_packet(0)
  self.assertFalse(q.acknowledge(p[3]+1,0));self.assertTrue(q.acknowledge(p[3],2));self.assertFalse(q.items)
 def test_queue_retry_stop(self):
  q=CommandQueue();q.add([(GO,0,0,0)]);p=q.next_packet(0)
  self.assertEqual(q.retry(1),p);self.assertEqual(q.retry(2),p)
  with self.assertRaises(TimeoutError):q.retry(3)
  q.add([(GO,0,0,0)]);q.emergency_stop();self.assertEqual(q.next_packet(4)[4],STOP)

class FakeSerial:
 def __init__(self,status=0):self.status=status;self.is_open=False;self.received=bytearray();self.writes=[]
 def open(self):self.is_open=True
 @property
 def in_waiting(self):return len(self.received)
 def write(self,data):
  self.writes.append(data)
  if data[4]!=HEARTBEAT:self.received.extend(f'@{data[3]:02X}:{self.status:02X}\r\n'.encode())
  return len(data)
 def read(self,n):b=bytes(self.received[:n]);del self.received[:n];return b
 def close(self):self.is_open=False

class WorkerTests(unittest.TestCase):
 def wait_event(self,q,kind,value,timeout=1):
  deadline=time.monotonic()+timeout
  while time.monotonic()<deadline:
   try:k,v=q.get(timeout=.1)
   except queue.Empty:continue
   if k==kind and v==value:return
  self.fail(f'Missing event {kind} {value}')
 def test_no_start_on_connect_and_close_stop(self):
  q=queue.Queue();dev=FakeSerial();link=Link(q,lambda:dev);link.connect('OFFLINE_FAKE')
  try:
   self.wait_event(q,'ready',True)
   self.assertEqual([p[4] for p in dev.writes if p[4]!=HEARTBEAT],[INFO])
   self.assertEqual(dev.writes[1] if dev.writes[0][4]==HEARTBEAT else dev.writes[0],encode(next(p[3] for p in dev.writes if p[4]==INFO),INFO,FIRMWARE))
  finally:link.close_event.set();link.thread.join(1)
  self.assertFalse(dev.is_open);self.assertEqual(dev.writes[-1][4],STOP)
 def test_wrong_firmware(self):
  q=queue.Queue();dev=FakeSerial(5);link=Link(q,lambda:dev);link.connect('OFFLINE_FAKE');link.thread.join(1)
  self.assertFalse(link.thread.is_alive());self.assertFalse(dev.is_open)
  self.assertFalse(any(p[4] in (MOTION,GO,ROUTE,APPROACH) for p in dev.writes))
 def test_submission(self):
  q=queue.Queue();dev=FakeSerial();link=Link(q,lambda:dev);link.connect('OFFLINE_FAKE')
  try:
   self.wait_event(q,'ready',True);link.submit([(SPEED,6,0,0)])
   deadline=time.monotonic()+1
   while not any(p[4]==SPEED for p in dev.writes) and time.monotonic()<deadline:time.sleep(.01)
   self.assertTrue(any(p[4]==SPEED and p[6]==6 for p in dev.writes))
   self.assertFalse(any(p[4]==MOTION for p in dev.writes))
  finally:link.close_event.set();link.thread.join(1)

if __name__=='__main__':unittest.main(verbosity=2)
