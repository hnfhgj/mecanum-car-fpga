"""Pure protocol/model helpers. Importing never opens serial or starts a task."""
import re
import struct
from collections import deque
from decimal import Decimal,InvalidOperation

STOP,PAGE,MOTION,APPROACH,CALIBRATE,GOAL,GO,POINT,ROUTE,GAINS,MENU,HEARTBEAT=range(12)
HELLO,SPEED,INFO=12,13,14
FIRMWARE=0x97F0
STATUS={0:'指令已接受',1:'任务运行中，请先停止再修改',2:'参数或坐标超出允许范围',3:'传感器或定位尚未就绪',4:'板上按键优先',5:'固件不支持此指令',6:'指令序号冲突，请重新操作'}
TASK_STATUS={0:'空闲',1:'等待准备',2:'未就绪',3:'可以出发',4:'运行中',5:'已结束，核对结果',6:'条件失效 / 超时',7:'已停止',8:'近障停车'}
PAGES=['编码器与姿态','航向参数','原始IMU','控制诊断','摄像头','实时雷达']

def encode(seq,op,a=0,b=0,c=0):
    if not 0<=seq<=255 or not 0<=op<=255 or any(not isinstance(v,int) or not 0<=v<=65535 for v in (a,b,c)):
        raise ValueError('指令参数必须为范围内整数')
    body=struct.pack('>BBBHHH',1,seq,op,a,b,c)
    return b'\xa5\x5a'+body+bytes([sum(body)&255])+b'\r\n'

def cm_to_mm(value):
    try:number=Decimal(str(value))*10
    except InvalidOperation:raise ValueError('坐标请输入数字')
    if not number.is_finite() or number!=number.to_integral_value() or not 0<=number<=65535:
        raise ValueError('坐标精度为1毫米，请输入有效范围内的厘米数值')
    return int(number)

def speed_level(percent):
    try:value=int(percent)
    except (ValueError,TypeError):raise ValueError('速度倍率必须为25%～150%，每档25%')
    if str(value)!=str(percent).strip() or value not in range(25,151,25):raise ValueError('速度倍率必须为25%～150%，每档25%')
    return value//25

def parse_line(line):
    line=line.strip()
    match=re.fullmatch(r'@([0-9A-Fa-f]{2}):([0-9A-Fa-f]{2})',line)
    if match:return 'ack',(int(match[1],16),int(match[2],16))
    if re.fullmatch(r'IO HEX=(?:[0-9A-Fa-f]{64}|[0-9A-Fa-f]{42})',line):
        data=bytes.fromhex(line[7:])
        if data[:3] not in (b'BT\x01',b'BT\x02'):return 'text',line
        if (data[:3]==b'BT\x02')!=(len(data)==32):return 'text',line
        flags=data[3];x,y,yaw,tx,ty,front,back=struct.unpack('>hhhHHHH',data[7:21])
        result=dict(active=bool(flags&2),calibrated=bool(flags&32),radar=bool(flags&16),pose=bool(flags&8),can_go=bool(flags&4),
                    demo_running=bool(flags&128),mission_running=bool(flags&64),heading_ready=bool(flags&1),
                    demo=data[4]>>4,mission=data[4]&15,waypoint=1+((data[5]>>2)&3),route=bool(data[5]&16),group=data[5]>>5,
                    x_cm=x/10,y_cm=y/10,yaw_deg=yaw/100,goal_x_cm=tx/10,goal_y_cm=ty/10,front_cm=front/10,back_cm=back/10,
                    speed_percent=((data[6]>>4)&7)*25 if data[:3]==b'BT\x02' else None)
        if len(data)==32:
            left,right,width,height=struct.unpack('>HHHH',data[21:29]);aux=data[29]
            result.update(left_cm=left/10,right_cm=right/10,width_cm=width/10,height_cm=height/10,
                          nav=aux>>4,slow_seen=bool(aux&8),stop_seen=bool(aux&4),near=bool(aux&2),imu_fresh=bool(aux&1),
                          firmware=int.from_bytes(data[30:32],'big'))
        return 'task',result
    if line.startswith('ATT '):
        values=dict(re.findall(r'([RPY])=([+-]\d+)',line));return 'attitude',{**{k:int(v)/100 for k,v in values.items()},'ready':'OK=1' in line}
    if line.startswith('LF='):
        rows=re.findall(r'(LF|RF|LB|RB)=([+-]\d+) V=([+-]\d+)',line)
        if len(rows)==4:return 'wheels',{k:dict(count=int(c),speed=int(s)) for k,c,s in rows}
    if line.startswith('IMU_INIT='):
        return 'sensors',{k:bool(int(v)) for k,v in re.findall(r'(IMU_INIT|IMU_NEW|TOF_INIT|TOF_NEW)=([01])',line)}
    if line.startswith('AX='):
        return 'imu',{k:int(v) for k,v in re.findall(r'([AG][XYZ])=([+-]\d+)',line)}
    if line.startswith('PID '):
        m=re.search(r'RUN=([01]{4}) FAULT=([01]{4})',line)
        if m:return 'pid',dict(run=m[1],fault=m[2])
    return 'text',line

class CommandQueue:
    def __init__(self):self.items=deque();self.pending=None;self.seq=0
    def add(self,commands):
        if self.items or self.pending:raise ValueError('上一组指令尚未确认，请等待或停止')
        self.items.extend(commands)
    def emergency_stop(self):self.items.clear();self.pending=None;self.items.append((STOP,0,0,0))
    def next_packet(self,now):
        if self.pending or not self.items:return None
        self.seq=(self.seq+1)&255;packet=encode(self.seq,*self.items.popleft())
        self.pending=dict(seq=self.seq,packet=packet,last=now,retries=0);return packet
    def acknowledge(self,seq,status):
        if not self.pending or seq!=self.pending['seq']:return False
        self.pending=None
        if status:self.items.clear()
        return True
    def retry(self,now):
        if not self.pending or now-self.pending['last']<1:return None
        if self.pending['retries']>=2:self.items.clear();self.pending=None;raise TimeoutError('指令确认超时，已取消后续操作')
        self.pending['last']=now;self.pending['retries']+=1;return self.pending['packet']
