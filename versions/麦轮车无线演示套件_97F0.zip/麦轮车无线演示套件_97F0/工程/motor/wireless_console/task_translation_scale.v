// 25%-step translation scale. Shift/add only; no DSP, no heading scaling.
module task_translation_scale(input wire [6:0] base,input wire [2:0] level,output wire [15:0] scaled);
 reg [9:0] product;
 wire [9:0] value={3'd0,base};
 always @*case(level)
  1:product=value;
  2:product=value<<1;
  3:product=(value<<1)+value;
  5:product=(value<<2)+value;
  6:product=(value<<2)+(value<<1);
  default:product=value<<2;
 endcase
 assign scaled={8'd0,product[9:2]};
endmodule
