set root [file normalize [file join [file dirname [info script]] ..]]
cd $root
open_project [file join $root wireless_console.gprj] -pn GW5AT-LV60PG484AC1/I0 -device_version B
set_option -top_module wireless_console_top
set_option -output_base_name wireless_console
set_option -use_sspi_as_gpio 1
set_option -place_option 1
set_option -route_option 1
set_option -timing_driven 1
set_option -user_code 000097F0
run all
set build_name wireless_console
source [file join $root pillar_nav timing_check.tcl]
exit
