import unittest,tkinter as tk,time,types
from unittest.mock import Mock,patch
from controller import App
from protocol import *
from local_navigation import Snapshot

class GuiTests(unittest.TestCase):
 def setUp(self):
  self.root=tk.Tk();self.root.withdraw();self.a=App(self.root,demo=True,enumerate_ports=False);self.root.update_idletasks()
  self.assertIsNone(self.a.worker.thread)
  self.a.worker=types.SimpleNamespace(command=Mock(),close=Mock(),thread=None)
 def tearDown(self):
  self.assertIsNone(self.a.link.thread)
  for ident in self.root.tk.splitlist(self.root.tk.call('after','info')):self.root.after_cancel(ident)
  self.root.destroy()
 def ready(self):
  a=self.a;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic();a.current='radar'
  a.task.update(calibrated=False,pose=False,can_go=False,near=True,radar=False,active=False,manual=False)
  a.local=Snapshot((0,0,0),True,5,'有效',time.monotonic(),10,rms=1,support=100)
  a.held_input=types.SimpleNamespace(foreground=lambda:True,mask=lambda:1);return a
 def test_ready_without_frame(self):
  a=self.ready();self.assertTrue(a.available('local_go'));self.assertFalse(a.task['calibrated'])
 def test_start_uses_local_worker_never_legacy_go(self):
  a=self.ready();a.send=Mock();a.goal(True)
  self.assertTrue(a.local_run);a.send.assert_not_called();self.assertEqual(a.worker.command.call_args_list[-1].args,('start',))
 def test_select_does_not_start(self):
  a=self.ready();a.goal(False);self.assertFalse(a.local_run)
  self.assertEqual(a.worker.command.call_args_list[-1].args,('target',(0,100)))
 def test_body_click_is_fixed_in_reference(self):
  a=self.ready();a.local.pose=(40,20,90);c=a.radar_canvas;a.draw_world(c);cx,cy,scale,body=c._local_transform
  a.map_click(c,types.SimpleNamespace(x=cx,y=cy-100*scale))
  self.assertEqual(a.local_goal,(-60,20));self.assertFalse(a.local_run)
 def test_manual_release_and_speed_focus_regression(self):
  a=self.ready();a.manual_armed.set(True);a.root.focus_set=Mock();a.speed_choice.set('150');a.apply_speed()
  a.on_command_sent(dict(seq=25,op=SPEED));a.on_command_ack(dict(seq=25,status=0));a.pending=False
  self.assertTrue(a.manual_armed.get());a.root.focus_set.assert_called_once()
  a._poll_drive_once();self.assertEqual(a.link.drive_state[0],0)
  a.held_input.mask=lambda:0;a._poll_drive_once();a.held_input.mask=lambda:1;a._poll_drive_once();self.assertEqual(a.link.drive_state[0],1)
 def test_navigation_only_uses_post_start_fresh_decision(self):
  a=self.ready();a.local_run=True;now=time.monotonic();a.local_started=now-.05;a.local.stamp=now-.01;a.local.mask=1;a.local.until=now+.1
  a._poll_drive_once();self.assertEqual(a.link.drive_state[0],1)
  a.local.stamp=now-.1;a._poll_drive_once();self.assertEqual(a.link.drive_state[0],0)
 def test_expired_pulse_sends_zero(self):
  a=self.ready();a.local_run=True;a.local_started=time.monotonic()-.1;a.local.mask=1;a.local.until=time.monotonic()-.01
  a._poll_drive_once();self.assertEqual(a.link.drive_state[0],0)
 def test_focus_loss_cancels_navigation(self):
  a=self.ready();a.local_run=True;a.held_input.foreground=lambda:False;a._poll_drive_once()
  self.assertFalse(a.local_run);self.assertEqual(a.link.drive_state[0],0)
 def test_stale_telemetry_cancels_navigation(self):
  a=self.ready();a.local_run=True;a.last_task=time.monotonic()-1;a._poll_drive_once();self.assertFalse(a.local_run)
 def test_stop_cancels_both_modes(self):
  a=self.ready();a.local_run=True;a.manual_armed.set(True);a.stop()
  self.assertFalse(a.local_run);self.assertFalse(a.manual_armed.get());self.assertEqual(a.link.drive_state[0],0)
 def test_old_frame_motion_commands_are_disabled_in_pc(self):
  a=self.ready();a.link.submit=Mock();a.send([(CALIBRATE,0,0,0)]);a.send([(GO,0,0,0)]);a.link.submit.assert_not_called()
 def test_nav_failure_requires_new_start(self):
  a=self.ready();a.local_run=True;now=time.monotonic();a.local_started=now-.1
  a.ingest('local_nav',Snapshot((0,0,0),False,0,'定位失效',now,11));self.assertFalse(a.local_run)
 def test_bad_target_not_submitted(self):
  a=self.ready();a.goal_x.set('nan')
  with patch('controller.messagebox.showerror') as err:a.goal(True);err.assert_called_once()
  self.assertFalse(a.local_run)
 def test_switching_to_settings_cancels_navigation(self):
  a=self.ready();a.local_run=True;a.show('settings');self.assertFalse(a.local_run)
 def test_stale_cloud_not_drawn_as_live(self):
  a=self.ready();a.cloud_time=time.monotonic()-2;a.draw_world(a.radar_canvas)
  self.assertFalse(a.radar_canvas.find_withtag('candidate_frame'))
 def test_radius_preserves_measurements(self):
  a=self.ready();pts=list(a.cloud['points']);c=a.radar_canvas;a.radar_radius.set('100');a.draw_world(c);s=c._local_transform[2]
  a.radar_radius.set('500');a.draw_world(c);self.assertAlmostEqual(s/c._local_transform[2],5);self.assertEqual(pts,a.cloud['points'])
 def test_reset_only_when_idle(self):
  a=self.ready();a.task['active']=True;self.assertFalse(a.available('local_reset'))
  a.task['active']=False;a.reset_local();self.assertFalse(a.local.valid);self.assertIsNone(a.local_goal)

if __name__=='__main__':unittest.main(verbosity=2)
