from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent;r=p.parent
m=json.loads((r/'navigation_tuning/release/manifest.json').read_text(encoding='utf-8'))
for name,h in m['inputs'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest().upper()==h,name
s=(r/'navigation_tuning/navigation_tuning_top.v').read_text(encoding='utf-8').replace('module navigation_tuning_top #(','module free_navigation_top #(').replace("16'h97F3","16'h97F4")
(p/'free_navigation_top.v').write_text(s,encoding='utf-8')
(p/'pc_ui.v').write_text((r/'navigation_tuning/pc_ui.v').read_text(encoding='utf-8').replace("16'h97F3","16'h97F4"),encoding='utf-8')
s=(r/'drive_speedup/hold_drive.v').read_text(encoding='utf-8')
# Lookup tables preserve exact floor(round baseline boost * level / 4).
for a,b in [(127,222),(106,185),(84,148),(63,110),(42,74),(21,36),(180,315),(150,262),(120,210),(90,157),(60,105),(30,52)]:
 s=re.sub(r'(?<!\w)'+str(a)+r'(?!\w)',str(b),s)
s=s.replace('floor(210*level/4)','floor(210*level/4)')
(p/'hold_drive.v').write_text(s,encoding='utf-8')
s=(r/'drive_speedup/task_translation_scale.v').read_text(encoding='utf-8')
s=s.replace('reg [9:0] product','reg [12:0] product').replace('reg [9:0] value','reg [12:0] value')
s=s.replace('15:value=20;30:value=40;45:value=60;60:value=80;90:value=120;', '15:value=35;30:value=70;45:value=105;60:value=140;90:value=210;')
s=s.replace("default:value={3'd0,base};","default:value=({6'd0,base}*7)/4;")
s=s.replace("{8'd0,product[9:2]}","{5'd0,product[12:2]}").replace('increase by 4/3','increase by 4/3 then 7/4')
(p/'task_translation_scale.v').write_text(s,encoding='utf-8')
s=(r/'navigation_tuning.gprj').read_text(encoding='utf-8')
for a,b in [('navigation_tuning/navigation_tuning_top.v','free_navigation/free_navigation_top.v'),('navigation_tuning/pc_ui.v','free_navigation/pc_ui.v'),('drive_speedup/hold_drive.v','free_navigation/hold_drive.v'),('drive_speedup/task_translation_scale.v','free_navigation/task_translation_scale.v')]:
 assert a in s;s=s.replace(a,b)
(r/'free_navigation.gprj').write_text(s,encoding='utf-8')
s=(r/'navigation_tuning/build.tcl').read_text(encoding='utf-8').replace('navigation_tuning','free_navigation').replace('000097F3','000097F4')
(p/'build.tcl').write_text(s,encoding='utf-8')
print('Prepared 97F4 translation x1.75, rotation110/PWM882 preserved. PC navigation will not call legacy frame commands.')
