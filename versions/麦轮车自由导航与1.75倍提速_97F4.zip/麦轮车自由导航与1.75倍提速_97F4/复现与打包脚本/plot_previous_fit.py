from pathlib import Path
import sys,math,json
from PIL import Image,ImageDraw,ImageFont
w=Path(__file__).resolve().parents[2];sys.path.insert(0,str(w/'麦轮控制台_97F4'))
from protocol import parse_line
from local_navigation import rotate,fit_rectangle
data=w/'motor/navigation_tuning/hardware_97F3'
lines=(data/'calibration.txt').read_text(encoding='utf-8').splitlines()
scans=[v for k,v in map(parse_line,lines) if k=='scan'];task=json.loads((data/'calibration.json').read_text(encoding='utf-8'))['lastTask']
pts=scans[-1]['points'];r=fit_rectangle(pts)
img=Image.new('RGB',(1200,900),'#0B1220');d=ImageDraw.Draw(img)
font=lambda n:ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',n)
title=font(26);small=font(18);cx,cy,scale=600,450,1.35
d.text((35,20),'实采雷达点云与旧版拟合边框对照',font=title,fill='#ECF3FF')
d.text((35,62),'来源：97F3 静止建系检查，最后一帧；只用于诊断，未核对场地实物尺寸。',font=small,fill='#99AAC4')
def xy(x,y):return cx+x*scale,cy-y*scale
for n in range(-250,251,50):
 x,y=xy(n,0);d.line((x,110,x,790),fill='#283952');d.text((x+3,cy+5),str(n),font=small,fill='#99AAC4')
 x,y=xy(0,n);d.line((200,y,1000,y),fill='#283952')
for a,rng in pts:
 x,y=rotate(0,rng,-a)
 if abs(x)>285 or abs(y)>250:continue
 sx,sy=xy(x,y);d.ellipse((sx-3,sy-3,sx+3,sy+3),fill='#48DFC1')
corners=[]
for x,y in [(0,0),(task['width_cm'],0),(task['width_cm'],task['height_cm']),(0,task['height_cm'])]:
 rx,fy=rotate(x-task['x_cm'],y-task['y_cm'],-(task['yaw_deg']-90));corners.append(xy(rx,fy))
d.line(corners+[corners[0]],fill='#FF6978',width=3)
d.polygon([(cx,cy-12),(cx-9,cy+9),(cx+9,cy+9)],fill='#62ACFF')
d.text((cx+15,cy-24),'车头↑',font=small,fill='#62ACFF')
d.text((35,810),'绿色：实采点云   红色：旧版报告的约109×96cm框   网格：50cm',font=small,fill='#ECF3FF')
d.text((35,846),'新连续性/角点检查：该帧未确认闭合四边，不强行报告可信边框。' if r is None else str(r),font=small,fill='#F2C36A')
out=w/'motor/free_navigation/旧版边框误配对照.png';img.save(out);print(str(out))
