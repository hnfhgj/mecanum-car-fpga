from pathlib import Path
import hashlib,json,shutil,zipfile
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent;release=p/'release'
m=json.loads((release/'manifest.json').read_text(encoding='utf-8'));sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
assert sha(release/m['firmware'])==m['sha256']
out=w/'麦轮车自由导航与1.75倍提速_97F4';out.mkdir(exist_ok=True)
def copy(src,rel):
 dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for name,h in m['inputs'].items():assert sha(r/name)==h;copy(r/name,Path('工程/motor')/name)
for name in ['free_navigation.gprj','free_navigation/build.tcl','pillar_nav/timing_check.tcl']:copy(r/name,Path('工程/motor')/name)
for name,h in m['testInputs'].items():assert sha(p/name)==h;copy(p/name,Path('工程/motor/free_navigation')/name)
for name in ['prepare.py','prepare_tests.py','plot_previous_fit.py','release.py','package.py']:copy(p/name,Path('复现与打包脚本')/name)
for f in release.iterdir():
 if f.is_file():copy(f,Path('固件与验证')/f.name)
for f in p.glob('*_tb.log'):copy(f,Path('固件与验证/仿真记录')/f.name)
for name in ['replay.json','旧版边框误配对照.png']:copy(p/name,Path('固件与验证')/name)
copy(r/'navigation_tuning/release/navigation_tuning_97F3.fs','回退97F3/已验证97F3.fs')
for f in (w/'麦轮控制台_97F3').iterdir():
 if f.suffix in ('.py','.cmd','.md','.txt'):copy(f,Path('回退97F3/电脑控制台')/f.name)
gui=w/'麦轮控制台_97F4'
for name,h in m['guiInputs'].items():assert sha(gui/name)==h;copy(gui/name,Path('电脑控制台_97F4')/name)
for name in ['python_tests.log','gui_smoke.log']:copy(gui/name,Path('固件与验证')/name)
copy(gui/'使用说明.md','先读我.md')
(out/'固件与验证/烧录说明.md').write_text('''# 97F4尚未烧录

当前Flash和桌面入口仍为97F3。等待用户确认准备好后再写Flash。
固件free_navigation_97F4.fs，UserCode000097F4，GW5AT-60B PBGA484A，真实器件ID0001481B。
工程/motor/free_navigation.gprj，顶层free_navigation/free_navigation_top.v。
在工程/motor运行gw_sh.exe free_navigation/build.tcl。布局2/布线2，50MHz setup/hold均需零违例。

Flash擦写、校验、重载并读回97F4后，再换桌面入口到电脑控制台_97F4/controller.py。
平移目标1.75倍；旋转、PID、PWM约30%上限、引脚与轮序保留。
电脑任务4为免矩形建系的局部点选导航，需要电脑和无线持续在线。
此包只通过离线测试；实车绕障与到点效果尚未验证。
回退97F3包含原固件和匹配控制台。
''',encoding='utf-8')
entries={f.relative_to(out).as_posix():sha(f) for f in out.rglob('*') if f.is_file() and f.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding='utf-8')
archive=w/'麦轮车自由导航与1.75倍提速_97F4.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in out.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in entries.items():assert hashlib.sha256(z.read(out.name+'/'+name)).hexdigest().upper()==h
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,files=len(entries)+1),ensure_ascii=True,indent=2))
