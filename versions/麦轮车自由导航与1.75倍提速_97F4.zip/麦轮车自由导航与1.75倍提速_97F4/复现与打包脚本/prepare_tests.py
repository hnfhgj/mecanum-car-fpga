from pathlib import Path
import re,shutil
p=Path(__file__).resolve().parent;r=p.parent
for name in ['top_tb.sv','control_tb.v','stream_tb.sv','cloud_stream_tb.sv','snapshot_tb.sv','manual_tb.sv','hold_top_tb.sv','speed_tb.sv','nav_tb.v','frame_tb.v']:
 s=(r/'navigation_tuning'/name).read_text(encoding='utf-8').replace('navigation_tuning_top','free_navigation_top').replace('97F3','97F4')
 if name=='top_tb.sv':s=s.replace("byte_send('hf3)","byte_send('hf4)").replace("byte_send('hbc)","byte_send('hbd)")
 if name in ('manual_tb.sv','hold_top_tb.sv'):
  s=re.sub(r'(?<!\w)(120|84|168)(?!\w)',lambda m:{'120':'210','84':'148','168':'296'}[m[0]],s)
  s=s.replace('(210*i/4*181)/256','diag(i)')
  if name=='manual_tb.sv':
   s=s.replace('initial begin', '''function integer diag(input integer v);begin case(v)
1:diag=36;2:diag=74;3:diag=110;5:diag=185;6:diag=222;default:diag=148;endcase end endfunction
initial begin''',1)
 if name=='speed_tb.sv':
  s=s.replace('0:boosted=0;15:boosted=20;30:boosted=40;45:boosted=60;60:boosted=80;90:boosted=120;default:boosted=value;',
   '0:boosted=0;15:boosted=35;30:boosted=70;45:boosted=105;60:boosted=140;90:boosted=210;default:boosted=value*7/4;')
  s=s.replace('120*l/4','210*l/4').replace('v<=90','v<=127').replace('all 0..90 inputs','all 0..127 inputs')
 if name=='nav_tb.v':
  s=re.sub(r'(?<=[!=]=)(-?)(20|40|60|80|120)(?!\d)',lambda m:m[1]+{'20':'35','40':'70','60':'105','80':'140','120':'210'}[m[2]],s)
 (p/name).write_text(s,encoding='utf-8')
for name in ['frame_fixture.txt','frame_live.txt','frame_missing.txt']:shutil.copy2(r/'navigation_tuning'/name,p/name)
s=(r/'navigation_tuning/run_tests.ps1').read_text(encoding='utf-8').replace('navigation_tuning.gprj','free_navigation.gprj').replace('navigation_97F3','free_97F4')
(p/'run_tests.ps1').write_text(s,encoding='utf-8')
print('Prepared 13 offline RTL tests for 97F4, wider products and all speed levels.')
