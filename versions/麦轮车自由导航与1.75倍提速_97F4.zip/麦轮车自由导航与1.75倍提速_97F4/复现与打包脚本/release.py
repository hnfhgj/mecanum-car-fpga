"""Strict 97F4 offline release gate: build, unchanged pins and complete tests."""
from pathlib import Path
import hashlib,json,re,shutil,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent;pnr=r/'impl/pnr'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
base=json.loads((r/'navigation_tuning/release/manifest.json').read_text(encoding='utf-8'))
for name,h in base['inputs'].items():assert sha(r/name)==h,'97F3 baseline changed: '+name
assert sha(r/'navigation_tuning/release'/base['firmware'])==base['sha256']
tree=ET.fromstring((r/'free_navigation.gprj').read_text(encoding='utf-8').replace('version="1"','version="1.0"'))
paths=[f.get('path') for f in tree.findall('.//File') if f.get('enable')=='1']+['src/imu660ra_config.hex','src/dl1b_config.hex']
old={'navigation_tuning/navigation_tuning_top.v','navigation_tuning/pc_ui.v','drive_speedup/hold_drive.v','drive_speedup/task_translation_scale.v'}
new={'free_navigation/'+v+'.v' for v in ['free_navigation_top','pc_ui','hold_drive','task_translation_scale']}
assert len(paths)==len(set(paths)) and set(paths)==(set(base['inputs'])-old)|new
tests=['pc_control_tb','pc_bridge_tb','wireless_top_tb','wireless_stream_tb','speed_tb','basic_nav_tb','pc_motor_pipeline_tb','manual_tb','directional_tb','cloud_stream_tb','snapshot_tb','hold_top_tb','square_frame_tb']
for test in tests:
 log=(p/(test+'.log')).read_text(encoding='utf-8-sig');assert 'PASS ' in log and not re.search('Fatal:|ERROR:',log),test
assert 'all 0..127 inputs' in (p/'speed_tb.log').read_text(encoding='utf-8-sig')
gui=w/'麦轮控制台_97F4'
log=(gui/'python_tests.log').read_text(encoding='utf-8-sig');assert 'Ran 70 tests' in log and re.search(r'\nOK\s*$',log)
assert 'PASS GUI' in (gui/'gui_smoke.log').read_text(encoding='utf-8-sig')
assert 'PASS: free_navigation setup/hold violations zero' in (p/'build.log').read_text(encoding='utf-8-sig')
fs=pnr/'free_navigation.fs';header='\n'.join(fs.read_text(encoding='ascii').splitlines()[:18])
assert '//Device-package: GW5AT-60B-PBGA484A' in header
assert re.search(r'//UserCode:\s+0x([0-9A-Fa-f]+)',header)[1].upper()=='000097F4'
assert all((r/f).stat().st_mtime<=fs.stat().st_mtime for f in paths),'Source newer than build'
timing=(pnr/'free_navigation_tr_content.html').read_text(encoding='utf-8-sig')
for kind in ('Setup','Hold'):assert re.search(r'Numbers of '+kind+r' Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>',timing)[1]=='0'
pins=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;',(r/'basic_tasks/wireless_board.cst').read_text(encoding='utf-8-sig')))
assert len(pins)==56 and len(set(pins.values()))==56
actual={}
for line in (pnr/'free_navigation.rpt.txt').read_text(encoding='utf-8-sig').splitlines():
 fields=[s.strip() for s in line.split('|')]
 if len(fields)>4 and fields[0] in pins:
  assert fields[3]=='Y';actual[fields[0]]=fields[2].split('/')[0]
assert actual==pins
top=(p/'free_navigation_top.v').read_text(encoding='utf-8');hold=(p/'hold_drive.v').read_text(encoding='utf-8')
assert top.count('.MAX_TURN(110)')==3 and '.MAX_DUTY(882)' in top
assert '.NO_FEEDBACK_GUARD(0)' in top and '.FIXED_ENCODER_SIGN(1)' in top
assert 'straight_pos<=210' in hold and 'straight_pos<=315' in hold and "16'sd110:-16'sd110" in hold
replay=json.loads((p/'replay.json').read_text(encoding='utf-8'))
assert replay['valid']==replay['scans']==44 and not replay['anyMotionCommand']
out=p/'release';out.mkdir(exist_ok=True);dest=out/'free_navigation_97F4.fs'
if dest.exists():assert sha(dest)==sha(fs),'Immutable firmware differs'
else:shutil.copy2(fs,dest)
for f,name in [(pnr/'free_navigation_tr_content.html','timing.html'),(pnr/'free_navigation.rpt.txt','pnr.txt'),(p/'build.log','build.log')]:shutil.copy2(f,out/name)
m=dict(firmware=dest.name,userCode='000097F4',sha256=sha(dest),setup=0,hold=0,ports=56,baseline='97F3',
 hardwareProgrammed=False,integratedHardwareVerified=False,navigationMotionTested=False,rtlSimulations=len(tests),pythonTests=70,placeOption=2,routeOption=2,
 pcNavigationRequiresRectangle=False,pcMustRemainConnected=True,positionSource='scan-to-line translation + IMU yaw, temporary local reference',
 candidateFrameRequiresCoverageAndCorners=True,goalFixedInLocalReference=True,plannerCellCm=10,arrivalToleranceCm=12,arrivalConfirmScans=3,
 unknownSpaceBlocked=True,diagonalCornerCutPrevented=True,actualDriveMaskSweptPathChecked=True,duplicateScansStop=True,
 translationGainFrom97F3=1.75,translationDefault=210,translationTargets=[52,105,157,210,262,315],spinMaxTurn=110,pwmMaxCounts=882,
 manualRequiresFieldCalibration=False,legacyFpgaFrameMenuRetained=True,
 inputs={f:sha(r/f) for f in paths},guiInputs={f.name:sha(f) for f in gui.iterdir() if f.suffix in ('.py','.cmd','.md','.txt')},
 testInputs={f.name:sha(f) for f in p.iterdir() if f.suffix in ('.sv','.v','.ps1','.txt') and not f.name.endswith('.rpt.txt')})
(out/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v for k,v in m.items() if k not in ('inputs','guiInputs','testInputs')},indent=2))
