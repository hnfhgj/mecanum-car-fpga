# Re-synthesize the corrected packet/display boundary, then reuse the same
# complete physical checkpoint. No clock relaxation or broad timing exceptions.
set root [file normalize [file join [file dirname [info script]] ..]]
cd $root
set marker [file join $root pillar_nav final_build.ok]
if {[file exists $marker]} {file rename -force $marker ${marker}.previous}
open_project [file join $root pillar_navigation.gprj] -pn GW5AT-LV60PG484AC1/I0 -device_version B
set_option -top_module pillar_nav_top
set_option -output_base_name pillar_final
set_option -use_sspi_as_gpio 1
set_option -place_option 1
set_option -route_option 1
set_option -timing_driven 1
run syn
set_option -inc_pnr auto
run pnr
set build_name pillar_final
source [file join $root pillar_nav timing_check.tcl]
set f [open $marker w]
puts $f "Corrected navigation build approved [clock format [clock seconds]]"
close $f
exit
