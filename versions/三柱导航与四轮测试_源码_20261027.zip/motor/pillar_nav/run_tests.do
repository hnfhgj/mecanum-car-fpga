onerror {quit -code 1 -f}
set lib [file normalize pillar_nav/test_work]
if {![file isdirectory $lib]} {vlib $lib}
eval vlog -sv -work $lib [glob src/*.v] [glob pillar_nav/*.v] [glob pillar_nav/tests/*.v]
foreach test {math_tb pose_tb control_tb features_tb ui_tb renderer_tb demo_tb} {
 vsim -onfinish stop -voptargs=+acc -lib $lib $test
 run -all
 if {[examine -radix unsigned /$test/passed] != 1} {quit -code 1 -f}
 quit -sim
}
quit -code 0 -f
