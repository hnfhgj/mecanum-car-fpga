onerror {quit -code 1 -f}
set lib [file normalize pillar_nav/test_work]
eval vlog -sv -work $lib [glob src/*.v] [glob pillar_nav/*.v] pillar_nav/tests/uart_navigation_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib uart_navigation_tb
run -all
if {[examine -radix unsigned /uart_navigation_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
