onerror {quit -code 1 -f}
set lib [file normalize pillar_nav/test_work]
eval vlog -sv -work $lib [glob src/*.v] [glob pillar_nav/*.v]
vsim -voptargs=+acc -gUSE_EXTERNAL_OSC=1 -lib $lib pillar_nav_top
force -freeze /pillar_nav_top/clk 0 0ns,1 10ns -repeat 20ns
force -freeze /pillar_nav_top/rst_n 0
run 100ns
force -freeze /pillar_nav_top/rst_n 1
run 1000ns
foreach pin {lf_pwm rf_pwm lb_pwm rb_pwm} {
 if {[examine -radix unsigned /pillar_nav_top/$pin] != 0} {error "Unexpected boot motor output"}
}
puts "PASS full navigation top elaborates and all boot PWM outputs stay zero"
quit -code 0 -f
