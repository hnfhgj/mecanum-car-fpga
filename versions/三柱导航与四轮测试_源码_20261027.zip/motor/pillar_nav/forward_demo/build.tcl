set root [file dirname [file normalize [info script]]]
cd $root
open_project [file join $root demo.gprj] -pn GW5AT-LV60PG484AC1/I0 -device_version B
set_option -top_module forward_demo_top
set_option -output_base_name four_forward
set_option -use_sspi_as_gpio 1
set_option -place_option 1
set_option -route_option 1
run all
set build_name four_forward
source [file join $root .. timing_check.tcl]
exit
