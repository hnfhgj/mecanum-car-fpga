`timescale 1ns/1ps
module nav_camera_capture_tb;
    reg clk=0, pclk=0, rst_n=0, enable=1;
    always #10 clk=~clk;
    always #17 pclk=~pclk;
    reg vsync=0, href=0;
    reg [7:0] data=0;
    reg [14:0] rd_addr=0;
    reg display_frame_start=0, display_frame_end=0;
    wire [15:0] rd_pixel;
    wire frame_valid;
    reg passed=0;
    nav_camera_capture #(.STALE_CYCLES(400000)) dut(.*);
    task tick(input bit v,input bit h,input [7:0] d);
        @(negedge pclk); vsync=v; href=h; data=d;
    endtask
    function [15:0] pixel(input integer seed,input integer addr);
        pixel = (seed ^ (addr*37)) & 16'hffff;
    endfunction
    // kind: 0 valid,1 odd/short line,2 overlong line,3 short frame,4 extra line.
    task send_frame(input integer seed,input integer kind);
        integer y,x,n,addr;
        reg [15:0] px;
        tick(1,0,0); repeat(3) tick(1,0,0);
        tick(0,0,0); tick(0,0,0);
        for(y=0;y<(kind==3?127:kind==4?129:128);y=y+1) begin
            n=(kind==1 && y==3)?319:(kind==2 && y==3)?322:320;
            for(x=0;x<n;x=x+1) begin
                addr=y*160+x/2; px=pixel(seed,addr);
                tick(0,1,x%2 ? px[7:0] : px[15:8]);
            end
            if(kind==5 && y==127)begin tick(1,0,0);tick(1,0,0);end
            else begin tick(0,0,0);tick(0,0,0);end
        end
        tick(1,0,0); repeat(10) tick(1,0,0);
    endtask
    task pulse_start;
        @(negedge clk); display_frame_start=1;
        @(negedge clk); display_frame_start=0;
    endtask
    task pulse_end;
        @(negedge clk); display_frame_end=1;
        @(negedge clk); display_frame_end=0;
    endtask
    task check_frame(input integer seed);
        integer a;
        for(a=0;a<20480;a=a+1) begin
            @(negedge clk); rd_addr=a;
            @(posedge clk); #1;
            if(rd_pixel !== pixel(seed,a))
                $fatal(1,"pixel seed=%h addr=%d got=%h expected=%h",seed,a,rd_pixel,pixel(seed,a));
        end
    endtask
    reg token, bank;
    integer kind;
    initial begin
        #103 rst_n=1;
        repeat(10) @(posedge pclk);
        if(frame_valid) $fatal(1,"half/uninitialized frame valid");
        for(kind=1;kind<=4;kind=kind+1) begin
            send_frame(16'h1111,kind);
            if(dut.request !== 0 || frame_valid) $fatal(1,"malformed accepted kind %d",kind);
        end
        send_frame(16'h1234,0);
        if(frame_valid) $fatal(1,"valid before display adoption");
        pulse_start(); repeat(5) @(posedge clk);
        if(!frame_valid) $fatal(1,"valid frame not adopted");
        check_frame(16'h1234);
        send_frame(16'habcd,0); // next bank ready while display A active
        token=dut.request; bank=dut.front_bank;
        pulse_start(); // overlapping START must not switch
        if(dut.front_bank !== bank) $fatal(1,"front changed inside display frame");
        send_frame(16'hdead,0); // both front and ready owned: drop entire frame
        if(dut.request !== token) $fatal(1,"pending bank overwritten");
        check_frame(16'h1234);
        pulse_end(); pulse_start(); repeat(5) @(posedge clk);
        check_frame(16'habcd);
        send_frame(16'h1357,5); // last RAM write and request toggle share an edge
        pulse_end();pulse_start();repeat(5)@(posedge clk);check_frame(16'h1357);
        // Reset with a ready frame in flight; independent reset release phases.
        send_frame(16'hcafe,0);
        #7 rst_n=0; #53 rst_n=1;
        repeat(10) @(posedge pclk);
        if(frame_valid) $fatal(1,"reset retained stale front");
        send_frame(16'h5678,0); pulse_end(); pulse_start();
        repeat(5) @(posedge clk); check_frame(16'h5678);
        // Stop PCLK entirely: main clock must still expire frame validity.
        force pclk=0;
        repeat(400005) @(posedge clk);
        #1;
        if(frame_valid || rd_pixel !== 0) $fatal(1,"stale timeout failed");
        release pclk;
        passed=1; $display("PASS ov5640 capture: exact dimensions, byte order, ownership, CDC reset, stale");
        $finish;
    end
    initial begin #100000000; $fatal(1,"watchdog"); end
endmodule
