`timescale 1ns/1ps
module attitude_equivalence_tb;
 reg clk=0,rst_n=0,sample=0;
 reg signed [15:0] ax=0,ay=0,az=4096,gx=24,gy=-12,gz=17;
 wire signed [15:0] r0,p0,y0,r1,p1,y1;wire v0,v1,ready0,ready1;
 reg signed [15:0] reference_r,reference_p,reference_y;
 integer passed=0,i,k,compared_frames=0;reg reference_seen=0;
 always #500 clk=~clk;
 imu_attitude #(.CLK_FREQ(1000000),.CAL_SAMPLES(256)) reference_core(clk,rst_n,sample,ax,ay,az,gx,gy,gz,r0,p0,y0,v0,ready0);
 nav_attitude #(.CLK_FREQ(1000000),.CAL_SAMPLES(256)) compact_core(clk,rst_n,sample,ax,ay,az,gx,gy,gz,r1,p1,y1,v1,ready1);
 always @(negedge clk)begin
  if(v0)begin reference_r=r0;reference_p=p0;reference_y=y0;reference_seen=1;end
  if(v1)begin
   for(k=0;k<4;k=k+1)if(compact_core.bank_a[7+k]!==reference_core.q[k])$fatal(1,"Internal quaternion state mismatch");
   for(k=0;k<3;k=k+1)if(compact_core.bank_a[11+k]!==reference_core.ef[k])$fatal(1,"Internal feedback state mismatch");
   if(!reference_seen || r1!==reference_r || p1!==reference_p || y1!==reference_y)
    $fatal(1,"Quaternion mismatch at frame%d got%d,%d,%d expected%d,%d,%d",compared_frames,r1,p1,y1,reference_r,reference_p,reference_y);
   compared_frames=compared_frames+1;reference_seen=0;
  end
 end
 task send_sample(input integer cycles);
 begin @(negedge clk);sample=1;@(negedge clk);sample=0;repeat(cycles-2)@(negedge clk);end
 endtask
 initial begin
  #151;rst_n=1;repeat(1000)@(negedge clk);
  for(i=0;i<256;i=i+1)send_sample(5000);
  for(i=0;i<600;i=i+1)begin
   gx=24+((i%31)-15)*9;gy=-12+((i%41)-20)*7;gz=17+((i%61)-30)*12;
   ax=((i%21)-10)*25;ay=((i%23)-11)*23;az=4096-((i%17)*4);
   if(i>=150 && i<200)begin ax=8000;ay=-7000;az=1000;end // invalid accel normalization gate
   if(i>=300 && i<350)begin gx=24;gy=-12;gz=1657;end // sustained yaw
   send_sample(3000+(i%9)*500);
  end
  if(compared_frames!=600 || !ready0 || !ready1)$fatal(1,"Skipped attitude frames: %d",compared_frames);
  #110000000; // identical stale-data gate
  if(ready0 || ready1)$fatal(1,"Freshness gate failed");
  passed=1;$display("PASS %d bit-identical quaternion output frames, bias calibration, invalid acceleration, yaw and stale gate",compared_frames);$finish;
 end
 initial begin #(64'd6000000000);$fatal(1,"Attitude equivalence timeout");end
endmodule
