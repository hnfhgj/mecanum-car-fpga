`timescale 1ns/1ps
module pipeline_display_tb;
 reg clk=0,rst_n=0;
 always #10 clk=~clk;
 wire tft_scl,tft_sda,tft_reset,tft_dc,tft_cs_n,tft_bl;
 wire [7:0] lx;wire [6:0] ly;wire frame_start;
 wire [15:0] raw_pixel,overlay_pixel;
 reg scan_bit=0;reg [15:0] camera_pixel=0;reg [2:0] page=5;
 always @(posedge clk)begin
  scan_bit<=(lx==17 && ly==19)||(lx>42 && lx<49 && ly==71);
  camera_pixel<={lx,1'b0,ly};
 end
 nav_scan_renderer raw(.clk(clk),.rst_n(rst_n),.frame_start(frame_start),.pixel_x(lx),.pixel_y(ly),
  .scan_bit(scan_bit),.front_valid(1'b1),.online(1'b1),.packets(32'd12),.crc_errors(32'd0),.drops(32'd0),.scans(32'd3),.scan_addr(),.pixel(raw_pixel));
 nav_renderer overlay(.clk(clk),.rst_n(rst_n),.frame_start(frame_start),.pixel_x(lx),.pixel_y(ly),.raw_pixel(raw_pixel),
  .menu_view(1'b0),.cursor(4'd1),.status(4'd0),.aligned(1'b0),.can_go(1'b0),.learn_ok(1'b0),.template_valid(1'b0),.ambiguous(1'b0),
  .live_count(4'd0),.frozen_count(4'd0),.o_id(4'd0),.x_id(4'd1),.y_id(4'd2),.live_xs(192'd0),.live_ys(192'd0),
  .frozen_xs(192'd0),.frozen_ys(192'd0),.pose_x(16'sd0),.pose_y(16'sd0),.target_x(16'd1000),.target_y(16'd1000),
  .width_mm(16'd2000),.height_mm(16'd2000),.diameter_mm(16'd100),.quality(16'd0),.pixel(overlay_pixel));
 nav_tft_display #(.CLK_FREQ(1000000),.SPI_FREQ(100000),.RESET_MS(1),.STARTUP_MS(1),.SLEEP_MS(1),.FRAME_GAP_MS(1),.DASHBOARD_ENABLE(1),.TELEMETRY_PAGES(1),.LIDAR_PAGE_ENABLE(1),.CAMERA_PAGE_ENABLE(1)) display(
  .clk(clk),.rst_n(rst_n),.lidar_pixel(overlay_pixel),.lidar_x(lx),.lidar_y(ly),.lidar_frame_start(frame_start),
  .lf_count(16'd0),.rf_count(16'd0),.lb_count(16'd0),.rb_count(16'd0),.lf_speed(16'd0),.rf_speed(16'd0),.lb_speed(16'd0),.rb_speed(16'd0),
  .acc_x(16'd0),.acc_y(16'd0),.acc_z(16'd0),.gyro_x(16'd0),.gyro_y(16'd0),.gyro_z(16'd0),.distance_mm(16'd0),
  .imu_init(1'b0),.tof_init(1'b0),.attitude_roll(16'd0),.attitude_pitch(16'd0),.attitude_yaw(16'd0),.attitude_ready(1'b0),
  .heading_turn(16'd0),.heading_left(16'd0),.heading_right(16'd0),.heading_fault(1'b0),.outputs_enabled(1'b0),
  .lf_duty(16'd0),.rf_duty(16'd0),.lb_duty(16'd0),.rb_duty(16'd0),
  .fault_reasons(16'd0),.tof_retries(16'd0),.calibration_mask(4'd0),.encoder_sign_mask(4'b1001),.encoder_inputs(8'd0),.tof_state(6'd0),
  .target_speed(16'd0),.closed_loop(1'b0),.fault_mask(4'd0),.page(page),.selection(4'd0),.gains_flat(480'd0),
  .camera_valid(1'b1),.camera_init_done(1'b1),.camera_fault(1'b0),.camera_pixel(camera_pixel),.camera_rd_addr(),.camera_frame_start(),.camera_frame_end(),
  .tft_scl(tft_scl),.tft_sda(tft_sda),.tft_reset(tft_reset),.tft_dc(tft_dc),.tft_cs_n(tft_cs_n),.tft_bl(tft_bl));

 function [15:0] expected_map(input integer x,input integer y);
 reg [15:0] v;
 begin
  v=0;
  if((x==17 && y==19)||(x>42 && x<49 && y==71))v=16'h07ff;
  else if(x%16==0 || y%16==0)v=16'h1082;
  if(x==0 || x==127 || y==0 || y==127)v=16'h39e7;
  if((x>=61 && x<=67 && y==64)||(y>=61 && y<=67 && x==64))v=16'hf800;
  if((x==64 && y>=4 && y<=10)||(y==7 && (x==62 || x==66)))v=16'hffe0;
  expected_map=v;
 end
 endfunction
 integer bits=0,bytes=0,pixels=0,x=0,y=0,passed=0;
 reg [7:0] incoming=0,high_byte=0;reg reading=0;
 reg [15:0] value,expected;
 reg [7:0] expected_character;reg [2:0] expected_font_x,expected_font_y;wire expected_dot;
 tft180_font reference_font(.ascii(expected_character),.x(expected_font_x),.y(expected_font_y),.pixel(expected_dot));
 function [7:0] sidebar_character(input integer x,input integer y);
 reg [31:0] word;
 begin
  case(y/8)
   0:word="N10 ";1:word="LIVE";2:word="SCAN";3:word="0003";4:word="PKT ";5:word="000C";
   6:word="CRC ";7:word="0000";8:word="DROP";9:word="0000";10:word="64MM";11:word="0 UP";
   12:word="90 R";13:word="S1> ";14:word="NO  ";15:word="SLAM";default:word="    ";
  endcase
  sidebar_character=word[(3-(x-128)/8)*8+:8];
 end
 endfunction
 always @(posedge tft_scl)begin
  if(tft_cs_n)$fatal(1,"SPI CS was high");
  incoming={incoming[6:0],tft_sda};bits=bits+1;
  if(bits==8)begin
   bits=0;
   if(!tft_dc)begin reading=incoming==8'h2c;if(reading)bytes=0;end
   else if(reading)begin
    if(!bytes[0])high_byte=incoming;
    else begin
     pixels=bytes/2;x=pixels%160;y=pixels/160;value={high_byte,incoming};
     if(display.frame_page==5)begin
      if(x<128)expected=expected_map(x,y);
      else begin
       expected_character=sidebar_character(x,y);expected_font_x=x%8;expected_font_y=y%8;#1;
       expected=expected_dot?(y<8?16'h07ff:y<16?16'h07e0:16'hffff):16'h0000;
      end
      if(value!==expected)$fatal(1,"Radar pipeline shifted x=%d y=%d got%h expected%h",x,y,value,expected);
     end
     if(display.frame_page==4)begin expected=(x<<8)|y;if(value!==expected)$fatal(1,"Camera read pipeline shifted x=%d y=%d got%h expected%h",x,y,value,expected);end
     if(pixels==20479)begin
      if(display.frame_page==5)page=4;
      else if(display.frame_page==4)begin passed=1;$display("PASS native radar raster and camera raster -> TFT SPI, all 40960 pixels aligned");$finish;end
     end
    end
    bytes=bytes+1;
   end
  end
 end
 initial begin #51;rst_n=1;end
 initial begin #200000000;$fatal(1,"Display pipeline timeout");end
endmodule
