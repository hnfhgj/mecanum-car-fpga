from pathlib import Path
import math, random
root=Path(__file__).parent
rng=random.Random(20261027)
lines=[]
def add(op,a,b):
    if op==0:r=a*b;z=0
    elif op==1:
        z=int(b==0);r=(abs(a)//abs(b))*(-1 if (a<0) != (b<0) else 1) if b else 0
    else:r=math.isqrt(a);z=0
    lines.append(f'{op} {a} {b} {r} {z}\n')
for a,b in [(0,0),(1,1),(-1,1),(-2147483648,-2147483648),(2147483647,-2147483648),(4000,16384)]:add(0,a,b)
for _ in range(300):add(0,rng.randrange(-2**31,2**31),rng.randrange(-2**31,2**31))
for a,b in [(0,0),(1,0),(-7,3),(7,-3),(-2**63,-2**31),(2**63-1,1)]:add(1,a,b)
for _ in range(300):add(1,rng.randrange(-2**61,2**61),rng.randrange(-2**30,2**30))
for a in [0,1,2,3,4,15,16,17,2**64-1,4000000,8000000]:add(2,a,0)
for _ in range(300):add(2,rng.randrange(2**63),0)
# The Verilog input uses signed %d, but square-root interprets its raw bits unsigned.
lines=[s.replace('2 18446744073709551615 ','2 -1 ') for s in lines]
(root/'math_vectors.txt').write_text(''.join(lines),encoding='ascii')
landmarks=[(0,0),(2000,0),(100,1900),(400,600),(1650,450),(700,1700)]
def local(x,y,theta,order):
    c=math.cos(math.radians(theta));s=math.sin(math.radians(theta))
    return [(round(c*(landmarks[i][0]-x)+s*(landmarks[i][1]-y)),
             round(-s*(landmarks[i][0]-x)+c*(landmarks[i][1]-y))) for i in order]
out=[f'{x} {y}\n' for x,y in local(800,700,31,range(6))]
for theta in [0,15,-15,45,-45,90,-90,135,-135,179,-179]:
    for x,y in [(500,500),(1000,950),(1500,1300)]:
        order=list(range(6));rng.shuffle(order)
        out.append(f'{x} {y} {round(theta*100)}\n')
        out.extend(f'{a} {b}\n' for a,b in local(x,y,theta,order))
(root/'pose_vectors.txt').write_text(''.join(out),encoding='ascii')
print('Generated independent arithmetic and known-world pose fixtures')
centers=[(1400,0),(-900,850),(-900,-1050)]
out=[f'{x} {y}\n' for x,y in centers]
for index in range(450*4+16):
    angle=(index%450)*0.8;t=math.radians(angle)
    vx,vy=math.cos(t),-math.sin(t)
    distance=0
    for cx,cy in centers:
        dot=cx*vx+cy*vy;disc=dot*dot-(cx*cx+cy*cy-50*50)
        if dot>0 and disc>=0:
            hit=round(dot-math.sqrt(disc))
            if distance==0 or hit<distance:distance=hit
    out.append(f'{round(angle*100)} {distance}\n')
(root/'feature_points.txt').write_text(''.join(out),encoding='ascii')
# Independent ray/circle intersections serialized as actual N10 UART packets.
theta=math.radians(35);cc,ss=math.cos(theta),math.sin(theta)
local_poles=[(cc*(x-800)+ss*(y-700),-ss*(x-800)+cc*(y-700)) for x,y in landmarks[:3]]
(root/'uart_expected_poles.txt').write_text(''.join(f'{round(x)} {round(y)}\n' for x,y in local_poles),encoding='ascii')
bytes_out=[]
for packet_index in range(143):
    raw=bytearray(58);raw[:3]=b'\xa5\x5a\x3a'
    angles=[((packet_index*16+j)*80)%36000 for j in range(16)]
    raw[5:7]=angles[0].to_bytes(2,'big');raw[55:57]=angles[-1].to_bytes(2,'big')
    for j,angle in enumerate(angles):
        t=math.radians(angle/100);vx,vy=math.cos(t),-math.sin(t);distance=0
        for cx,cy in local_poles:
            dot=cx*vx+cy*vy;disc=dot*dot-(cx*cx+cy*cy-50*50)
            if dot>0 and disc>=0:
                hit=round(dot-math.sqrt(disc))
                if distance==0 or hit<distance:distance=hit
        raw[7+3*j:9+3*j]=distance.to_bytes(2,'big');raw[9+3*j]=100 if distance else 0
    raw[57]=sum(raw[:57])&255;bytes_out.extend(raw)
(root/'uart_poles.hex').write_text(''.join(f'{v:02x}\n' for v in bytes_out),encoding='ascii')
