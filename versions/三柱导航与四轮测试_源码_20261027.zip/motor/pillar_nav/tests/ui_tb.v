`timescale 1ns/1ps
module ui_tb;
 reg clk=0,rst_n=0,active=0;reg [3:0] key_n=15;reg feature_done=0,learn_done=0;
 wire [2:0] page;wire menu;wire [3:0] cursor,o,a,b,n,selection;
 wire [191:0] fx,fy;wire [15:0] diameter,tx,ty;wire req,align,go,stop,clear;
 wire [31:0] kp,kd;integer passed=0,i,stops=0,aligns=0;
 always #10 clk=~clk;
 always @(posedge clk)begin if(stop)stops=stops+1;if(align)aligns=aligns+1;end
 nav_ui #(.CLK_HZ(1000)) dut(clk,rst_n,key_n,active,feature_done,1'b1,4'd3,192'd1,192'd2,
  learn_done,1'b1,1'b1,16'd2000,16'd1900,page,menu,cursor,o,a,b,n,fx,fy,diameter,tx,ty,req,align,go,stop,clear,selection,kp,kd);
 task press(input integer k);
 begin @(negedge clk);key_n[k]=0;repeat(35)@(negedge clk);key_n[k]=1;repeat(35)@(negedge clk);end
 endtask
 task long_s1;
 begin @(negedge clk);key_n[0]=0;repeat(850)@(negedge clk);key_n[0]=1;repeat(35)@(negedge clk);end
 endtask
 initial begin
  #51;rst_n=1;press(1);if(page!=5 || !menu || cursor!=1)$fatal(1,"Cannot open radar menu");
  press(2);if(n!=3 || fx!=1 || fy!=2 || menu)$fatal(1,"Freeze not atomic");
  press(1);press(1);if(cursor!=2)$fatal(1,"Select origin failed");
  press(2);if(o!=1)$fatal(1,"ID edit failed");press(3);if(o!=0)$fatal(1,"ID decrement failed");
  repeat(4)press(1);if(cursor!=6)$fatal(1,"Select learn failed");press(2);if(!req)$fatal(1,"Learn request not held");
  learn_done=1;@(negedge clk);learn_done=0;repeat(3)@(negedge clk);if(req)$fatal(1,"Learn ack not consumed");
  press(1);press(2);if(aligns!=1)$fatal(1,"Align event missing");
  press(1);press(2);if(tx!=1050)$fatal(1,"Target unit is not 5cm");
  active=1;press(2);if(tx!=1050)$fatal(1,"Target changed during travel");i=stops;press(3);if(stops<=i)$fatal(1,"Stop during travel missing");active=0;
  long_s1();if(page!=0)$fatal(1,"Long S1 should leave radar, without double short event");
  press(0);if(page!=1)$fatal(1,"Original pages unavailable");press(2);if(kp!=328)$fatal(1,"Heading P edit regression");
  press(1);press(3);if(kd!=2304)$fatal(1,"Heading D edit regression");
  long_s1();if(page!=5)$fatal(1,"Cannot return directly to radar");
  passed=1;$display("PASS real debounced buttons, map/menu, freeze, ID edits, learn handshake, align, 5cm target and stop");$finish;
 end
 initial begin #10000000;$fatal(1,"UI timeout");end
endmodule
