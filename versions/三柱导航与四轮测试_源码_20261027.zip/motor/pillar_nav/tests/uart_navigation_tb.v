`timescale 1ns/1ps
module uart_navigation_tb;
 reg clk=0,rst_n=0,rx=1,periodic_frame=0,injected=0;
 wire inject=!injected && radar.core.pending && radar.core.state==5;
 wire frame_start=periodic_frame || inject;
 reg [15:0] counter=0;
 wire raw_valid,raw_bad,online;wire [15:0] raw_angle,raw_range;
 wire valid,ready,overflow;wire signed [15:0] x,y;wire [15:0] angle,range_out;
 wire features_done,features_ok;wire [3:0] count;wire [191:0] xs,ys;wire [31:0] scans;
 reg learn_req=0;reg [3:0] o_id=0,a_id=1,b_id=2;reg [191:0] frozen_xs=0,frozen_ys=0;
 wire learn_done,learn_ok,template_valid,pose_update,pose_ok,busy,ambiguous;
 wire signed [15:0] pose_x,pose_y,pose_yaw;wire [15:0] width,height,bx,quality;
 integer passed=0,fd,rc,i,j,n,byte_in,expected_x[0:2],expected_y[0:2],dx,dy,fixes=0,raw_points=0;
 reg froze=0;reg [3:0] selected[0:2];
 always #10 clk=~clk;
 always @(posedge clk)begin
  periodic_frame<=0;if(counter==49999)begin counter<=0;periodic_frame<=1;end else counter<=counter+1'b1;
  if(inject)injected<=1;
  if(raw_valid)raw_points<=raw_points+1;
 end
 nav_lidar radar(.clk(clk),.rst_n(rst_n),.rx(rx),.display_start(frame_start),.pixel_x(8'd0),.pixel_y(7'd0),.pixel(),
  .online(online),.point_valid(raw_valid),.stream_bad(raw_bad),.point_angle(raw_angle),.point_range_mm(raw_range));
 nav_point_stream stream(clk,rst_n,raw_bad,raw_valid,raw_angle,raw_range,ready,valid,x,y,angle,range_out,overflow);
 nav_features features(clk,rst_n,raw_bad,valid,x,y,angle,range_out,16'd100,ready,features_done,features_ok,count,xs,ys,scans);
 nav_pose pose(clk,rst_n,1'b0,features_done,features_ok,count,xs,ys,learn_req,4'd3,o_id,a_id,b_id,frozen_xs,frozen_ys,
  learn_done,learn_ok,template_valid,pose_update,pose_ok,busy,pose_x,pose_y,pose_yaw,width,height,bx,quality,ambiguous);
 always @(negedge clk)if(rst_n)begin
  if(raw_bad || overflow)$fatal(1,"Valid UART fixture was corrupted in parser/FIFO");
  if(features_done && !froze)begin
   if(!features_ok || count!=3)$fatal(1,"Whole UART scan did not produce three poles");
   for(j=0;j<3;j=j+1)begin
    selected[j]=15;
    for(n=0;n<3;n=n+1)begin
     dx=$signed(xs[n*16+:16])-expected_x[j];dy=$signed(ys[n*16+:16])-expected_y[j];
     if(dx*dx+dy*dy<1600)selected[j]=n;
    end
    if(selected[j]==15)$fatal(1,"Native UART point geometry differs from known pole");
   end
   o_id=selected[0];a_id=selected[1];b_id=selected[2];frozen_xs=xs;frozen_ys=ys;learn_req=1;froze=1;
  end
  if(learn_done)begin if(!learn_ok)$fatal(1,"UART-learn failed");learn_req=0;end
  if(pose_update)begin
   if(!pose_ok || pose_x<750 || pose_x>850 || pose_y<650 || pose_y>750 || pose_yaw<3400 || pose_yaw>3600)
    $fatal(1,"End-to-end pose wrong: %d %d %d valid=%d",pose_x,pose_y,pose_yaw,pose_ok);
   fixes=fixes+1;
  end
 end
 task send_byte(input [7:0] v);
 begin rx=0;#4340;for(i=0;i<8;i=i+1)begin rx=v[i];#4340;end rx=1;#4340;end
 endtask
 initial begin
  fd=$fopen("pillar_nav/tests/uart_expected_poles.txt","r");for(j=0;j<3;j=j+1)rc=$fscanf(fd,"%d %d\n",expected_x[j],expected_y[j]);$fclose(fd);
  #77;rst_n=1;#233;
  fd=$fopen("pillar_nav/tests/uart_poles.hex","r");if(!fd)$fatal(1,"No UART fixture");
  while(!$feof(fd))begin rc=$fscanf(fd,"%x\n",byte_in);if(rc==1)send_byte(byte_in[7:0]);end
  $fclose(fd);#1000000;
  if(!injected || raw_points!=2288)$fatal(1,"Display transfer dropped native points: %d expected2288",raw_points);
  if(fixes<2 || !online || !template_valid)$fatal(1,"Not enough live fixes from full UART path");
  passed=1;$display("PASS 230400 UART -> verified packet queue -> native points -> seam-aware clusters -> learned triangle -> known pose; fixes=%d",fixes);$finish;
 end
 initial begin #500000000;$fatal(1,"UART end-to-end timeout");end
endmodule
