`timescale 1ns/1ps
module math_tb;
 reg clk=0,rst_n=0,cancel=0,start=0;reg [1:0] op;reg signed [63:0] a;reg signed [31:0] b;
 wire busy,done,zero;wire signed [63:0] result;integer passed=0,fd,rc,cases=0;
 reg signed [63:0] expected;reg expected_zero;
 always #10 clk=~clk;
 nav_math dut(clk,rst_n,cancel,start,op,a,b,busy,done,zero,result);
 initial begin
  #51;rst_n=1;fd=$fopen("pillar_nav/tests/math_vectors.txt","r");if(!fd)$fatal(1,"No arithmetic vectors");
  while(!$feof(fd))begin
   @(negedge clk);rc=$fscanf(fd,"%d %d %d %d %d\n",op,a,b,expected,expected_zero);
   if(rc==5)begin
    start=1;@(negedge clk);start=0;wait(done);#1;
    if(result!==expected || zero!==expected_zero)$fatal(1,"Arithmetic op=%d a=%d b=%d result=%d expected=%d",op,a,b,result,expected);
    cases=cases+1;@(negedge clk);
   end
  end
  $fclose(fd);passed=1;$display("PASS %d independent arithmetic vectors",cases);$finish;
 end
 initial begin #100000000;$fatal(1,"Arithmetic timeout");end
endmodule
