`timescale 1ns/1ps
module pose_tb;
 reg clk=0,rst_n=0,clear=0,scan_done=0,scan_ok=1,learn_req=0;
 reg [3:0] count=6,frozen_count=6,o_id=0,x_id=1,y_id=2;
 reg [191:0] xs=0,ys=0,frozen_xs=0,frozen_ys=0;
 wire learn_done,learn_ok,template_valid,update,ok,busy,ambiguous;
 wire signed [15:0] x,y,yaw;wire [15:0] width,height,bx,quality;
 integer fd,rc,i,px,py,expected_x,expected_y,expected_yaw,passed=0,cases=0;
 always #10 clk=~clk;
 nav_pose dut(clk,rst_n,clear,scan_done,scan_ok,count,xs,ys,learn_req,frozen_count,o_id,x_id,y_id,frozen_xs,frozen_ys,
  learn_done,learn_ok,template_valid,update,ok,busy,x,y,yaw,width,height,bx,quality,ambiguous);
 function integer abs_int(input integer v);begin abs_int=v<0?-v:v;end endfunction
 function integer angle_error(input integer a,input integer b);integer d;begin d=a-b;if(d>18000)d=d-36000;if(d< -18000)d=d+36000;angle_error=abs_int(d);end endfunction
 initial begin
  fd=$fopen("pillar_nav/tests/pose_vectors.txt","r");if(!fd)$fatal(1,"No pose vectors");
  for(i=0;i<6;i=i+1)begin rc=$fscanf(fd,"%d %d\n",px,py);frozen_xs[i*16+:16]=px;frozen_ys[i*16+:16]=py;end
  #51;rst_n=1;@(negedge clk);learn_req=1;wait(learn_done);#1;
  if(!learn_ok || !template_valid || abs_int(width-2000)>4 || abs_int(height-1900)>5)$fatal(1,"Learn failed width=%d height=%d",width,height);
  @(negedge clk);learn_req=0;
  while(!$feof(fd))begin
   rc=$fscanf(fd,"%d %d %d\n",expected_x,expected_y,expected_yaw);
   if(rc==3)begin
    for(i=0;i<6;i=i+1)begin rc=$fscanf(fd,"%d %d\n",px,py);xs[i*16+:16]=px;ys[i*16+:16]=py;end
    @(negedge clk);scan_done=1;@(negedge clk);scan_done=0;wait(update);#1;
    if(!ok || abs_int($signed(x)-expected_x)>7 || abs_int($signed(y)-expected_y)>7 || angle_error($signed(yaw),expected_yaw)>30)
     $fatal(1,"Pose case %d got=%d,%d,%d expected=%d,%d,%d ok=%d quality=%d",cases,x,y,yaw,expected_x,expected_y,expected_yaw,ok,quality);
    cases=cases+1;@(negedge clk);
   end
  end
  // Incomplete observation must invalidate the current fix.
  @(negedge clk);count=2;scan_done=1;@(negedge clk);scan_done=0;wait(update);#1;if(ok)$fatal(1,"Two poles accepted");
  // Two translated copies of the same triangle must never become a silent jump.
  @(negedge clk);count=6;
  xs[0+:16]=-600;ys[0+:16]=-700;xs[16+:16]=1400;ys[16+:16]=-700;xs[32+:16]=-500;ys[32+:16]=1200;
  xs[48+:16]=-100;ys[48+:16]=-400;xs[64+:16]=1900;ys[64+:16]=-400;xs[80+:16]=0;ys[80+:16]=1500;
  scan_done=1;@(negedge clk);scan_done=0;wait(update);#1;
  if(ok || !ambiguous)$fatal(1,"Ambiguous duplicate triangle accepted");
  @(negedge clk);clear=1;@(negedge clk);clear=0;#1;if(template_valid)$fatal(1,"Clear did not invalidate template");
  @(negedge clk);y_id=1;learn_req=1;wait(learn_done);#1;if(learn_ok || template_valid)$fatal(1,"Repeated landmark ID accepted");
  passed=1;$display("PASS %d pose/association cases plus missing landmark and clear",cases);$finish;
 end
 initial begin #200000000;$fatal(1,"Pose timeout");end
endmodule
