`timescale 1ns/1ps
module control_tb;
 reg clk=0,rst_n=0,template_valid=0,learn_req=0,clear_cal=0,align=0,go=0,stop=0;
 reg [2:0] page=5;reg update=0,ok=1;
 reg signed [15:0] x=500,y=500,yaw=0;reg [15:0] tx=1000,ty=1000,width=2000,height=2000;
 reg heading_ready=1,wheel_fault=0;reg signed [15:0] turn=0;
 wire active,aligned,fresh,can_go;wire [3:0] status;wire signed [15:0] lf,rf,lb,rb,body_yaw;
 integer passed=0,i,j,forward,left,wx,wy,steps;real angle,c,s;
 always #10 clk=~clk;
 nav_control #(.CLK_HZ(1000000)) dut(clk,rst_n,template_valid,learn_req,clear_cal,align,go,stop,page,update,ok,
  x,y,yaw,tx,ty,width,height,heading_ready,wheel_fault,turn,active,aligned,fresh,can_go,status,lf,rf,lb,rb,body_yaw);
 task feed;
 begin @(negedge clk);update=1;@(negedge clk);update=0;repeat(200)@(negedge clk);end
 endtask
 task pulse_go;
 begin @(negedge clk);go=1;@(negedge clk);go=0;repeat(3)@(negedge clk);end
 endtask
 initial begin
  #51;rst_n=1;pulse_go();if(active)$fatal(1,"Uncalibrated GO accepted");
  for(i=0;i<4;i=i+1)begin
   @(negedge clk);clear_cal=1;@(negedge clk);clear_cal=0;template_valid=1;x=500;y=500;yaw=0;ok=1;
   repeat(5)feed();@(negedge clk);align=1;@(negedge clk);align=0;
   case(i)0:yaw=0;1:yaw=9000;2:yaw=-9000;3:yaw=17900;endcase
   repeat(4)feed();if(!can_go)$fatal(1,"Not ready after valid calibration");
   pulse_go();if(!active)$fatal(1,"Ready GO ignored");steps=0;
   while(active && steps<100)begin
    feed();forward=($signed(lf)+$signed(rf)+$signed(lb)+$signed(rb))/4;
    left=(-$signed(lf)+$signed(rf)+$signed(lb)-$signed(rb))/4;
    angle=$itor($signed(yaw))*3.141592653589793/18000.0;c=$cos(angle);s=$sin(angle);
    wx=$rtoi((c*forward-s*left)/4);wy=$rtoi((s*forward+c*left)/4);
    x=x+wx;y=y+wy;steps=steps+1;
   end
   if(active || status!=5 || x<925 || x>1075 || y<925 || y>1075)$fatal(1,"Arrival failed yaw=%d pose=%d,%d status=%d",yaw,x,y,status);
   if(lf || rf || lb || rb)$fatal(1,"Arrival did not stop all wheels");
  end
  tx=1500;ty=1500;pulse_go();feed();ok=0;feed();
  if(active || lf || rf || lb || rb || status!=6)$fatal(1,"Lost fix did not stop");
  ok=1;repeat(5)feed();if(active)$fatal(1,"Unexpected auto-resume after reacquisition");
  pulse_go();feed();page=0;repeat(3)@(negedge clk);if(active || lf || rf || lb || rb)$fatal(1,"Leaving radar page did not stop");
  page=5;repeat(5)feed();tx=0;pulse_go();if(active)$fatal(1,"Out-of-field target accepted");
  passed=1;$display("PASS mecanum world/body transform, four-heading arrival, missing fix, manual restart, page stop, invalid GO");$finish;
 end
 initial begin #100000000;$fatal(1,"Control timeout");end
endmodule
