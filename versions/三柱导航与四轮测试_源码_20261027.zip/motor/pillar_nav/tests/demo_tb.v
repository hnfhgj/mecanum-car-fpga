`timescale 1ns/1ps
module demo_tb;
 reg clk=0,rst_n=0;reg [3:0] key_n=15;
 wire [3:0] dir,pwm;
 integer passed=0,i;integer high0,high1,high2,high3;
 always #10 clk=~clk;
 forward_demo_top #(.RUN_MS(25)) dut(.clk(clk),.rst_n(rst_n),.key_n(key_n),
  .lf_ea(1'b0),.lf_eb(1'b0),.rf_ea(1'b0),.rf_eb(1'b0),.lb_ea(1'b0),.lb_eb(1'b0),.rb_ea(1'b0),.rb_eb(1'b0),
  .lf_dir(dir[0]),.rf_dir(dir[1]),.lb_dir(dir[2]),.rb_dir(dir[3]),.lf_pwm(pwm[0]),.rf_pwm(pwm[1]),.lb_pwm(pwm[2]),.rb_pwm(pwm[3]),
  .uart_tx(),.tft_scl(),.tft_sda(),.tft_reset(),.tft_dc(),.tft_cs_n(),.tft_bl());
 initial begin
  #51;rst_n=1;repeat(3000)@(negedge clk);if(pwm!=0 || dut.running)$fatal(1,"Demo moved on boot");
  key_n[2]=0;#21000000;key_n[2]=1;
  if(!dut.running || dir!=15)$fatal(1,"Four forward polarity/start wrong");
  high0=0;high1=0;high2=0;high3=0;
  repeat(2941)begin @(negedge clk);high0=high0+pwm[0];high1=high1+pwm[1];high2=high2+pwm[2];high3=high3+pwm[3];end
  if(high0!=441 || high1!=441 || high2!=441 || high3!=441)$fatal(1,"PWM not 441/2941 on all wheels");
  key_n[3]=0;#21000000;key_n[3]=1;
  if(dut.running || pwm!=0 || dut.elapsed>=1250000)$fatal(1,"S4 did not stop before demo timeout");
  #21000000;key_n[2]=0;#21000000;key_n[2]=1;
  if(!dut.running)$fatal(1,"Demo cannot restart by button");
  #26000000;if(dut.running || pwm!=0)$fatal(1,"Demo did not stop at configured duration");
  passed=1;$display("PASS physical key debounce, no boot motion, four directions=1111, duty441/2941, manual stop and timeout");$finish;
 end
 initial begin #200000000;$fatal(1,"Demo timeout");end
endmodule
