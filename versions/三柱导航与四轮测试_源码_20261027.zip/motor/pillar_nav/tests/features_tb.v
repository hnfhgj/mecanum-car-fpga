`timescale 1ns/1ps
module features_tb;
 reg clk=0,rst_n=0,bad=0,point_valid=0;reg [15:0] angle_in=0,range_in=0;
 wire ready,valid,overflow;wire signed [15:0] x,y;wire [15:0] angle,range_out;
 wire done,ok;wire [3:0] count;wire [191:0] xs,ys;wire [31:0] scans;
 integer fd,rc,a,r,i,j,found,dx,dy,passed=0,frames=0;
 integer expected_x[0:2],expected_y[0:2];reg matched[0:2];
 always #10 clk=~clk;
 nav_point_stream stream(clk,rst_n,bad,point_valid,angle_in,range_in,ready,valid,x,y,angle,range_out,overflow);
 nav_features features(clk,rst_n,bad,valid,x,y,angle,range_out,16'd100,ready,done,ok,count,xs,ys,scans);
 always @(posedge clk)if(rst_n && overflow)$fatal(1,"Point FIFO overflow at valid packet burst rate");
 always @(negedge clk)if(done)begin
  frames=frames+1;
  if(!ok || count!=3)$fatal(1,"Candidate count/valid wrong %d %d",count,ok);
  for(j=0;j<3;j=j+1)matched[j]=0;
  for(i=0;i<count;i=i+1)begin
   found=0;
   for(j=0;j<3;j=j+1)begin
    dx=$signed(xs[i*16+:16])-expected_x[j];dy=$signed(ys[i*16+:16])-expected_y[j];
    if(dx*dx+dy*dy<1600)begin found=1;matched[j]=1;end
   end
   if(!found)$fatal(1,"Candidate not near a true pole: %d,%d",$signed(xs[i*16+:16]),$signed(ys[i*16+:16]));
  end
  for(j=0;j<3;j=j+1)if(!matched[j])$fatal(1,"Pole was lost, including angle-zero split cluster");
 end
 initial begin
  fd=$fopen("pillar_nav/tests/feature_points.txt","r");if(!fd)$fatal(1,"No point fixtures");
  for(i=0;i<3;i=i+1)rc=$fscanf(fd,"%d %d\n",expected_x[i],expected_y[i]);
  #51;rst_n=1;i=0;
  while(!$feof(fd))begin
   rc=$fscanf(fd,"%d %d\n",a,r);
   if(rc==2)begin
    @(negedge clk);angle_in=a;range_in=r;point_valid=1;@(negedge clk);point_valid=0;
    // A 16-point parser burst is fast; idle between packets allows draining.
    repeat(6)@(negedge clk);i=i+1;
    if(i%16==0)repeat(5000)@(negedge clk);
   end
  end
  repeat(30000)@(negedge clk);
  if(frames<2)$fatal(1,"No complete feature revolutions");
  passed=1;$display("PASS ray/cylinder geometry, zero-angle merging, radius correction, atomic candidate frames and FIFO bursts");$finish;
 end
 initial begin #100000000;$fatal(1,"Features timeout");end
endmodule
