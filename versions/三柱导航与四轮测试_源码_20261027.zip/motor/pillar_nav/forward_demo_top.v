// Independent repair check: S3 starts 5 seconds at 15%; S4 stops. No automatic
// motion on power-up, no encoder auto-polarity learning and no Flash writes.
module forward_demo_top #(parameter integer CLK_HZ=50000000,RUN_MS=5000)(
 input wire clk,rst_n,input wire [3:0] key_n,
 input wire lf_ea,lf_eb,rf_ea,rf_eb,lb_ea,lb_eb,rb_ea,rb_eb,
 output wire lf_dir,lf_pwm,rf_dir,rf_pwm,lb_dir,lb_pwm,rb_dir,rb_pwm,
 output wire uart_tx,output wire tft_scl,tft_sda,tft_reset,tft_dc,tft_cs_n,tft_bl);
 wire [3:0] press;
 nav_buttons #(.CLK_HZ(CLK_HZ)) buttons(.clk(clk),.rst_n(rst_n),.key_n(key_n),.press(press),.release_event(),.long_press(),.stable());
 reg running;reg [31:0] elapsed;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin running<=0;elapsed<=0;end
  else if(press[3])begin running<=0;elapsed<=0;end
  else if(press[2] && !running)begin running<=1;elapsed<=0;end
  else if(running)begin
   if(elapsed>=CLK_HZ/1000*RUN_MS-1)running<=0;
   else elapsed<=elapsed+1'b1;
  end
 end
 wire signed [15:0] drive=running?-16'sd441:16'sd0;
 motor_driver #(.CLK_FREQ(CLK_HZ),.PHASE_OFFSET(0)) d0(clk,rst_n,drive,lf_dir,lf_pwm);
 motor_driver #(.CLK_FREQ(CLK_HZ),.PHASE_OFFSET(735)) d1(clk,rst_n,drive,rf_dir,rf_pwm);
 motor_driver #(.CLK_FREQ(CLK_HZ),.PHASE_OFFSET(1470)) d2(clk,rst_n,drive,lb_dir,lb_pwm);
 motor_driver #(.CLK_FREQ(CLK_HZ),.PHASE_OFFSET(2200)) d3(clk,rst_n,drive,rb_dir,rb_pwm);
 wire [15:0] c0,c1,c2,c3;wire signed [15:0] v0,v1,v2,v3;
 // Preserve the last verified encoder corrections: LF and RB reversed.
 quad_decoder q0(clk,rst_n,lf_eb,lf_ea,c0);quad_decoder q1(clk,rst_n,rf_ea,rf_eb,c1);
 quad_decoder q2(clk,rst_n,lb_ea,lb_eb,c2);quad_decoder q3(clk,rst_n,rb_eb,rb_ea,c3);
 speed_measure #(.CLK_FREQ(CLK_HZ)) m0(.clk(clk),.rst_n(rst_n),.count_in(c0),.speed(v0),.tick());
 speed_measure #(.CLK_FREQ(CLK_HZ)) m1(.clk(clk),.rst_n(rst_n),.count_in(c1),.speed(v1),.tick());
 speed_measure #(.CLK_FREQ(CLK_HZ)) m2(.clk(clk),.rst_n(rst_n),.count_in(c2),.speed(v2),.tick());
 speed_measure #(.CLK_FREQ(CLK_HZ)) m3(.clk(clk),.rst_n(rst_n),.count_in(c3),.speed(v3),.tick());
 uart_enc_debug #(.CLK_FREQ(CLK_HZ)) serial(.clk(clk),.rst_n(rst_n),.lf_count(c0),.rf_count(c1),.lb_count(c2),.rb_count(c3),
  .lf_speed(v0),.rf_speed(v1),.lb_speed(v2),.rb_speed(v3),.acc_x(16'd0),.acc_y(16'd0),.acc_z(16'd0),
  .gyro_x(16'd0),.gyro_y(16'd0),.gyro_z(16'd0),.distance_mm(16'd0),.imu_init(1'b0),.imu_valid(1'b0),
  .tof_init(1'b0),.tof_valid(1'b0),.target_speed(running?16'd441:16'd0),.run_mask({4{running}}),.fault_mask(4'd0),
  .attitude_roll(16'd0),.attitude_pitch(16'd0),.attitude_yaw(16'd0),.attitude_ready(1'b0),
  .heading_left(16'd0),.heading_right(16'd0),.heading_turn(16'd0),.heading_fault(1'b0),
  .calibration_mask(4'd0),.encoder_sign_mask(4'b1001),.fault_reasons(16'd0),.diagnostic_stop(!running),.diagnostic_bits(168'd0),.uart_tx(uart_tx));
 tft180_display #(.CLK_FREQ(CLK_HZ),.DASHBOARD_ENABLE(1),.TELEMETRY_PAGES(1)) display(
  .clk(clk),.rst_n(rst_n),.lidar_pixel(16'd0),.lidar_x(),.lidar_y(),.lidar_frame_start(),
  .lf_count(c0),.rf_count(c1),.lb_count(c2),.rb_count(c3),.lf_speed(v0),.rf_speed(v1),.lb_speed(v2),.rb_speed(v3),
  .acc_x(16'd0),.acc_y(16'd0),.acc_z(16'd0),.gyro_x(16'd0),.gyro_y(16'd0),.gyro_z(16'd0),.distance_mm(16'd0),
  .imu_init(1'b0),.tof_init(1'b0),.attitude_roll(16'd0),.attitude_pitch(16'd0),.attitude_yaw(16'd0),.attitude_ready(1'b0),
  .heading_turn(16'd0),.heading_left(16'd0),.heading_right(16'd0),.heading_fault(1'b0),.outputs_enabled(running),
  .lf_duty(running?16'd441:16'd0),.rf_duty(running?16'd441:16'd0),.lb_duty(running?16'd441:16'd0),.rb_duty(running?16'd441:16'd0),
  .fault_reasons(16'd0),.tof_retries(16'd0),.calibration_mask(4'd0),.encoder_sign_mask(4'b1001),.encoder_inputs(8'd0),.tof_state(6'd0),
  .target_speed(running?16'd441:16'd0),.closed_loop(1'b0),.fault_mask(4'd0),.page(3'd0),.selection(4'd0),.gains_flat(480'd0),
  .camera_valid(1'b0),.camera_init_done(1'b0),.camera_fault(1'b0),.camera_pixel(16'd0),.camera_rd_addr(),.camera_frame_start(),.camera_frame_end(),
  .tft_scl(tft_scl),.tft_sda(tft_sda),.tft_reset(tft_reset),.tft_dc(tft_dc),.tft_cs_n(tft_cs_n),.tft_bl(tft_bl));
endmodule
