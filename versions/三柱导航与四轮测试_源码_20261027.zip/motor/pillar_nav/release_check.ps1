param([switch]$Snapshot,[switch]$Publish)
$ErrorActionPreference='Stop'
$motorRoot=Split-Path $PSScriptRoot -Parent
$snapshotPath=Join-Path $PSScriptRoot 'build_inputs.json'
$units=@(
 @{name='navigation';project='pillar_navigation.gprj';pnr='impl/pnr';base='pillar_final';cst='n10_build/lidar_board.cst';portCount=53},
 @{name='four_forward';project='pillar_nav/forward_demo/demo.gprj';pnr='pillar_nav/forward_demo/impl/pnr';base='four_forward';cst='pillar_nav/forward_demo/board.cst';portCount=29}
)
function Inputs-For($unit){
 $projectPath=Join-Path $motorRoot $unit.project
 [xml]$project=(Get-Content $projectPath -Raw).Replace('version="1"','version="1.0"')
 $folder=Split-Path $projectPath -Parent
 $all=@{}
 foreach($ref in $project.Project.FileList.File){
  if($ref.enable -eq '1'){
   $absolute=if([System.IO.Path]::IsPathRooted($ref.path)){[System.IO.Path]::GetFullPath($ref.path)}else{[System.IO.Path]::GetFullPath((Join-Path $folder $ref.path))}
   $relative=[System.IO.Path]::GetRelativePath($motorRoot,$absolute)
   $all[$relative]=(Get-FileHash -LiteralPath $absolute).Hash
  }
 }
 # ROM files are loaded by $readmemh, outside the .gprj list.
 foreach($rom in @('src/imu660ra_config.hex','src/dl1b_config.hex')){$all[$rom]=(Get-FileHash (Join-Path $motorRoot $rom)).Hash}
 return $all
}
if($Snapshot){
 $snap=@{};foreach($unit in $units){$snap[$unit.name]=Inputs-For $unit}
 $snap|ConvertTo-Json -Depth 5|Set-Content $snapshotPath -Encoding utf8
 'Saved source/project/constraint/ROM hashes; this does not approve a bitstream'
 return
}
if(!(Test-Path $snapshotPath)){throw 'Missing source snapshot'}
$sourceSnapshot=Get-Content $snapshotPath -Raw|ConvertFrom-Json -AsHashtable
$results=@()
$release=Join-Path $PSScriptRoot 'release'
if($Publish){New-Item -ItemType Directory -Path $release -Force|Out-Null}
foreach($unit in $units){
 $inputs=Inputs-For $unit
 if($inputs.Count -ne $sourceSnapshot[$unit.name].Count){throw 'Project source list changed'}
 foreach($key in $inputs.Keys){if($sourceSnapshot[$unit.name][$key] -ne $inputs[$key]){throw "Input changed: $($unit.name) $key"}}
 $pnr=Join-Path $motorRoot $unit.pnr
 $html=Get-Content (Join-Path $pnr ($unit.base+'_tr_content.html')) -Raw
 foreach($kind in @('Setup','Hold')){
  $m=[regex]::Match($html,"Numbers of $kind Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>")
  if(!$m.Success -or $m.Groups[1].Value -ne '0'){throw "$($unit.name) $kind timing not passed"}
 }
 $expected=@{}
 foreach($m in [regex]::Matches((Get-Content (Join-Path $motorRoot $unit.cst) -Raw),'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;')){
  if($expected.ContainsKey($m.Groups[1].Value)){throw 'Duplicate port constraint'}
  $expected[$m.Groups[1].Value]=$m.Groups[2].Value
 }
 if($expected.Count -ne $unit.portCount -or @($expected.Values|Sort-Object -Unique).Count -ne $unit.portCount){throw 'Wrong pin count or repeated ball'}
 $reportPath=Join-Path $pnr ($unit.base+'.rpt.txt')
 $report=Get-Content $reportPath
 $fitted=@{}
 foreach($line in $report){
  $columns=@($line.Split('|')|ForEach-Object {$_.Trim()})
  if($columns.Count -gt 4 -and $expected.ContainsKey($columns[0])){
   if($columns[3] -ne 'Y'){throw 'Auto-assigned I/O'}
   $fitted[$columns[0]]=$columns[2].Split('/')[0]
  }
 }
 if($fitted.Count -ne $unit.portCount){throw 'Incomplete fitted port report'}
 foreach($pin in $expected.Keys){if($fitted[$pin] -ne $expected[$pin]){throw "Wrong fitted pin: $pin"}}
 $fs=Join-Path $pnr ($unit.base+'.fs')
 $logPath=if($unit.name -eq 'navigation'){Join-Path $PSScriptRoot 'build_navigation_final.log'}else{Join-Path $PSScriptRoot 'forward_demo/build.log'}
 if($unit.name -eq 'navigation'){
  $marker=Join-Path $PSScriptRoot 'final_build.ok'
  if(!(Test-Path $marker)){throw 'Corrected final build not approved yet'}
  if((Get-Item $marker).LastWriteTimeUtc -lt (Get-Item $snapshotPath).LastWriteTimeUtc){throw 'Build approval predates source snapshot'}
  if((Get-Content $marker -Raw) -match 'mode=full'){$logPath=Join-Path $PSScriptRoot 'build_navigation.log'}
 }
 if((Get-Content $logPath -Raw) -notmatch [regex]::Escape("PASS: $($unit.base) setup/hold violations zero")){throw 'Build has not completed its timing approval'}
 $builtAt=(Get-Item $fs).LastWriteTimeUtc
 foreach($key in $inputs.Keys){if((Get-Item (Join-Path $motorRoot $key)).LastWriteTimeUtc -gt $builtAt){throw "Bitstream older than source: $key"}}
 $header=(Get-Content $fs -TotalCount 18)-join "`n"
 if($header -notmatch '//Device-package: GW5AT-60B-PBGA484A'){throw 'Wrong FPGA/package'}
 $code=[regex]::Match($header,'//UserCode:\s+0x([0-9A-Fa-f]+)').Groups[1].Value
 if(!$code){throw 'Missing user code'}
 $resources=@{}
 foreach($resource in @('Logic','Register','BSRAM','DSP')){
  $line=$report|Where-Object {$_ -match ('^\s*'+$resource+'\s+\|')}|Select-Object -First 1
  if($line){$resources[$resource]=$line.Trim()}
 }
 $hash=(Get-FileHash $fs).Hash
 $fileName=$unit.name+'_'+$code.Substring($code.Length-4)+'.fs'
 $destination=if($Publish){Join-Path $release $fileName}else{$fs}
 if($Publish){
  Copy-Item -LiteralPath $fs -Destination $destination
  if((Get-FileHash $destination).Hash -ne $hash){throw 'Published file hash mismatch'}
  Copy-Item -LiteralPath $reportPath -Destination (Join-Path $release ($unit.name+'_pnr.txt'))
  Copy-Item -LiteralPath (Join-Path $pnr ($unit.base+'_tr_content.html')) -Destination (Join-Path $release ($unit.name+'_timing.html'))
 }
 $results+=@{name=$unit.name;firmware=$destination;sha256=$hash;bytes=(Get-Item $fs).Length;userCode=('0x'+$code);ports=$fitted.Count;resources=$resources;setup=0;hold=0}
}
$base=Join-Path $motorRoot 'n10_build/n10_B5C2_ready.fs'
if((Get-FileHash $base).Hash -ne '9879C5F2D4ED8BD334D97F61B35DAB03D56994CC8A7A9E0395C91BBC7A03A16C'){throw 'Rollback file changed'}
$testText=Get-Content (Join-Path $PSScriptRoot 'tests_console.log') -Raw
foreach($marker in @('923 independent arithmetic','pose/association cases','four-heading arrival','zero-angle merging','real debounced buttons','menu renderer','duty441/2941')){
 if($testText -notmatch [regex]::Escape($marker)){throw "Missing test evidence: $marker"}
}
if($testText -notmatch 'Errors: 0, Warnings: 0' -or $testText -match '\*\* (Fatal|Error)'){throw 'Functional simulation failed'}
$uartText=Get-Content (Join-Path $PSScriptRoot 'uart_navigation_console.log') -Raw
if($uartText -notmatch 'PASS 230400 UART' -or $uartText -match '\*\* (Fatal|Error)'){throw 'Full UART navigation simulation failed'}
$attitudeText=Get-Content (Join-Path $PSScriptRoot 'attitude_equivalence_console.log') -Raw
if($attitudeText -notmatch '600 bit-identical quaternion' -or $attitudeText -match '\*\* (Fatal|Error)'){throw 'Shared-DSP attitude equivalence test failed'}
$pipelineText=Get-Content (Join-Path $PSScriptRoot 'pipeline_tests_console.log') -Raw
if($pipelineText -notmatch 'all 40960 pixels aligned' -or $pipelineText -notmatch 'PASS ov5640 capture' -or $pipelineText -match '\*\* (Fatal|Error)'){throw 'Camera/display pipeline tests failed'}
$manifest=[ordered]@{target='GW5AT-LV60PG484AC1/I0 / GW5AT-60B PBGA484A';verified=(Get-Date).ToString('o');hardwareProgrammed=$false;hardwareMotionTested=$false;sourceSnapshot='build_inputs.json';firmware=$results;rollbackSHA256=(Get-FileHash $base).Hash}
if($Publish){$manifest|ConvertTo-Json -Depth 8|Set-Content (Join-Path $release 'manifest.json') -Encoding utf8}
$manifest|ConvertTo-Json -Depth 8
'PASS: offline release checks; no hardware operation performed'
