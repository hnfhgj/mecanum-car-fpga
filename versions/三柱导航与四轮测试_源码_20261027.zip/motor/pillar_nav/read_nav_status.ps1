param([Parameter(Mandatory=$true)][string]$Port,[int]$Seconds=6,[string]$LogPath='')
$ErrorActionPreference='Stop'
$serial=[System.IO.Ports.SerialPort]::new($Port,115200,[System.IO.Ports.Parity]::None,8,[System.IO.Ports.StopBits]::One)
$serial.DtrEnable=$false;$serial.RtsEnable=$false
$text=''
try {
 $serial.Open();$watch=[System.Diagnostics.Stopwatch]::StartNew()
 while($watch.Elapsed.TotalSeconds -lt $Seconds){$text+=$serial.ReadExisting();Start-Sleep -Milliseconds 40}
 $text+=$serial.ReadExisting()
} finally {if($serial.IsOpen){$serial.Close()};$serial.Dispose()}
if($LogPath){$text|Out-File -LiteralPath $LogPath -Encoding utf8}
function Word([byte[]]$Bytes,[int]$Index,[switch]$Signed){
 $v=([int]$Bytes[$Index] -shl 8)+$Bytes[$Index+1]
 if($Signed -and $v -ge 32768){$v-=65536};return $v
}
$lines=$text -split '\r?\n'
$frames=@($lines|Where-Object {$_ -match '^IO HEX=[0-9A-F]{42}$'})
"Bytes=$($text.Length) NavFrames=$($frames.Count)"
foreach($line in ($frames|Select-Object -Last 8)){
 $hex=$line.Substring(7);$bytes=[byte[]]::new(21)
 for($i=0;$i -lt 21;$i++){$bytes[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
 if($bytes[0] -ne 0 -or $bytes[1] -ne 0 -or $bytes[2] -ne 0){throw 'Unexpected navigation diagnostic layout'}
 $flags=$bytes[3]
 [pscustomobject]@{State=$bytes[4];Candidates=$bytes[5];Cursor=$bytes[6];
  X_mm=(Word $bytes 7 -Signed);Y_mm=(Word $bytes 9 -Signed);BodyYaw_cdeg=(Word $bytes 11 -Signed);
  TargetX_mm=(Word $bytes 13);TargetY_mm=(Word $bytes 15);FitError_mm=(Word $bytes 17);Scans=(Word $bytes 19);
  Template=[bool]($flags-band 32);Aligned=[bool]($flags-band 16);Fresh=[bool]($flags-band 8);
  CanGo=[bool]($flags-band 4);Active=[bool]($flags-band 2);HeadingReady=[bool]($flags-band 1);Ambiguous=[bool]($flags-band 128)}|ConvertTo-Json -Compress
}
$lines|Where-Object {$_ -match '^(LF=|PID |ATT |DBG )'}|Select-Object -Last 4
