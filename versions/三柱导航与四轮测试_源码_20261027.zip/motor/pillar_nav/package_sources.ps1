# Export local, portable project sources. Never programs hardware.
param([string]$Destination='',[switch]$Overwrite)
$ErrorActionPreference='Stop'
$motorRoot=Split-Path $PSScriptRoot -Parent
$workspace=Split-Path $motorRoot -Parent
if(!$Destination){$Destination=Join-Path $workspace '三柱导航与四轮测试_源码_20261027.zip'}
if((Test-Path -LiteralPath $Destination) -and !$Overwrite){throw 'Archive exists; choose a new destination'}
$stage=Join-Path $PSScriptRoot ('package_stage_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage|Out-Null
$exportMotor=Join-Path $stage 'motor'
New-Item -ItemType Directory -Path (Join-Path $exportMotor 'src') -Force|Out-Null
New-Item -ItemType Directory -Path (Join-Path $exportMotor 'pillar_nav/forward_demo') -Force|Out-Null
New-Item -ItemType Directory -Path (Join-Path $exportMotor 'pillar_nav/tests') -Force|Out-Null
New-Item -ItemType Directory -Path (Join-Path $exportMotor 'n10_build') -Force|Out-Null
Get-ChildItem (Join-Path $motorRoot 'src') -File|Where-Object {$_.Extension -in '.v','.hex'}|ForEach-Object {
 Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $exportMotor 'src')
}
Get-ChildItem $PSScriptRoot -File|Where-Object {$_.Extension -in '.v','.tcl','.do','.ps1','.json'}|ForEach-Object {
 Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $exportMotor 'pillar_nav')
}
foreach($file in @('build.tcl','clock.sdc','board.cst')){
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('forward_demo/'+$file)) -Destination (Join-Path $exportMotor 'pillar_nav/forward_demo')
}
foreach($file in @('lidar_board.cst','lidar_verified.sdc','n10_B5C2_ready.fs')){
 Copy-Item -LiteralPath (Join-Path $motorRoot ('n10_build/'+$file)) -Destination (Join-Path $exportMotor 'n10_build')
}
Get-ChildItem (Join-Path $PSScriptRoot 'tests') -File|ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $exportMotor 'pillar_nav/tests')}
foreach($file in @('tests.log','tests_console.log','uart_navigation_test.log','uart_navigation_console.log','top_elaboration_console.log','attitude_equivalence.log','attitude_equivalence_console.log','pipeline_tests.log','pipeline_tests_console.log')){
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $exportMotor 'pillar_nav')
}
foreach($project in @('pillar_navigation.gprj','pillar_nav/forward_demo/demo.gprj')){
 $original=Join-Path $motorRoot $project
 [xml]$xml=(Get-Content $original -Raw).Replace('version="1"','version="1.0"')
 $folder=Split-Path $original -Parent
 foreach($ref in $xml.Project.FileList.File){
  $absolute=if([IO.Path]::IsPathRooted($ref.path)){[IO.Path]::GetFullPath($ref.path)}else{[IO.Path]::GetFullPath((Join-Path $folder $ref.path))}
  $ref.path=[IO.Path]::GetRelativePath($folder,$absolute).Replace('\','/')
 }
 $xml.Save((Join-Path $exportMotor $project))
}
Copy-Item -LiteralPath (Join-Path $workspace '三柱定位导航与四轮测试_操作说明.md') -Destination $stage
$exportFiles=@(Get-ChildItem $stage -Recurse -File)
foreach($file in $exportFiles|Where-Object {$_.Extension -in '.gprj','.v','.tcl','.do'}){
 if((Get-Content $file.FullName -Raw) -match 'C:[/\\]Users[/\\]jiyuf'){throw "Nonportable absolute source path: $($file.FullName)"}
}
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $Destination -CompressionLevel Optimal -Force:$Overwrite
"Source archive: $Destination"
"SHA256: $((Get-FileHash $Destination).Hash)"
