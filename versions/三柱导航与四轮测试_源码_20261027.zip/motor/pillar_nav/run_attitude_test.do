onerror {quit -code 1 -f}
set lib [file normalize pillar_nav/test_work]
eval vlog -sv -work $lib [glob src/*.v] [glob pillar_nav/*.v] pillar_nav/tests/attitude_equivalence_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib attitude_equivalence_tb
run -all
if {[examine -radix unsigned /attitude_equivalence_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
