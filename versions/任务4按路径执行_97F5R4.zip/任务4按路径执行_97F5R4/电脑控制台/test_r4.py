import unittest,json,time,queue
from pathlib import Path
from unittest.mock import patch
from field_navigation import FieldPlanner,Field,path_waypoint
from test_field import ready,field_scan
from test_console import FakeSerial
from transport import Link
from protocol import DRIVE,PLANNED_DRIVE

class RouteExecutionTests(unittest.TestCase):
 def test_all_three_recorded_false_stalls_now_have_routes(self):
  rows=json.loads(Path(__file__).with_name('stall_replay.json').read_text(encoding='utf-8'))
  self.assertEqual(len(rows),3)
  for row in rows:
   with self.subTest(goal=row['goal']):
    p=FieldPlanner(row['scan']['points'],row['pose'],Field(**row['frame']));path,why,_,_=p.plan(row['goal'])
    self.assertTrue(path,why);self.assertEqual(tuple(path[-1]),tuple(row['goal']))
 def test_no_extra_short_segment_veto_after_route_exists(self):
  n=ready();n.select((165,210));n.start(10.9)
  with patch.object(FieldPlanner,'short_clear',side_effect=AssertionError('duplicate veto used')):
   s=n.update(field_scan(),0,11.08,4)
  self.assertTrue(s.running);self.assertNotEqual(s.mask,0)
 def test_corner_is_not_skipped_by_lookahead(self):
  path=[(130,160),(130,170),(140,180),(150,190)]
  self.assertEqual(path_waypoint(path,(150,190)),(130,170))
 def test_physical_body_still_determines_planned_route(self):
  p=FieldPlanner(field_scan(),(165,80,0),Field(330,260));self.assertEqual((p.mx,p.my),(15,22))
  self.assertFalse(p.free((-1,10)))

class PlannedPacketTests(unittest.TestCase):
 def test_auto_uses17_manual_uses15_release_restores_manual(self):
  events=queue.Queue();device=FakeSerial();link=Link(events,lambda:device);link.connect('OFFLINE_FAKE')
  try:
   end=time.monotonic()+1
   while time.monotonic()<end:
    try:kind,_=events.get(timeout=.05)
    except queue.Empty:continue
    if kind=='task':break
   else:self.fail('No handshake telemetry')
   end=time.monotonic()+.16
   while time.monotonic()<end:link.set_drive(1,planned=True);time.sleep(.02)
   link.set_drive(0);time.sleep(.03)
   end=time.monotonic()+.12
   while time.monotonic()<end:link.set_drive(4);time.sleep(.02)
   link.set_drive(0);time.sleep(.03)
   writes=[p for p in device.writes if p[4] in (DRIVE,PLANNED_DRIVE)]
   self.assertTrue(any(p[4]==PLANNED_DRIVE and p[6]==1 for p in writes))
   self.assertTrue(any(p[4]==DRIVE and p[6]==4 for p in writes))
   self.assertEqual((writes[-1][4],writes[-1][6]),(DRIVE,0))
  finally:link.close_event.set();link.thread.join(1)

if __name__=='__main__':unittest.main(verbosity=2)
