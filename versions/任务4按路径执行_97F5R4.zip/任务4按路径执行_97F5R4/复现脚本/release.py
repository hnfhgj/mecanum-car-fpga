"""Validate immutable 97F4 baseline and freeze the matching 97F5/R4 release."""
from pathlib import Path
import hashlib,json,re,shutil,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent;pnr=r/'impl/pnr'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
base=json.loads((r/'free_navigation/release/manifest.json').read_text(encoding='utf-8'))
for name,h in base['inputs'].items():assert sha(r/name)==h,name
assert sha(r/'free_navigation/release'/base['firmware'])==base['sha256']
tree=ET.fromstring((r/'planned_drive.gprj').read_text(encoding='utf-8').replace('version="1"','version="1.0"'))
paths=[f.get('path') for f in tree.findall('.//File') if f.get('enable')=='1']+['src/imu660ra_config.hex','src/dl1b_config.hex']
assert len(paths)==len(set(paths))
assert set(paths)==(set(base['inputs'])-{'free_navigation/free_navigation_top.v','free_navigation/pc_ui.v'})|{'planned_drive/planned_drive_top.v','planned_drive/pc_ui.v'}
tests=['pc_control_tb','pc_bridge_tb','wireless_top_tb','wireless_stream_tb','speed_tb','basic_nav_tb','pc_motor_pipeline_tb','manual_tb','directional_tb','cloud_stream_tb','snapshot_tb','hold_top_tb','square_frame_tb']
for test in tests:
 log=(p/(test+'.log')).read_text(encoding='utf-8-sig');assert 'PASS ' in log and not re.search('Fatal:|ERROR:',log),test
assert 'all 0..127 inputs' in (p/'speed_tb.log').read_text(encoding='utf-8-sig')
gui=w/'麦轮控制台_97F5_路径执行_R4'
log=(gui/'python_tests.log').read_text(encoding='utf-8-sig');assert 'Ran 115 tests' in log and re.search(r'\nOK\s*$',log)
assert 'PASS field GUI' in (gui/'gui_smoke.log').read_text(encoding='utf-8-sig')
assert 'PASS: planned_drive setup/hold violations zero' in (p/'build.log').read_text(encoding='utf-8-sig')
fs=pnr/'planned_drive.fs';header='\n'.join(fs.read_text(encoding='ascii').splitlines()[:18])
assert '//Device-package: GW5AT-60B-PBGA484A' in header
assert re.search(r'//UserCode:\s+0x([0-9A-Fa-f]+)',header)[1].upper()=='000097F5'
assert all((r/f).stat().st_mtime<=fs.stat().st_mtime for f in paths),'Source newer than build'
timing=(pnr/'planned_drive_tr_content.html').read_text(encoding='utf-8-sig')
for kind in ('Setup','Hold'):assert re.search(r'Numbers of '+kind+r' Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>',timing)[1]=='0'
pins=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;',(r/'basic_tasks/wireless_board.cst').read_text(encoding='utf-8-sig')))
assert len(pins)==56 and len(set(pins.values()))==56
actual={}
for line in (pnr/'planned_drive.rpt.txt').read_text(encoding='utf-8-sig').splitlines():
 fields=[s.strip() for s in line.split('|')]
 if len(fields)>4 and fields[0] in pins:
  assert fields[3]=='Y';actual[fields[0]]=fields[2].split('/')[0]
assert actual==pins
top=(p/'planned_drive_top.v').read_text(encoding='utf-8');ui=(p/'pc_ui.v').read_text(encoding='utf-8')
assert top.count('.MAX_TURN(110)')==3 and '.MAX_DUTY(882)' in top
assert '.NO_FEEDBACK_GUARD(0)' in top and '.FIXED_ENCODER_SIGN(1)' in top
assert ".blocked(planned_drive?4'd0:manual_blocked)" in top
assert 'planned_drive<=remote_op==17 && remote_a!=0;' in ui
replay=json.loads((gui/'stall_replay.json').read_text(encoding='utf-8'));assert len(replay)==3
out=p/'release';out.mkdir(exist_ok=True);dest=out/'planned_drive_97F5.fs'
if dest.exists():assert sha(dest)==sha(fs),'Immutable firmware differs'
else:shutil.copy2(fs,dest)
for f,name in [(pnr/'planned_drive_tr_content.html','timing.html'),(pnr/'planned_drive.rpt.txt','pnr.txt'),(p/'build.log','build.log')]:shutil.copy2(f,out/name)
m=dict(firmware=dest.name,userCode='000097F5',sha256=sha(dest),setup=0,hold=0,ports=56,baseline='97F4',
 hardwareProgrammed=False,navigationMotionTested=False,rtlSimulations=13,pythonTests=115,placeOption=2,routeOption=2,
 pcClient='97F5/R4',pcMustRemainConnected=True,pcNavigationRequiresRectangle=True,
 plannedDriveOpcode=17,manualDriveOpcode=15,task4DirectionConeVeto=False,task3DirectionalBlocking=True,
 extraShortSegmentVeto=False,extraRotationObstacleVeto=False,forcedLeftRightGate=False,
 planningBodyHalfWidthCm=8,planningBodyHalfLengthCm=15,gridMarginCm=7,plannerCellCm=10,firstStraightLegFollowed=True,
 staleSensorsStop=True,commandLeaseMs=300,stopAndEscapeRetained=True,
 translationTargets=[52,105,157,210,262,315],spinMaxTurn=110,pwmMaxCounts=882,
 inputs={f:sha(r/f) for f in paths},guiInputs={f.name:sha(f) for f in gui.iterdir() if f.suffix in ('.py','.cmd','.md','.txt','.json')},
 testInputs={f.name:sha(f) for f in p.iterdir() if f.suffix in ('.sv','.v','.ps1','.txt')})
(out/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v for k,v in m.items() if k not in ('inputs','guiInputs','testInputs')},indent=2))
