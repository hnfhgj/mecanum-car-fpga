from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;r=p.parent
m=json.loads((r/'free_navigation/release/manifest.json').read_text(encoding='utf-8'))
for name,h in m['inputs'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest().upper()==h,name
def change(s,a,b):assert a in s,a;return s.replace(a,b)
s=(r/'free_navigation/pc_ui.v').read_text(encoding='utf-8').replace("16'h97F4","16'h97F5")
s=change(s,'output reg [1:0] cone_mode);','output reg [1:0] cone_mode,output reg planned_drive);')
s=change(s,'else if(remote_op==15)begin','else if(remote_op==15 || remote_op==17)begin')
s=change(s,'drive_valid<=0;drive_mask<=0;ack_valid', 'drive_valid<=0;drive_mask<=0;planned_drive<=0;ack_valid')
s=change(s,'stop_pulse<=1;remote_owned<=0;seen_active<=0;ack_status<=0;', 'stop_pulse<=1;planned_drive<=0;remote_owned<=0;seen_active<=0;ack_status<=0;')
s=change(s,'15:begin drive_valid<=1;drive_mask<=remote_a[5:0];','15,17:begin drive_valid<=1;drive_mask<=remote_a[5:0];planned_drive<=remote_op==17 && remote_a!=0;')
(p/'pc_ui.v').write_text(s,encoding='utf-8')
s=(r/'free_navigation/free_navigation_top.v').read_text(encoding='utf-8').replace('module free_navigation_top #(','module planned_drive_top #(').replace("16'h97F4","16'h97F5")
s=change(s,'wire [5:0] drive_mask,manual_requested;', 'wire planned_drive;wire [5:0] drive_mask,manual_requested;')
s=change(s,'.blocked(manual_blocked),.speed_level',".blocked(planned_drive?4'd0:manual_blocked),.speed_level")
s=change(s,'.cone_mode(cone_mode));\n basic_clearance', '.cone_mode(cone_mode),.planned_drive(planned_drive));\n basic_clearance')
(p/'planned_drive_top.v').write_text(s,encoding='utf-8')
s=(r/'free_navigation.gprj').read_text(encoding='utf-8').replace('free_navigation/free_navigation_top.v','planned_drive/planned_drive_top.v').replace('free_navigation/pc_ui.v','planned_drive/pc_ui.v')
(r/'planned_drive.gprj').write_text(s,encoding='utf-8')
s=(r/'free_navigation/build.tcl').read_text(encoding='utf-8').replace('free_navigation','planned_drive').replace('000097F4','000097F5')
(p/'build.tcl').write_text(s,encoding='utf-8')
print('Prepared97F5: packet17 planned path ignores direction cones; packet15 manual cones unchanged, lease/STOP retained.')
