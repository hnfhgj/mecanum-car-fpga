from pathlib import Path
import hashlib,json,shutil,zipfile
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
m=json.loads((p/'release/manifest.json').read_text(encoding='utf-8'))
out=w/'任务4按路径执行_97F5R4';out.mkdir(exist_ok=True)
def cp(src,rel):
 d=out/rel;d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists() and sha(d)==sha(src):return
 shutil.copy2(src,d)
for name,h in m['inputs'].items():assert sha(r/name)==h;cp(r/name,Path('工程/motor')/name)
for name in ['planned_drive.gprj','planned_drive/build.tcl','pillar_nav/timing_check.tcl']:
 cp(r/name,Path('工程/motor')/name)
for name,h in m['testInputs'].items():assert sha(p/name)==h;cp(p/name,Path('工程/motor/planned_drive')/name)
for name in ['prepare.py','prepare_tests.py','release.py','package.py']:cp(p/name,Path('复现脚本')/name)
for f in (p/'release').iterdir():
 if f.is_file():cp(f,Path('固件与验证')/f.name)
for f in p.glob('*_tb.log'):cp(f,Path('固件与验证/RTL仿真')/f.name)
gui=w/'麦轮控制台_97F5_路径执行_R4'
for name,h in m['guiInputs'].items():assert sha(gui/name)==h;cp(gui/name,Path('电脑控制台')/name)
for name in ['python_tests.log','gui_smoke.log']:cp(gui/name,Path('固件与验证')/name)
cp(gui/'使用说明.md','先读我.md')
cp(r/'free_navigation/release/free_navigation_97F4.fs','回退97F4/free_navigation_97F4.fs')
for f in (w/'麦轮控制台_97F4_矩形导航_R3').iterdir():
 if f.is_file() and f.suffix in ('.py','.cmd','.md','.txt','.json'):cp(f,Path('回退97F4/匹配R3控制台')/f.name)
entries={f.relative_to(out).as_posix():sha(f) for f in out.rglob('*') if f.is_file() and f.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding='utf-8')
archive=w/(out.name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in out.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in entries.items():assert hashlib.sha256(z.read(out.name+'/'+name)).hexdigest().upper()==h
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),files=len(entries)+1,bytes=archive.stat().st_size),indent=2,ensure_ascii=True))
