from pathlib import Path
import shutil
p=Path(__file__).resolve().parent;r=p.parent
for name in ['top_tb.sv','control_tb.v','stream_tb.sv','cloud_stream_tb.sv','snapshot_tb.sv','manual_tb.sv','hold_top_tb.sv','speed_tb.sv','nav_tb.v','frame_tb.v']:
 s=(r/'free_navigation'/name).read_text(encoding='utf-8').replace('free_navigation_top','planned_drive_top').replace('97F4','97F5')
 if name=='top_tb.sv':s=s.replace("byte_send('hf4)","byte_send('hf5)").replace("byte_send('hbd)","byte_send('hbe)")
 if name=='control_tb.v':
  s=s.replace('wire [15:0] fb,lr;', 'wire planned;wire [15:0] fb,lr;').replace('drive_mask,fb,lr,cone);','drive_mask,fb,lr,cone,planned);')
  s=s.replace('  passed=1;$display("PASS PC protocol', '''  active=0;manual_active=0;manual_range=1;
  command(130,17,5,0,0,0);if(status || !planned || drive_mask!=5)$fatal(1,"Planned packet rejected");
  active=1;manual_active=1;command(131,15,1,0,0,0);if(status || planned)$fatal(1,"Manual inherited planned bypass");
  manual_range=0;command(132,17,1,0,0,0);if(status!=3 || planned)$fatal(1,"Planned ignored stale input");
  command(133,17,0,0,0,0);if(status || planned || drive_mask)$fatal(1,"Planned release rejected");
  command(134,17,1,1,0,0);if(status!=2)$fatal(1,"Planned extra payload accepted");
  command(135,17,64,0,0,0);if(status!=2)$fatal(1,"Planned invalid mask accepted");
  active=0;manual_range=1;command(136,17,1,0,0,0);command(137,0,0,0,0,0);if(planned)$fatal(1,"STOP retained planned mode");
  passed=1;$display("PASS PC protocol''')
 if name=='hold_top_tb.sv':
  s=s.replace(' $display("PASS held top', ''' force dut.manual_blocked=15;
 command(20,17,1);
 if(!dut.planned_drive || dut.targets[0]!=210 || dut.targets[1]!=210 || dut.targets[2]!=210 || dut.targets[3]!=210)$fatal(1,"Planned path blocked by cones");
 command(21,15,1);repeat(20)@(negedge clk);
 if(dut.planned_drive || dut.targets[0] || dut.targets[1] || dut.targets[2] || dut.targets[3])$fatal(1,"Task3 bypassed protection");
 command(22,17,1);repeat(15001000)@(negedge clk);
 if(dut.manual_active || lfp || rfp || lbp || rbp)$fatal(1,"Planned lease did not expire");
 command(23,17,1);command(24,0,0);if(dut.planned_drive || dut.active || lfp || rfp || lbp || rbp)$fatal(1,"Planned STOP failed");
 $display("PASS held top''')
  s=s.replace('#100000000;','#500000000;')
 (p/name).write_text(s,encoding='utf-8')
for name in ['frame_fixture.txt','frame_live.txt','frame_missing.txt']:shutil.copy2(r/'free_navigation'/name,p/name)
s=(r/'free_navigation/run_tests.ps1').read_text(encoding='utf-8').replace('free_navigation.gprj','planned_drive.gprj').replace('free_97F4','planned_97F5')
(p/'run_tests.ps1').write_text(s,encoding='utf-8')
print('Prepared13 RTL tests including actual UART planned bypass, protected manual, release, STOP and 300ms expiry.')
