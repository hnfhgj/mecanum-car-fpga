onerror {quit -code 1 -f}
set lib [file normalize pc_control/work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/uart_tx.v src/uart_rx.v pillar_nav/nav_buttons.v pc_control/command_rx.v pc_control/pc_ui.v pc_control/pc_wireless_bridge.v pc_control/motor_pipeline.v pc_control/control_tb.v
foreach test {pc_control_tb pc_bridge_tb pc_motor_pipeline_tb} {
 vsim -onfinish stop -voptargs=+acc -lib $lib $test
 run -all
 if {[examine -radix unsigned /$test/passed] != 1} {quit -code 1 -f}
 quit -sim
}
quit -code 0 -f
