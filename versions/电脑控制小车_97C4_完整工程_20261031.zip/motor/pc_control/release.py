"""Isolated release guard; no serial access, programming or motion."""
from pathlib import Path
import importlib.util,json,hashlib,re,argparse,zipfile,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent.parent
p=r/'pc_control'
s=importlib.util.spec_from_file_location('release_shared',r/'square_nav/release.py')
shared=importlib.util.module_from_spec(s);s.loader.exec_module(shared)
shared.PROJECT=r/'pc_tasks.gprj'

def publish():
    current=shared.inputs()
    assert current==json.loads((p/'inputs.json').read_text())
    previous=json.loads((r/'basic_tasks/release/manifest.json').read_text())
    assert previous['userCode']=='0x000097B3'
    for name,h in previous['inputs'].items():
        assert shared.sha(r/name)==h,'97B3 baseline was modified: '+name
    pnr=r/'impl/pnr'
    fs=pnr/'pc_tasks.fs'
    header='\n'.join(fs.read_text(encoding='ascii').splitlines()[:18])
    assert '//Device-package: GW5AT-60B-PBGA484A' in header
    assert re.search(r'//UserCode:\s+0x([0-9A-Fa-f]+)',header)[1].upper()=='000097C4'
    timing=(pnr/'pc_tasks_tr_content.html').read_text(encoding='utf-8-sig')
    for kind in ('Setup','Hold'):
        assert re.search(r'Numbers of '+kind+r' Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>',timing)[1]=='0'
    assert 'PASS: pc_tasks setup/hold violations zero' in (p/'build_final.log').read_text(encoding='utf-8-sig')
    expected=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;', (r/'basic_tasks/wireless_board.cst').read_text(encoding='utf-8-sig')))
    actual={}
    report=(pnr/'pc_tasks.rpt.txt').read_text(encoding='utf-8-sig')
    for line in report.splitlines():
        f=[a.strip() for a in line.split('|')]
        if len(f)>4 and f[0] in expected:
            assert f[3]=='Y';actual[f[0]]=f[2].split('/')[0]
    assert len(expected)==len(set(expected.values()))==56 and actual==expected
    assert all((r/name).stat().st_mtime<=fs.stat().st_mtime for name in current)
    for file,markers in [('test_console.log',['PASS PC protocol/UI:','PASS PC UART end-to-end:','PASS PC motor pipeline:']),
                         ('top_test_console.log',['PASS PC tasks top:'])]:
        text=(p/file).read_text(encoding='utf-8-sig')
        assert all(m in text for m in markers) and not re.search(r'\*\* (Error|Fatal|Warning)',text)
        assert 'Errors: 0, Warnings: 0' in text
    out=p/'release';out.mkdir(exist_ok=True)
    shared.copy_artifact(fs,out/'pc_97C4.fs',immutable=True)
    shared.copy_artifact(pnr/'pc_tasks.rpt.txt',out/'pnr.txt')
    shared.copy_artifact(pnr/'pc_tasks_tr_content.html',out/'timing.html')
    manifest=dict(firmware='pc_97C4.fs',userCode='0x000097C4',sha256=shared.sha(fs),inputs=current,
                  setup=0,hold=0,ports=56,hardwareProgrammed=False,hardwareMotionTested=False,
                  currentKnownFlash='0x000097A2',previousCandidate='0x000097B3',protocolVersion=1)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in manifest.items() if k!='inputs'},indent=2))

def package():
    out=p/'release';m=json.loads((out/'manifest.json').read_text())
    assert shared.inputs()==m['inputs']
    paths={r/name for name in m['inputs']}
    # Include the 97B3 baseline required by the release guard and current Flash rollback.
    previous=json.loads((r/'basic_tasks/release/manifest.json').read_text())
    paths.update(r/name for name in previous['inputs'])
    paths.update(r/'basic_tasks/release'/name for name in ('manifest.json','basic_97B3.fs','previous_flash_97A2.fs'))
    paths.update(f for f in p.iterdir() if f.is_file())
    paths.update(f for f in out.iterdir() if f.is_file())
    paths.add(r/'pc_tasks.gprj')
    paths.update([r/'basic_tasks.gprj',r/'pillar_nav/timing_check.tcl',r/'square_nav/release.py'])
    dest=r.parent/'电脑控制小车_97C4_完整工程_20261031.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(paths):z.write(f,'motor/'+f.relative_to(r).as_posix())
        for f in (r.parent/'电脑控制小车').iterdir():
            if f.is_file():z.write(f,'电脑控制小车/'+f.name)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        assert hashlib.sha256(z.read('motor/pc_control/release/pc_97C4.fs')).hexdigest().upper()==m['sha256']
        for name,h in m['inputs'].items():assert hashlib.sha256(z.read('motor/'+name)).hexdigest().upper()==h,name
        for required in ('motor/pc_tasks.gprj','motor/pillar_nav/timing_check.tcl','motor/square_nav/release.py','电脑控制小车/controller.py','电脑控制小车/protocol.py'):
            assert required in z.namelist(),required
    print('PASS PC control source/firmware/desktop archive:',dest)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--snapshot',action='store_true');a.add_argument('--publish',action='store_true');a.add_argument('--package',action='store_true');args=a.parse_args()
    if args.snapshot:(p/'inputs.json').write_text(json.dumps(shared.inputs(),indent=2));print('Saved PC source snapshot')
    if args.publish:publish()
    if args.package:package()
