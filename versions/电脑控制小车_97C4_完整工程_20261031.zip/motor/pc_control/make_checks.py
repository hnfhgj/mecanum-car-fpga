from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent.parent
p=r/'pc_control'
t=ET.fromstring((r/'pc_tasks.gprj').read_text().replace('version="1"','version="1.0"'))
files=' '.join('{'+x.get('path')+'}' for x in t.findall('.//File') if x.get('type')=='file.verilog')
script='''onerror {quit -code 1 -f}
set lib [file normalize pc_control/top_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib FILES
vsim -voptargs=+acc -gUSE_EXTERNAL_OSC=1 -lib $lib pc_tasks_top
force -freeze /pc_tasks_top/clk 0 0ns,1 10ns -repeat 20ns
force -freeze /pc_tasks_top/rst_n 0
force -freeze /pc_tasks_top/key_n 1111
force -freeze /pc_tasks_top/wireless_rx 1
force -freeze /pc_tasks_top/wireless_rts 1
run 100ns
force -freeze /pc_tasks_top/rst_n 1
run 1000ns
foreach pin {lf_pwm rf_pwm lb_pwm rb_pwm} {
 if {[examine -radix unsigned /pc_tasks_top/$pin] != 0} {error "Unexpected boot PWM"}
}
if {[examine -radix unsigned /pc_tasks_top/group_id] != 0} {error "Wrong boot menu"}
echo "PASS PC tasks top: integrated control link, root menu, boot PWM zero"
quit -code 0 -f
'''.replace('FILES',files)
(p/'elaborate.do').write_text(script,encoding='utf-8')
print('PC top elaboration script ready')
