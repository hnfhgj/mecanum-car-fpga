"""Create an isolated PC-control project from frozen 97B3 source files."""
from pathlib import Path
r=Path(__file__).resolve().parent.parent
p=r/'pc_control'

ui=(r/'basic_tasks/basic_ui.v').read_text(encoding='utf-8-sig').replace('module basic_ui','module pc_ui')
ui=ui.replace('input wire calibrated,', '''input wire remote_valid,input wire [7:0] remote_seq,remote_op,
 input wire [15:0] remote_a,remote_b,remote_c,
 input wire motion_ready,range_ready,nav_ready,
 output reg ack_valid,output reg [7:0] ack_seq,ack_status,
 input wire calibrated,''')
ui=ui.replace(' wire [3:0] press;', ''' wire [3:0] press;
 reg [15:0] max_x,max_y;reg [2:0] bounds_ready;
 reg cached;reg [7:0] cached_seq,cached_status;
 reg [63:0] cached_payload;
 reg remote_owned,seen_active;reg [31:0] lease_age;
 wire [63:0] payload={remote_op,8'd0,remote_a,remote_b,remote_c};
 wire local_stop=press[0] || (press[3] && active);
 wire location_ok=(&bounds_ready) && remote_a>=300 && remote_a<=max_x && remote_b>=300 && remote_b<=max_y;
 wire point_ok=(&bounds_ready) && remote_a<4 && remote_b>=300 && remote_b<=max_x && remote_c>=300 && remote_c<=max_y;
 reg [7:0] decision;
 always @*begin
  decision=0;
  if(remote_op==0 || remote_op==11 || remote_op==12)decision=0;
  else if(|press)decision=4;
  else if(active)decision=1;
  else case(remote_op)
   1:if(remote_a>5)decision=2;
   2:if(remote_a>5)decision=2;else if(!motion_ready)decision=3;
   3:if(!motion_ready || !range_ready)decision=3;
   4:if(!motion_ready || !range_ready)decision=3;
   5:if(!location_ok)decision=2;
   6,8:if(!nav_ready)decision=3;
   7:if(!point_ok)decision=2;
   9:if(remote_a>1280 || remote_b>16384)decision=2;
   10:decision=0;
   default:decision=5;
  endcase
 end''')
ui=ui.replace('available_x,available_y,cell_x,cell_y,max_x,max_y;', 'available_x,available_y,cell_x,cell_y;')
ui=ui.replace(' reg [2:0] bounds_ready;\n', '')
ui=ui.replace('   page<=5;group_id<=0;', '''   cached<=0;cached_seq<=0;cached_status<=0;cached_payload<=0;
   ack_valid<=0;ack_seq<=0;ack_status<=0;remote_owned<=0;seen_active<=0;lease_age<=0;
   page<=5;group_id<=0;''')
ui=ui.replace('   demo_start<=0;single_start<=0;route_start<=0;stop_pulse<=0;calibrate_pulse<=0;\n   if((&bounds_ready)',
'''   demo_start<=0;single_start<=0;route_start<=0;stop_pulse<=0;calibrate_pulse<=0;
   ack_valid<=0;
   if(remote_owned)begin
    if(lease_age<CLK_HZ*2)lease_age<=lease_age+1'b1;
    if(active)seen_active<=1;
    if((seen_active && !active) || local_stop || (!active && press[2]))begin remote_owned<=0;seen_active<=0;end
    if(lease_age>=CLK_HZ*2)begin stop_pulse<=1;remote_owned<=0;seen_active<=0;end
   end
   if((&bounds_ready)''')
# Insert after the original physical-key handler, in the same sequential owner.
tail='''  end
 end
endmodule
'''
assert ui.endswith(tail)
ui=ui[:-len(tail)]+'''   if(remote_valid)begin
    // Heartbeats neither generate ACKs nor replace the last action's retry cache.
    if(remote_op==11)begin lease_age<=0;end
    else begin
     ack_valid<=1;ack_seq<=remote_seq;
     if(remote_op==0)begin
      stop_pulse<=1;remote_owned<=0;seen_active<=0;ack_status<=0;
      cached<=1;cached_seq<=remote_seq;cached_payload<=payload;cached_status<=0;
     end else if(cached && remote_seq==cached_seq)begin
      ack_status<=payload==cached_payload?cached_status:8'd6;
     end else begin
      cached<=1;cached_seq<=remote_seq;cached_payload<=payload;cached_status<=decision;
      ack_status<=decision;
      if(decision==0)begin
       lease_age<=0;
       case(remote_op)
        1:begin page<=remote_a[2:0];menu_view<=0;end
        2,3:begin
         page<=5;group_id<=remote_op==2?2:3;menu_view<=1;
         cursor<=remote_op==2?remote_a[3:0]+1'b1:4'd2;
         motion_selection<=remote_op==2?remote_a[2:0]:3'd0;
         slow_test<=remote_op==3;demo_start<=1;remote_owned<=1;seen_active<=0;
        end
        4:begin page<=5;group_id<=4;cursor<=1;menu_view<=1;calibrate_pulse<=1;end
        5:begin target_x<=remote_a;target_y<=remote_b;end
        6:begin page<=5;group_id<=4;cursor<=4;menu_view<=1;single_start<=1;remote_owned<=1;seen_active<=0;end
        7:begin xs[remote_a[1:0]]<=remote_b;ys[remote_a[1:0]]<=remote_c;end
        8:begin page<=5;group_id<=4;cursor<=6;menu_view<=1;route_start<=1;remote_owned<=1;seen_active<=0;end
        9:begin heading_kp<={16'd0,remote_a};heading_kd<={16'd0,remote_b};end
        10:begin page<=5;group_id<=0;cursor<=1;menu_view<=1;end
        default:begin end
       endcase
      end
     end
    end
   end
'''+tail
(p/'pc_ui.v').write_text(ui,encoding='utf-8')

bridge=(r/'basic_tasks/wireless_uart_bridge.v').read_text(encoding='utf-8-sig')
bridge=bridge.replace('module wireless_uart_bridge','module pc_wireless_bridge')
bridge=bridge.replace('input wire rx,rts,output wire tx);', '''input wire rx,rts,output wire tx,
 input wire ack_valid,input wire [7:0] ack_seq,ack_status,input wire control_frame_active,
 output wire [7:0] rx_data,output wire rx_valid,rx_error);''')
bridge=bridge.replace(' reg pending,boundary;', ''' assign rx_data=received;assign rx_valid=received_valid;assign rx_error=framing_error;
 reg ack_pending,reply_ack;reg [7:0] pending_seq,pending_status,reply_seq,reply_status;
 function [7:0] hex_digit(input [3:0] value);
  begin hex_digit=value<10?8'd48+value:8'd55+value;end
 endfunction
 function [7:0] ack_byte(input [3:0] index,input [7:0] seq,status);
  begin case(index)
   1:ack_byte="@";2:ack_byte=hex_digit(seq[7:4]);3:ack_byte=hex_digit(seq[3:0]);
   4:ack_byte=":";5:ack_byte=hex_digit(status[7:4]);6:ack_byte=hex_digit(status[3:0]);
   7:ack_byte=13;default:ack_byte=10;
  endcase end
 endfunction
 reg pending,boundary;''')
bridge=bridge.replace('wire reply_start=pending && boundary', 'wire reply_start=(pending || ack_pending) && boundary')
bridge=bridge.replace('pending<=0;boundary<=1;reply_index<=0;read_available<=0;',
'''pending<=0;boundary<=1;reply_index<=0;read_available<=0;
   ack_pending<=0;reply_ack<=0;pending_seq<=0;pending_status<=0;reply_seq<=0;reply_status<=0;''')
for char in ['?','P','R']:
 bridge=bridge.replace(f'if(received_valid && received=="{char}")',f'if(received_valid && !control_frame_active && received=="{char}")')
bridge=bridge.replace('tx_data<=reply_byte(1,overflow);send<=1;reply_index<=2;pending<=0;',
'''send<=1;reply_index<=2;reply_ack<=ack_pending;
    if(ack_pending)begin
     tx_data<=ack_byte(1,pending_seq,pending_status);reply_seq<=pending_seq;reply_status<=pending_status;ack_pending<=0;
    end else begin tx_data<=reply_byte(1,overflow);pending<=0;end''')
bridge=bridge.replace('tx_data<=reply_byte(reply_index,overflow);send<=1;',
 'tx_data<=reply_ack?ack_byte(reply_index,reply_seq,reply_status):reply_byte(reply_index,overflow);send<=1;')
bridge=bridge.replace('if(reply_index==15)', 'if(reply_ack?reply_index==8:reply_index==15)')
bridge=bridge.replace('  end\n end\nendmodule', '''   // A newer ACK arriving during transmission remains queued for the next line boundary.
   if(ack_valid)begin ack_pending<=1;pending_seq<=ack_seq;pending_status<=ack_status;end
  end
 end
endmodule''')
(p/'pc_wireless_bridge.v').write_text(bridge,encoding='utf-8')

top=(r/'basic_tasks/basic_tasks_top.v').read_text(encoding='utf-8-sig').replace('module basic_tasks_top','module pc_tasks_top')
top=top.replace(' basic_ui ui(', ''' wire command_valid,control_frame_active,pc_rx_valid,pc_rx_error,ack_valid;
 wire [7:0] command_seq,command_op,pc_rx_data,ack_seq,ack_status;
 wire [15:0] command_a,command_b,command_c;
 pc_command_rx commands(.clk(clk),.rst_n(rst_n),.data(pc_rx_data),.valid(pc_rx_valid),.framing_error(pc_rx_error),
  .command_valid(command_valid),.seq(command_seq),.operation(command_op),.a(command_a),.b(command_b),.c(command_c),.in_frame(control_frame_active));
 pc_ui ui(''')
top=top.replace('.key_n(key_n),.active(active),.calibrated(calibrated),', '''.key_n(key_n),.active(active),.calibrated(calibrated),
  .remote_valid(command_valid),.remote_seq(command_seq),.remote_op(command_op),.remote_a(command_a),.remote_b(command_b),.remote_c(command_c),
  .motion_ready(attitude_ready && imu_init && imu_fresh),.range_ready(range_fresh),.nav_ready(can_go),
  .ack_valid(ack_valid),.ack_seq(ack_seq),.ack_status(ack_status),''')
top=top.replace(' wireless_uart_bridge wireless(', ' pc_wireless_bridge wireless(')
top=top.replace('.rx(wireless_rx),.rts(wireless_rts),.tx(wireless_tx));', '''.rx(wireless_rx),.rts(wireless_rts),.tx(wireless_tx),
  .ack_valid(ack_valid),.ack_seq(ack_seq),.ack_status(ack_status),.control_frame_active(control_frame_active),
  .rx_data(pc_rx_data),.rx_valid(pc_rx_valid),.rx_error(pc_rx_error));''')
top=top.replace('  basic_wheel_speed_loop #(', '''  wire signed [15:0] sampled_target,drive;
  pc_motor_pipeline pipeline(.clk(clk),.rst_n(rst_n),.blocked(!active || stop_pulse || calibrate_pulse || (|faults)),
   .selected_target(targets[w]),.pid_duty(duties[w]),.target(sampled_target),.drive(drive));
  basic_wheel_speed_loop #(''')
top=top.replace('.target(targets[w]),.raw_speed', '.target(sampled_target),.raw_speed')
top=top.replace('  wire signed [15:0] drive=(|faults)?16\'sd0:-duties[w];\n','')
(p/'pc_tasks_top.v').write_text(top,encoding='utf-8')

project=(r/'basic_tasks.gprj').read_text(encoding='utf-8-sig')
project=project.replace('path="basic_tasks/basic_tasks_top.v"','path="pc_control/pc_tasks_top.v"')
project=project.replace('<FileList>', '''<FileList>
        <File path="pc_control/motor_pipeline.v" type="file.verilog" enable="1"/>
        <File path="pc_control/command_rx.v" type="file.verilog" enable="1"/>
        <File path="pc_control/pc_ui.v" type="file.verilog" enable="1"/>
        <File path="pc_control/pc_wireless_bridge.v" type="file.verilog" enable="1"/>''')
(r/'pc_tasks.gprj').write_text(project,encoding='utf-8')
print('Prepared isolated PC task control project; 97B3 files remain unchanged')
