"""SEEKFREE V2.4 desktop task controller. No auto-connect or auto-motion."""
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

from protocol import *


class Link:
    def __init__(self, events, serial_factory=None):
        self.events = events
        self.factory = serial_factory
        self.actions = queue.Queue()
        self.stop_event = threading.Event()
        self.close_event = threading.Event()
        self.thread = None

    def connect(self, port):
        if self.thread and self.thread.is_alive():
            raise ValueError('串口已连接或正在连接')
        self.stop_event.clear(); self.close_event.clear()
        while not self.actions.empty():
            self.actions.get_nowait()
        self.thread = threading.Thread(target=self.run, args=(port,), daemon=True)
        self.thread.start()

    def submit(self, commands):
        self.actions.put(commands)

    def run(self, port):
        import serial
        device = None
        commands = CommandQueue()
        # A fresh sequence reduces collision with a previous PC session's retry cache.
        import secrets
        commands.seq = secrets.randbelow(256)
        try:
            device = self.factory() if self.factory else serial.Serial()
            device.port = port; device.baudrate = 115200; device.timeout = 0
            device.write_timeout = .2; device.dtr = False; device.rts = False
            device.open()
            remote_ready = False
            commands.add([(HELLO,0,0,0)])
            self.events.put(('connection', True))
            self.events.put(('ready', False))
            last_heartbeat = 0; buffer = bytearray()
            def write(packet):
                if device.write(packet) != len(packet):
                    raise IOError('串口未能完整发送指令')
            while not self.close_event.is_set():
                now = time.monotonic()
                if self.stop_event.is_set():
                    self.stop_event.clear()
                    while not self.actions.empty():
                        self.actions.get_nowait()
                    commands.emergency_stop()
                try:
                    action = self.actions.get_nowait()
                    try:
                        if not remote_ready:raise ValueError('尚未完成固件握手，不能执行任务')
                        commands.add(action)
                    except ValueError as error:
                        self.events.put(('message', str(error)))
                except queue.Empty:
                    pass
                # Heartbeat never starts motion and does not replace the FPGA retry cache.
                if now-last_heartbeat >= .5:
                    write(encode(0, HEARTBEAT)); last_heartbeat = now
                packet = commands.next_packet(now)
                if packet:
                    write(packet)
                    self.events.put(('pending', True))
                try:
                    retry = commands.retry(now)
                    if retry:
                        write(retry)
                except TimeoutError as error:
                    self.events.put(('message', str(error)))
                    self.events.put(('pending', False))
                data = device.read(min(4096, max(1, device.in_waiting)))
                buffer.extend(data)
                if len(buffer) > 16384:
                    buffer.clear(); self.events.put(('message', '接收数据无完整行，已重新同步'))
                while b'\n' in buffer:
                    line, _, buffer = buffer.partition(b'\n')
                    text = line.decode('ascii', errors='replace').strip()
                    kind, value = parse_line(text)
                    if kind == 'ack':
                        seq, status = value
                        is_hello = commands.pending and commands.pending['packet'][4] == HELLO
                        if commands.acknowledge(seq, status):
                            if is_hello and status==0:
                                remote_ready=True;self.events.put(('ready',True))
                            elif is_hello and status==6:
                                commands.add([(HELLO,0,0,0)])
                            self.events.put(('message', f'{seq:02X}：{STATUS.get(status, "未知返回码")}'))
                            self.events.put(('pending', bool(commands.items)))
                    else:
                        self.events.put((kind, value))
                self.close_event.wait(.01)
        except Exception as error:
            self.events.put(('message', f'串口异常：{error}'))
        finally:
            if device and device.is_open:
                try:
                    # Explicit disconnect attempts STOP. Broken links fall back to FPGA lease expiry.
                    device.write(encode((commands.seq+1)&255, STOP))
                except Exception:
                    pass
                device.close()
            self.events.put(('pending', False))
            self.events.put(('ready', False))
            self.events.put(('connection', False))


class App:
    def __init__(self, root):
        self.root = root; self.events = queue.Queue(); self.link = Link(self.events)
        self.connected = False; self.remote_ready = False; self.pending = False; self.action_buttons = []
        root.title('小车任务控制台 · 逐飞无线串口')
        root.geometry('980x780')
        outer = ttk.Frame(root, padding=12); outer.pack(fill='both', expand=True)
        connect = ttk.Frame(outer); connect.pack(fill='x')
        ttk.Label(connect, text='逐飞USB端串口').pack(side='left')
        self.port = ttk.Combobox(connect, width=30, state='readonly'); self.port.pack(side='left', padx=8)
        ttk.Button(connect, text='刷新', command=self.refresh).pack(side='left')
        self.connect_button = ttk.Button(connect, text='连接', command=self.toggle); self.connect_button.pack(side='left', padx=8)
        tk.Button(connect, text='停止任务 / Esc', bg='#b42318', fg='white', command=self.stop).pack(side='right')
        self.state = tk.StringVar(value='未连接；需要支持电脑控制的新固件，97A2/97B3不能执行这些任务指令')
        ttk.Label(outer, textvariable=self.state, wraplength=940).pack(fill='x', pady=8)
        self.metrics = tk.StringVar(value='等待遥测')
        ttk.Label(outer, textvariable=self.metrics, wraplength=940, font=('Microsoft YaHei UI', 11)).pack(fill='x', pady=6)
        self.attitude=tk.StringVar(value='姿态角：等待IMU数据')
        self.encoders=tk.StringVar(value='四轮编码器：等待数据')
        self.tof=tk.StringVar(value='TOF：等待初始化状态');self.tof_mm=None;self.tof_ok=False
        for variable in (self.attitude,self.encoders,self.tof):ttk.Label(outer,textvariable=variable,wraplength=940).pack(fill='x',pady=2)
        tabs = ttk.Notebook(outer); tabs.pack(fill='x')
        motion = ttk.Frame(tabs, padding=12); tabs.add(motion, text='运动测试')
        for i, title in enumerate(['前进4秒', '后退4秒', '前进左转', '前进右转', '原地左转30°', '原地右转30°']):
            self.button(motion, title, lambda n=i: self.send([(MOTION,n,0,0)])).grid(row=i//3,column=i%3,padx=6,pady=8,sticky='ew')
        self.button(motion, '接近障碍减速 / 停车', lambda:self.send([(APPROACH,0,0,0)])).grid(row=2,column=0,columnspan=3,pady=8)
        ttk.Label(motion, text='ACK表示指令被接受；实际任务进度以遥测状态为准。避障测试需要正常雷达数据。').grid(row=3,column=0,columnspan=3)
        nav = ttk.Frame(tabs,padding=12);tabs.add(nav,text='坐标与导航')
        self.button(nav,'校准边框坐标系',lambda:self.send([(CALIBRATE,0,0,0)])).grid(row=0,column=0,pady=8)
        self.goal_x=self.number(nav,'目标X（厘米）',100,1,0);self.goal_y=self.number(nav,'目标Y（厘米）',100,1,2)
        self.button(nav,'只设置目标',lambda:self.goal(False)).grid(row=2,column=0,pady=8)
        self.button(nav,'设置目标并出发',lambda:self.goal(True)).grid(row=2,column=2,pady=8)
        self.points=[]
        for i,(x,y) in enumerate([(50,50),(150,50),(150,150),(50,150)]):
            px=self.number(nav,f'点{i+1} X（厘米）',x,3+i,0)
            py=self.number(nav,f'Y',y,3+i,2);self.points.append((px,py))
        self.button(nav,'上传四个点',lambda:self.route(False)).grid(row=7,column=0,pady=8)
        self.button(nav,'上传四点并出发',lambda:self.route(True)).grid(row=7,column=2,pady=8)
        ttk.Label(nav,text='先静止校准，再设置场地内坐标。任一设置被拒绝，就取消后续出发指令。').grid(row=8,column=0,columnspan=4)
        settings=ttk.Frame(tabs,padding=12);tabs.add(settings,text='显示与航向参数')
        for i,name in enumerate(['编码器 / 姿态 / TOF','航向参数','原始IMU','控制诊断','摄像头','雷达']):
            self.button(settings,name,lambda n=i:self.send([(PAGE,n,0,0)])).grid(row=i//3,column=i%3,padx=5,pady=8)
        self.button(settings,'返回板上主菜单',lambda:self.send([(MENU,0,0,0)])).grid(row=2,column=0,pady=8)
        self.kp=self.number(settings,'航向P（与板上数值一致）',320,3,0,step=8)
        self.kd=self.number(settings,'航向D',2560,3,2,step=256)
        self.button(settings,'应用P/D',self.gains).grid(row=4,column=0,pady=8)
        ttk.Label(settings,text='参数本次上电有效；这里只切换TFT画面，摄像头图像不通过无线串口传输。').grid(row=5,column=0,columnspan=4)
        self.log=tk.Text(outer,height=12,state='disabled',font=('Consolas',9));self.log.pack(fill='both',expand=True,pady=8)
        root.bind('<Escape>',lambda event:self.stop())
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.refresh();self.update_buttons();root.after(50,self.poll)

    def button(self,parent,text,command):
        button=ttk.Button(parent,text=text,command=command);self.action_buttons.append(button);return button

    def number(self,parent,label,value,row,col,step=5):
        ttk.Label(parent,text=label).grid(row=row,column=col,padx=4,pady=4)
        variable=tk.StringVar(value=str(value))
        ttk.Spinbox(parent,from_=0,to=65535,increment=step,textvariable=variable,width=10).grid(row=row,column=col+1,padx=4)
        return variable

    def refresh(self):
        from serial.tools import list_ports
        self.ports={f'{p.device} · {p.description}':p.device for p in list_ports.comports()}
        self.port['values']=list(self.ports)
        if self.ports and self.port.get() not in self.ports:self.port.current(0)

    def toggle(self):
        if self.connected:
            self.link.close_event.set();self.connect_button.configure(state='disabled')
        elif self.port.get() in self.ports:
            self.connect_button.configure(state='disabled')
            self.link.connect(self.ports[self.port.get()])

    def send(self,commands):
        if not self.connected:
            return
        self.pending=True;self.update_buttons();self.link.submit(commands)

    def stop(self):
        if self.connected:self.link.stop_event.set();self.state.set('正在发送停止指令')

    def values(self,variables,scale=1):
        values=[]
        for variable in variables:
            number=float(variable.get())*scale
            if not number.is_integer() or not 0<=number<=65535:raise ValueError('请输入范围内的整数毫米或参数')
            values.append(int(number))
        return values

    def goal(self,go):
        try:
            x,y=self.values([self.goal_x,self.goal_y],10)
            self.send([(GOAL,x,y,0)]+([(GO,0,0,0)] if go else []))
        except ValueError as error:messagebox.showerror('输入有误',str(error))

    def route(self,go):
        try:
            commands=[]
            for i,(px,py) in enumerate(self.points):
                x,y=self.values([px,py],10);commands.append((POINT,i,x,y))
            self.send(commands+([(ROUTE,0,0,0)] if go else []))
        except ValueError as error:messagebox.showerror('输入有误',str(error))

    def gains(self):
        try:
            p,d=self.values([self.kp,self.kd]);self.send([(GAINS,p,d,0)])
        except ValueError as error:messagebox.showerror('输入有误',str(error))

    def update_buttons(self):
        for button in self.action_buttons:button.configure(state='normal' if self.connected and self.remote_ready and not self.pending else 'disabled')

    def poll(self):
        for _ in range(250):
            try:kind,value=self.events.get_nowait()
            except queue.Empty:break
            if kind=='connection':
                self.connected=value;self.connect_button.configure(state='normal',text='断开' if value else '连接')
                self.state.set('串口已打开，等待任务指令确认；不自动执行运动' if value else '已断开连接')
            elif kind=='pending':self.pending=value
            elif kind=='ready':
                self.remote_ready=value
                if value:self.state.set('电脑控制握手成功；等待你选择任务，不自动运动')
            elif kind=='message':self.state.set(value)
            elif kind=='task':
                v=value;self.metrics.set(f'运行：{v["active"]}  建系：{v["calibrated"]}  雷达：{v["radar"]}  可出发：{v["can_go"]}  '
                    f'位置({v["x_cm"]:.1f}, {v["y_cm"]:.1f})cm  坐标系航向{v["yaw_deg"]:.2f}°  '
                    f'动作状态{v["demo"]} / 导航状态{v["mission"]}  路径点{v["waypoint"]}')
            elif kind=='attitude' and all(k in value for k in ('R','P','Y')):
                self.attitude.set(f'Roll {value["R"]:.2f}°    Pitch {value["P"]:.2f}°    Yaw {value["Y"]:.2f}°')
            if kind=='text':
                import re
                if value.startswith('LF='):
                    names={'LF':'左前','RF':'右前','LB':'左后','RB':'右后'}
                    rows=re.findall(r'(LF|RF|LB|RB)=([+-]\d+) V=([+-]\d+)',value)
                    if len(rows)==4:self.encoders.set('    '.join(f'{names[n]}：计数{int(c)} 速度{int(s)}' for n,c,s in rows)+'（计数/10ms）')
                if value.startswith('TOF='):
                    try:self.tof_mm=int(value[4:])
                    except ValueError:pass
                flag=re.search(r'TOF_INIT=([01])',value)
                if flag:self.tof_ok=flag[1]=='1'
                self.tof.set(f'TOF：{self.tof_mm} mm' if self.tof_ok and self.tof_mm is not None else 'TOF：未初始化／等待有效数据')
            if kind in ('text','attitude','message'):
                self.log.configure(state='normal');self.log.insert('end',str(value)+'\n')
                if int(self.log.index('end-1c').split('.')[0])>500:self.log.delete('1.0','101.0')
                self.log.see('end');self.log.configure(state='disabled')
        self.update_buttons();self.root.after(50,self.poll)

    def close(self):
        self.link.close_event.set()
        self.root.withdraw()
        deadline=time.monotonic()+1
        def finish():
            if not self.link.thread or not self.link.thread.is_alive() or time.monotonic()>=deadline:self.root.destroy()
            else:self.root.after(20,finish)
        finish()


if __name__=='__main__':
    root=tk.Tk();app=App(root)
    import sys
    if '--smoke' in sys.argv:
        root.withdraw();root.update();assert not app.connected;root.destroy();print('PASS desktop GUI creates without opening a port')
    else:root.mainloop()
