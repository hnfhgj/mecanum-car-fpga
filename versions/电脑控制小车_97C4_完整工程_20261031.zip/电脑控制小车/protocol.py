"""PC task protocol v1. Pure encode/parse functions; never opens hardware."""
import re
import struct

STOP, PAGE, MOTION, APPROACH, CALIBRATE, GOAL, GO, POINT, ROUTE, GAINS, MENU, HEARTBEAT = range(12)
HELLO = 12
STATUS = {0: '指令已接受', 1: '任务运行中，拒绝修改/重复启动', 2: '参数或坐标超出允许范围',
          3: '传感器/定位尚未就绪', 4: '板上按键优先', 5: '不支持的指令', 6: '序号冲突，请重新操作'}


def encode(seq, op, a=0, b=0, c=0):
    if not 0 <= seq <= 255 or not 0 <= op <= 255:
        raise ValueError('序号和指令必须为0～255')
    if any(not 0 <= x <= 65535 for x in (a, b, c)):
        raise ValueError('参数必须为0～65535')
    body = struct.pack('>BBBHHH', 1, seq, op, a, b, c)
    return b'\xa5\x5a' + body + bytes([sum(body) & 255]) + b'\r\n'


def parse_line(line):
    ack = re.fullmatch(r'@([0-9A-Fa-f]{2}):([0-9A-Fa-f]{2})', line)
    if ack:
        return 'ack', (int(ack[1], 16), int(ack[2], 16))
    if re.fullmatch(r'IO HEX=[0-9A-Fa-f]{42}', line):
        data = bytes.fromhex(line[7:])
        if data[:3] != b'BT\x01':
            return 'text', line
        flags = data[3]
        x, y, yaw, tx, ty, front, back = struct.unpack('>hhhHHHH', data[7:])
        return 'task', dict(active=bool(flags & 2), calibrated=bool(flags & 32),
                            radar=bool(flags & 16), pose=bool(flags & 8), can_go=bool(flags & 4),
                            demo=data[4] >> 4, mission=data[4] & 15, waypoint=1+((data[5] >> 2) & 3),
                            x_cm=x/10, y_cm=y/10, yaw_deg=yaw/100,
                            goal_x_cm=tx/10, goal_y_cm=ty/10, front_cm=front/10, back_cm=back/10)
    if line.startswith('ATT '):
        values = dict(re.findall(r'([RPY])=([+-]\d+)', line))
        return 'attitude', {k: int(v)/100 for k, v in values.items()}
    return 'text', line


class CommandQueue:
    """Only one action awaits ACK. A failed step cancels the remaining batch."""
    def __init__(self):
        from collections import deque
        self.items = deque()
        self.pending = None
        self.seq = 0

    def add(self, commands):
        # Reject queueing a second operator action behind a running submission.
        if self.items or self.pending:
            raise ValueError('上一组指令尚未确认，请等待，或点击停止')
        self.items.extend(commands)

    def emergency_stop(self):
        self.items.clear()
        self.pending = None
        self.items.append((STOP, 0, 0, 0))

    def next_packet(self, now):
        if self.pending or not self.items:
            return None
        self.seq = (self.seq + 1) & 255
        command = self.items.popleft()
        packet = encode(self.seq, *command)
        self.pending = dict(seq=self.seq, packet=packet, last=now, retries=0)
        return packet

    def acknowledge(self, seq, status):
        if not self.pending or seq != self.pending['seq']:
            return False
        self.pending = None
        if status:
            self.items.clear()
        return True

    def retry(self, now):
        if not self.pending or now-self.pending['last'] < 1:
            return None
        if self.pending['retries'] >= 2:
            self.items.clear()
            self.pending = None
            raise TimeoutError('未收到指令确认：不要把“已发送”当成小车已执行；请检查固件和无线链路')
        self.pending['last'] = now
        self.pending['retries'] += 1
        return self.pending['packet']
