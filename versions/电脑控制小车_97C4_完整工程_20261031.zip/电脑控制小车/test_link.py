"""Desktop transport smoke test with a fake serial device, never real hardware."""
import queue
import threading
import time
import unittest
from controller import Link
from protocol import *


class FakeSerial:
    def __init__(self):
        self.is_open=False;self.buffer=bytearray();self.writes=[];self.lock=threading.Lock()

    def open(self):self.is_open=True
    def close(self):self.is_open=False

    @property
    def in_waiting(self):
        with self.lock:return len(self.buffer)

    def read(self,n):
        with self.lock:
            result=bytes(self.buffer[:n]);del self.buffer[:n];return result

    def write(self,data):
        assert len(data)==14 and data[:3]==bytes.fromhex('A5 5A 01')
        assert data[11]==sum(data[2:11])&255
        with self.lock:
            self.writes.append(data)
            if data[4]!=HEARTBEAT:
                status=2 if data[4]==GOAL else 0
                self.buffer.extend(f'@{data[3]:02X}:{status:02X}\r\n'.encode())
        return len(data)


class LinkTests(unittest.TestCase):
    def test_old_firmware_cannot_enable_tasks(self):
        class OldSerial(FakeSerial):
            def write(self,data):
                with self.lock:self.writes.append(data)
                return len(data)
        events=queue.Queue();device=OldSerial();link=Link(events,lambda:device)
        link.connect('FAKE_OLD')
        try:
            deadline=time.monotonic()+1
            while time.monotonic()<deadline:
                kind,value=events.get(timeout=1)
                if kind=='connection' and value:break
            link.submit([(MOTION,0,0,0)])
            rejected=False;deadline=time.monotonic()+1
            while time.monotonic()<deadline:
                kind,value=events.get(timeout=1)
                if kind=='message' and '握手' in value:rejected=True;break
            self.assertTrue(rejected)
            self.assertNotIn(MOTION,[p[4] for p in device.writes])
        finally:
            link.close_event.set();link.thread.join(timeout=2)

    def test_handshake_no_auto_motion_and_rejected_goal_no_go(self):
        events=queue.Queue();device=FakeSerial();link=Link(events,lambda:device)
        link.connect('FAKE')
        try:
            deadline=time.monotonic()+2;ready=False
            while time.monotonic()<deadline and not ready:
                kind,value=events.get(timeout=1)
                ready=kind=='ready' and value
            self.assertTrue(ready)
            self.assertTrue(all(p[4] in (HELLO,HEARTBEAT) for p in device.writes))
            link.submit([(GOAL,500,600,0),(GO,0,0,0)])
            deadline=time.monotonic()+2
            while time.monotonic()<deadline:
                kind,value=events.get(timeout=1)
                if kind=='message' and '范围' in value:break
            self.assertIn(GOAL,[p[4] for p in device.writes])
            self.assertNotIn(GO,[p[4] for p in device.writes])
            link.stop_event.set()
            deadline=time.monotonic()+1
            while time.monotonic()<deadline and not any(p[4]==STOP for p in device.writes):time.sleep(.01)
            self.assertTrue(any(p[4]==STOP for p in device.writes))
        finally:
            link.close_event.set();link.thread.join(timeout=2)
        self.assertFalse(device.is_open)


if __name__=='__main__':unittest.main()
