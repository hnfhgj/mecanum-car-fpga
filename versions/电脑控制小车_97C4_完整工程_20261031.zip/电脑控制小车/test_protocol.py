import unittest
import struct
from protocol import *


class ProtocolTests(unittest.TestCase):
    def test_reference_frame(self):
        # Same seq=0x50/op=9/a=0x52/b=0x3F frame checked by Verilog UART test.
        self.assertEqual(encode(0x50,9,0x52,0x3f), bytes.fromhex('A5 5A 01 50 09 00 52 00 3F 00 00 EB 0D 0A'))

    def test_negative_or_overflow_rejected(self):
        for value in [-1,65536]:
            with self.assertRaises(ValueError):encode(1,GOAL,value)

    def test_ack(self):
        self.assertEqual(parse_line('@50:03'),('ack',(80,3)))
        self.assertEqual(parse_line('x@50:03')[0],'text')

    def test_live_fields(self):
        raw=b'BT\x01'+bytes([0x7e,0x45,0x14,2])+struct.pack('>hhhHHHH',-50,1200,-1234,1500,500,700,1000)
        kind,state=parse_line('IO HEX='+raw.hex().upper())
        self.assertEqual(kind,'task');self.assertEqual(state['x_cm'],-5)
        self.assertEqual(state['yaw_deg'],-12.34);self.assertEqual(state['waypoint'],2)
        self.assertTrue(state['can_go']);self.assertEqual(state['mission'],5)

    def test_batch_waits_for_ack_and_failure_cancels_departure(self):
        q=CommandQueue();q.add([(GOAL,500,600,0),(GO,0,0,0)])
        packet=q.next_packet(0);self.assertIsNone(q.next_packet(.1))
        self.assertEqual(q.retry(1.1),packet)
        self.assertTrue(q.acknowledge(q.seq,2));self.assertIsNone(q.next_packet(2))

    def test_stop_cancels_motion_retries_and_queued_go(self):
        q=CommandQueue();q.add([(MOTION,0,0,0),(GO,0,0,0)])
        q.next_packet(0);old=q.seq;q.emergency_stop();packet=q.next_packet(.2)
        self.assertEqual(packet[4],STOP);self.assertFalse(q.acknowledge(old,0))
        self.assertEqual(q.retry(1.3)[4],STOP)

    def test_timeout_does_not_launch_next_step(self):
        q=CommandQueue();q.add([(POINT,0,500,500),(ROUTE,0,0,0)])
        q.next_packet(0);q.retry(1.1);q.retry(2.2)
        with self.assertRaises(TimeoutError):q.retry(3.3)
        self.assertIsNone(q.next_packet(4))


if __name__=='__main__':unittest.main()
