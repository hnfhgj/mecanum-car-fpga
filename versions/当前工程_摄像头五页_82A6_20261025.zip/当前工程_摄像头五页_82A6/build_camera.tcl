# Portable offline build. This script never programs hardware.
set package_root [file dirname [file normalize [info script]]]
cd $package_root
foreach required {src/imu660ra_config.hex src/dl1b_config.hex constraints/camera_board.cst constraints/camera_verified.sdc} {
 if {![file exists $required]} {error "Required project file missing: $required"}
}
open_project [file join $package_root camera_dashboard.gprj] -pn GW5AT-LV60PG484AC1/I0 -device_version B
set_option -top_module camera_dashboard_top
set_option -output_base_name camera_dashboard
set_option -use_sspi_as_gpio 1
run all
run close
exit
