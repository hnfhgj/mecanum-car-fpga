# Refuse to create a hardware image until board-specific bindings exist.
set camera_cst USER_HOME/Desktop/gaoyun/motor/camera_build/camera_board.cst
set camera_sdc USER_HOME/Desktop/gaoyun/motor/camera_build/camera_verified.sdc
if {![file exists $camera_cst] || ![file exists $camera_sdc]} {
 error "Camera 60K P4 pinout and timing are NOT verified. Provide camera_verified.cst and camera_verified.sdc; do not use 138K ball assignments."
}
open_project USER_HOME/Desktop/gaoyun/motor/camera_build/camera_dashboard.gprj -pn GW5AT-LV60PG484AC1/I0 -device_version B
cd USER_HOME/Desktop/gaoyun/motor
foreach init_file {src/imu660ra_config.hex src/dl1b_config.hex} {
 if {![file exists $init_file]} {error "Missing required sensor ROM: $init_file"}
}
set_option -top_module camera_dashboard_top
set_option -output_base_name camera_dashboard
set_option -use_sspi_as_gpio 1
run all
run close
exit
