// Repaired-board heading dashboard. Set MOTORS_ENABLE=0 for display-only benches.
// Camera pins are NOT guessed from the incompatible 138K schematic.
module dashboard_top #(
    parameter integer MOTORS_ENABLE=1
)(
    input wire clk,rst_n,
    input wire [3:0] key_n,
    input wire lf_ea,lf_eb,rf_ea,rf_eb,lb_ea,lb_eb,rb_ea,rb_eb,
    output wire lf_dir,lf_pwm,rf_dir,rf_pwm,lb_dir,lb_pwm,rb_dir,rb_pwm,
    output wire uart_tx,
    output wire imu_sck,imu_mosi,imu_cs_n,
    input wire imu_miso,
    output wire tof_scl,
    inout wire tof_sda,
    output wire tof_xs,
    input wire tof_int,
    output wire tft_scl,tft_sda,tft_reset,tft_dc,tft_cs_n,tft_bl
);
    wire lf_dir_i,lf_pwm_i,rf_dir_i,rf_pwm_i;
    wire lb_dir_i,lb_pwm_i,rb_dir_i,rb_pwm_i;
    assign lf_dir=MOTORS_ENABLE ? lf_dir_i : 1'b0;
    assign lf_pwm=MOTORS_ENABLE ? lf_pwm_i : 1'b0;
    assign rf_dir=MOTORS_ENABLE ? rf_dir_i : 1'b0;
    assign rf_pwm=MOTORS_ENABLE ? rf_pwm_i : 1'b0;
    assign lb_dir=MOTORS_ENABLE ? lb_dir_i : 1'b0;
    assign lb_pwm=MOTORS_ENABLE ? lb_pwm_i : 1'b0;
    assign rb_dir=MOTORS_ENABLE ? rb_dir_i : 1'b0;
    assign rb_pwm=MOTORS_ENABLE ? rb_pwm_i : 1'b0;
    motor_top #(.DASHBOARD_ENABLE(1),.OUTPUTS_ENABLED(MOTORS_ENABLE),.NO_FEEDBACK_GUARD(MOTORS_ENABLE ? 1 : 0)) u_car(
        .clk(clk),.rst_n(rst_n),.key_n(key_n),
        .camera_valid(1'b0),.camera_init_done(1'b0),.camera_fault(1'b0),
        .camera_pixel(16'd0),.camera_rd_addr(),.camera_frame_start(),.camera_frame_end(),
        .lf_ea(lf_ea),.lf_eb(lf_eb),.rf_ea(rf_ea),.rf_eb(rf_eb),
        .lb_ea(lb_ea),.lb_eb(lb_eb),.rb_ea(rb_ea),.rb_eb(rb_eb),
        .lf_dir(lf_dir_i),.lf_pwm(lf_pwm_i),.rf_dir(rf_dir_i),.rf_pwm(rf_pwm_i),
        .lb_dir(lb_dir_i),.lb_pwm(lb_pwm_i),.rb_dir(rb_dir_i),.rb_pwm(rb_pwm_i),
        .uart_tx(uart_tx),.imu_sck(imu_sck),.imu_mosi(imu_mosi),
        .imu_cs_n(imu_cs_n),.imu_miso(imu_miso),
        .tof_scl(tof_scl),.tof_sda(tof_sda),.tof_xs(tof_xs),.tof_int(tof_int),
        .tft_scl(tft_scl),.tft_sda(tft_sda),.tft_reset(tft_reset),
        .tft_dc(tft_dc),.tft_cs_n(tft_cs_n),.tft_bl(tft_bl));
endmodule
