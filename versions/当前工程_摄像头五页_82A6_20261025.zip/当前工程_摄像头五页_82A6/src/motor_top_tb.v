//============================================================================
// motor_top_tb.v —— 顶层仿真测试台（可选，用于上板前验证 PWM 波形）
//
// 在 Gowin IDE 或 ModelSim 中仿真，观察：
//   - 四轮 pwm 周期约 58.82us（17kHz），占空比441/2941约15%，错相
//   - 四轮DIR=1，保持已修正的方向参数
//============================================================================
`timescale 1ns / 1ps

module motor_top_tb;

    reg  clk;
    reg  rst_n;
    wire lf_dir, lf_pwm;
    wire rf_dir, rf_pwm;
    wire lb_dir, lb_pwm;
    wire rb_dir, rb_pwm;
    reg ea = 0, eb = 0;
    integer highs, lf_highs, rf_highs, lb_highs, j;
    reg passed = 0;

    motor_top #(.USE_CLOSED_LOOP(0)) uut(
        .clk    (clk),
        .rst_n  (rst_n),
        .lf_ea(ea), .lf_eb(eb), .rf_ea(ea), .rf_eb(eb),
        .lb_ea(ea), .lb_eb(eb), .rb_ea(ea), .rb_eb(eb),
        .imu_miso(1'b1), .tof_int(1'b1),
        .uart_tx(), .imu_sck(), .imu_mosi(), .imu_cs_n(),
        .tof_scl(), .tof_sda(), .tof_xs(),
        .tft_scl(), .tft_sda(), .tft_reset(), .tft_dc(), .tft_cs_n(), .tft_bl(),
        .lf_dir (lf_dir),
        .lf_pwm (lf_pwm),
        .rf_dir (rf_dir),
        .rf_pwm (rf_pwm),
        .lb_dir (lb_dir),
        .lb_pwm (lb_pwm),
        .rb_dir (rb_dir),
        .rb_pwm (rb_pwm)
    );

    // 50MHz 时钟：周期 20ns
    initial clk = 1'b0;
    always #10 clk = ~clk;

    initial begin
        rst_n = 1'b0;
        #100;
        if ({lf_pwm, rf_pwm, lb_pwm, rb_pwm} !== 4'b0000)
            $fatal(1, "PWM must be off during reset");
        @(negedge clk); rst_n = 1'b1;
        repeat(2941) @(negedge clk);
        highs = 0;
        lf_highs=0; rf_highs=0; lb_highs=0;
        repeat(2941) begin
            @(negedge clk);
            if ({rb_dir, lb_dir, rf_dir, lf_dir} !== 4'b1111)
                $fatal(1, "Default motor direction mismatch");
            if (({2'b0,lf_pwm}+{2'b0,rf_pwm}+{2'b0,lb_pwm}+{2'b0,rb_pwm})>1)
                $fatal(1, "15 percent phase-staggered pulses must not overlap");
            if (lf_pwm) lf_highs=lf_highs+1;
            if (rf_pwm) rf_highs=rf_highs+1;
            if (lb_pwm) lb_highs=lb_highs+1;
            if (rb_pwm) highs = highs + 1;
        end
        if (highs != 441 || lf_highs!=441 || rf_highs!=441 || lb_highs!=441)
            $fatal(1, "Each PWM must have 441 high clocks per period");
        if (uut.MOTOR_REVERSE !== 4'b1111 || uut.TEST_WHEEL_MASK !== 4'b1111)
            $fatal(1, "Expected all motor polarities reversed and all wheels enabled");
        if (uut.USE_CLOSED_LOOP != 0 || uut.system_fault !== 1'b0)
            $fatal(1, "Expected open-loop test mode without feedback fault");
        for (j = 0; j < 10; j = j + 1) begin
            eb = 1; repeat(10) @(negedge clk);
            ea = 1; repeat(10) @(negedge clk);
            eb = 0; repeat(10) @(negedge clk);
            ea = 0; repeat(10) @(negedge clk);
        end
        if ($signed(uut.lf_count) != -40 || uut.rf_count != 40 || uut.lb_count != 40 || $signed(uut.rb_count) != -40)
            $fatal(1, "Quadrature count mismatch");
        wait(uut.lf_tick); @(negedge clk);
        if (uut.lf_speed != -40 || uut.rf_speed != 40 || uut.lb_speed != 40 || uut.rb_speed != -40)
            $fatal(1, "Encoder speed mismatch");
        // Reverse the physical A/B sequence: LF/RB must invert both signs,
        // while RF/LB remain unchanged. Check the next 10ms speed delta too.
        for (j = 0; j < 20; j = j + 1) begin
            ea = 1; repeat(10) @(negedge clk);
            eb = 1; repeat(10) @(negedge clk);
            ea = 0; repeat(10) @(negedge clk);
            eb = 0; repeat(10) @(negedge clk);
        end
        if ($signed(uut.lf_count) != 40 || $signed(uut.rf_count) != -40 ||
            $signed(uut.lb_count) != -40 || $signed(uut.rb_count) != 40)
            $fatal(1, "Reverse quadrature count mismatch");
        wait(uut.lf_tick); @(negedge clk);
        if (uut.lf_speed != 80 || uut.rf_speed != -80 || uut.lb_speed != -80 || uut.rb_speed != 80)
            $fatal(1, "Reverse encoder speed mismatch");
        if ({rb_dir, lb_dir, rf_dir, lf_dir} !== 4'b1111)
            $fatal(1, "Encoder correction must not reverse motors");
        // Accelerate tick inputs, not the protection thresholds: no-feedback stop.
        force uut.lf_tick=1'b1; force uut.rf_tick=1'b1;
        force uut.lb_tick=1'b1; force uut.rb_tick=1'b1;
        force uut.lf_raw_speed=16'sd0; force uut.rf_raw_speed=16'sd0;
        force uut.lb_raw_speed=16'sd0; force uut.rb_raw_speed=16'sd0;
        repeat(52) @(negedge clk);
        if (uut.system_fault!==1'b1 || {lf_pwm,rf_pwm,lb_pwm,rb_pwm}!==0)
            $fatal(1, "Missing encoder feedback must latch global stop");
        rst_n=0; repeat(2) @(negedge clk); rst_n=1;
        force uut.lf_raw_speed=16'sd10; force uut.rf_raw_speed=16'sd10;
        force uut.lb_raw_speed=16'sd10; force uut.rb_raw_speed=16'sd10;
        repeat(1002) @(negedge clk);
        if (uut.system_fault!==1'b1 || {lf_pwm,rf_pwm,lb_pwm,rb_pwm}!==0)
            $fatal(1, "Ten-second diagnostic timeout must stop even with motion");
        rst_n = 0; #1;
        if ({lf_pwm, rf_pwm, lb_pwm, rb_pwm} !== 4'b0000)
            $fatal(1, "Reset must stop all PWM outputs");
        $display("PASS: four phase-staggered 441/2941 PWM, encoder corrections, reset, no-feedback and timeout stops");
        passed = 1;
        $finish;
    end

    initial begin #25000000; $fatal(1, "Motor timeout"); end

endmodule
