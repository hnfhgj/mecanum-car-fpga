// 25%-step translation scale. Shift/add only; no DSP, no heading scaling.
module task_translation_scale(input wire [6:0] base,input wire [2:0] level,output wire [15:0] scaled);
 reg [9:0] product;
 reg [9:0] value;
 // All built-in translation levels increase by 4/3; preserve zero stop.
 always @*case(base)
  0:value=0;15:value=20;30:value=40;45:value=60;60:value=80;90:value=120;
  default:value={3'd0,base};
 endcase
 always @*case(level)
  1:product=value;
  2:product=value<<1;
  3:product=(value<<1)+value;
  5:product=(value<<2)+value;
  6:product=(value<<2)+(value<<1);
  default:product=value<<2;
 endcase
 assign scaled={8'd0,product[9:2]};
endmodule
