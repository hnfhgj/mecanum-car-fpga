// Manual control only: independent +/-10.6 degree body-axis cones.
// Side-front returns cannot inhibit straight motion. Units are millimetres.
module directional_clearance #(parameter integer CLK_HZ=50000000)(
 input wire clk,rst_n,bad,point_valid,
 input wire signed [15:0] forward_mm,left_mm,
 input wire [15:0] angle_cdeg,range_mm,
 output wire fresh,output wire [3:0] blocked);
 reg previous_valid,collect;reg [15:0] previous_angle;
 reg [3:0] live,committed;reg [9:0] count;reg [31:0] age;
 wire wrap_scan=previous_valid && previous_angle>angle_cdeg+17'd18000;
 wire signed [31:0] f=forward_mm,l=left_mm;
 wire [31:0] af=f<0?-f:f,al=l<0?-l:l;
 wire good=range_mm>=50 && range_mm<=5000;
 wire longitudinal=(al<<4)<=((af<<1)+af);
 wire transverse=(af<<4)<=((al<<1)+al);
 wire [3:0] hit={transverse && l<0 && al<=180,transverse && l>0 && al<=180,
  longitudinal && f<0 && af<=250,longitudinal && f>0 && af<=250};
 assign fresh=age<CLK_HZ/4;
 assign blocked=fresh?(live|committed):4'b1111;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin previous_valid<=0;previous_angle<=0;collect<=0;count<=0;age<=32'hffffffff;live<=0;committed<=0;end
  else begin
   if(age!=32'hffffffff)age<=age+1'b1;
   if(bad)begin previous_valid<=0;collect<=0;age<=32'hffffffff;live<=0;committed<=0;count<=0;end
   else if(point_valid)begin
    previous_valid<=1;previous_angle<=angle_cdeg;
    if(wrap_scan)begin
     if(collect && count>=120)begin committed<=live;age<=0;end
     else age<=32'hffffffff;
     collect<=1;count<=0;live<=good?hit:4'd0;
    end else if(collect)begin
     // point_valid comes only from a CRC-validated packet. Far/no-return rays
     // still establish complete scan coverage; no wall detection is required.
     if(count<1023)count<=count+1'b1;
     if(good)live<=live|hit;
    end
   end
  end
 end
endmodule
