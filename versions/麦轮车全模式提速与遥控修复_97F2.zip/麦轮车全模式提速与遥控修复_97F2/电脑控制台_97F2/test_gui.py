"""Own-widget tests only: simulated data, no COM enumeration or real serial."""
import time,types,tkinter as tk,unittest
from unittest.mock import Mock
from protocol import SPEED
from controller import App

class GuiTests(unittest.TestCase):
 def setUp(self):
  self.root=tk.Tk();self.root.withdraw();self.app=App(self.root,demo=True,enumerate_ports=False);self.root.update_idletasks()
 def tearDown(self):
  self.assertIsNone(self.app.link.thread);self.root.destroy()
 def click_at(self,x,y):
  c=self.app.worlds[-1];self.app.draw_world(c);ox,oy,scale,*_=c._world_transform
  self.app.map_click(c,types.SimpleNamespace(x=ox+x*scale,y=oy-y*scale))
 def test_click_selects_without_autostart(self):
  self.click_at(100,110);self.assertEqual(self.app.goal_y.get(),'110');self.assertFalse(self.app.task['active'])
 def test_armed_click_starts_goal(self):
  self.app.click_go.set(True);self.click_at(100,110)
  self.assertTrue(self.app.task['active']);self.assertEqual(self.app.task['goal_y_cm'],110)
 def test_invalid_position_does_not_start(self):
  self.app.click_go.set(True);self.click_at(5,110);self.assertFalse(self.app.task['active'])
  self.app.task['pose']=False;self.click_at(100,110);self.assertFalse(self.app.task['active'])
 def test_manual_accepts_only_manual_running(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic()
  self.assertTrue(a.available('manual'));a.task['active']=True;self.assertFalse(a.available('manual'))
  a.task['manual']=True;self.assertTrue(a.available('manual'))
 def test_focus_loss_disarms(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic();a.current='radar';a.manual_armed.set(True)
  a.held_input=types.SimpleNamespace(foreground=lambda:False,mask=lambda:1);a.link.set_drive(1);a.poll_drive()
  self.assertFalse(a.manual_armed.get());self.assertEqual(a.link.drive_state[0],0)
 def test_manual_without_any_field_or_pose(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic()
  a.task.update(calibrated=False,pose=False,can_go=False,width_cm=0,height_cm=0,near=True,radar=False)
  self.assertTrue(a.available('manual'))
  a.render();self.assertEqual(a.variable('radar_state').get(),'有效扫描')
  a.show('radar');a.draw_world(a.radar_canvas)
  self.assertFalse(a.task['active']);self.assertIsNone(a.link.thread)
 def ready_manual(self):
  a=self.app;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic();a.current='radar';a.manual_armed.set(True)
  a.held_input=types.SimpleNamespace(foreground=lambda:True,mask=lambda:1)
  return a
 def test_speed_pending_pauses_without_disarming(self):
  a=self.ready_manual();a.pending=True;a.poll_drive()
  self.assertTrue(a.manual_armed.get());self.assertEqual(a.link.drive_state[0],0)
 def test_speed_ack_restores_focus_and_requires_release(self):
  a=self.ready_manual();a.root.focus_set=Mock();a.speed_choice.set('125');a.apply_speed()
  self.assertTrue(a.pending);a.poll_drive();self.assertTrue(a.manual_armed.get())
  a.on_command_sent(dict(seq=22,op=SPEED));a.on_command_ack(dict(seq=22,status=0));a.pending=False
  a.root.focus_set.assert_called_once();a.poll_drive();self.assertEqual(a.link.drive_state[0],0);self.assertIn('松开',a.variable('held_state').get())
  a.held_input.mask=lambda:0;a.poll_drive();a.held_input.mask=lambda:1;a.poll_drive()
  self.assertEqual(a.link.drive_state[0],1);self.assertTrue(a.manual_armed.get())
 def test_speed_rejected_does_not_freeze_manual(self):
  a=self.ready_manual();a.root.focus_set=Mock();a.apply_speed();a.on_command_sent(dict(seq=10,op=SPEED))
  a.on_command_ack(dict(seq=10,status=1));a.pending=False;a.held_input.mask=lambda:0;a.poll_drive()
  a.held_input.mask=lambda:8;a.poll_drive();self.assertEqual(a.link.drive_state[0],8)
 def test_disconnect_clears_speed_wait(self):
  a=self.ready_manual();a.speed_focus_pending=True;a.speed_seq=1;a.on_link_lost()
  self.assertFalse(a.speed_focus_pending);self.assertIsNone(a.speed_seq)
 def test_input_exception_stops_and_reschedules_instead_of_hanging(self):
  a=self.ready_manual();a.root.after=Mock()
  a.held_input.mask=lambda:(_ for _ in ()).throw(KeyError('popdown'))
  a.poll_drive();self.assertEqual(a.link.drive_state[0],0);self.assertFalse(a.manual_armed.get())
  a.root.after.assert_called_once_with(20,a.poll_drive)
 def test_normal_poll_has_exactly_one_next_timer(self):
  a=self.ready_manual();a.root.after=Mock();a.poll_drive()
  a.root.after.assert_called_once_with(20,a.poll_drive)

if __name__=='__main__':unittest.main(verbosity=2)

