from pathlib import Path
import math
p=Path(__file__).resolve().parent;r=p.parent
for name in ['top_tb.sv','control_tb.v','stream_tb.sv','cloud_stream_tb.sv','snapshot_tb.sv','manual_tb.sv','hold_top_tb.sv','speed_tb.sv','nav_tb.v']:
 s=(r/'drive_speedup'/name).read_text(encoding='utf-8').replace('drive_speedup_top','navigation_tuning_top').replace('97F2','97F3')
 if name=='top_tb.sv':s=s.replace("byte_send('hf2)","byte_send('hf3)").replace("byte_send('hbb)","byte_send('hbc)")
 if name=='control_tb.v':
  s=s.replace('wire [2:0] level;', 'wire [15:0] fb,lr;wire [1:0] cone;wire [2:0] level;')
  s=s.replace('drive_valid,drive_mask);','drive_valid,drive_mask,fb,lr,cone);')
  s=s.replace('range_ok=0;command(11','manual_range=0;command(11').replace('accepted");range_ok=1;','accepted");manual_range=1;range_ok=0;')
  s=s.replace('nav_ok=0;command(13','range_ok=1;nav_ok=0;command(13')
  s=s.replace('  passed=1;$display("PASS PC protocol', '''  manual_range=1;active=0;manual_active=0;
  if(fb!=400 || lr!=250 || cone!=2)$fatal(1,"Obstacle defaults changed");
  command(116,16,500,300,3,0);if(status || fb!=500 || lr!=300 || cone!=3)$fatal(1,"Obstacle settings failed");
  command(117,16,199,300,3,0);if(status!=2 || fb!=500)$fatal(1,"Small front bound accepted");
  command(118,16,801,300,3,0);if(status!=2)$fatal(1,"Large front bound accepted");
  command(119,16,400,149,2,0);if(status!=2)$fatal(1,"Small side bound accepted");
  command(120,16,400,601,2,0);if(status!=2)$fatal(1,"Large side bound accepted");
  command(121,16,400,250,0,0);if(status!=2)$fatal(1,"Invalid cone accepted");
  active=1;command(122,16,400,250,2,0);if(status!=1 || fb!=500)$fatal(1,"Busy settings accepted");
  active=0;range_ok=0;begin integer old_demo,old_single,old_route;
  old_demo=ndemo;old_single=nsingle;old_route=nroute;command(123,4,0,0,0,0);
  if(status || ncal!=2 || ndemo!=old_demo || nsingle!=old_single || nroute!=old_route)$fatal(1,"Static calibration requires old wall clearance or started motion");end
  passed=1;$display("PASS PC protocol''')
 if name in ['stream_tb.sv','cloud_stream_tb.sv']:
  old='425403F1546042FF9C01F4232803E803E807D003E805DC07D009C409C43997F3E1005AFFC40050'
  new='425404'+old[6:]+'019000FA0200B40900'
  s=s.replace(old,new).replace("312'h","384'h").replace('[0:77]','[0:95]').replace('i<78','i<96').replace('j<78','j<96')
  s=s.replace('424','442').replace('803','821').replace('i+87!=','i+105!=').replace('i+85]','i+103]').replace('i+86]','i+104]').replace('BT03','BT04')
 if name=='manual_tb.sv':
  s=s.replace('wire fresh;wire [3:0] blocked;', 'reg [15:0] fb=250,lr=180;reg [1:0] mode=1;wire fresh;wire [3:0] blocked;')
  s=s.replace('range,fresh,blocked);','range,fresh,blocked,fb,lr,mode);')
  s=s.replace('pv=0;\nend endtask','pv=0;repeat(3)@(negedge clk);\nend endtask')
  s=s.replace(' repeat(25010)', ''' fb=400;lr=250;mode=2;
 point(200,350,100,364);if(blocked!=1)$fatal(1,"Wider/longer front cone not effective");
 point(400,80,240,253);if(blocked!=5)$fatal(1,"New side range not effective");
 scan();scan();scan();point(0,1000,1000,1400);
 point(200,350,150,381);if(blocked)$fatal(1,"Medium cone includes wide side return");
 mode=3;point(400,350,150,381);if(blocked!=1)$fatal(1,"Wide cone mode ignored");
 scan();scan();scan();point(0,1000,1000,1400);
 fb=200;point(200,350,0,350);if(blocked)$fatal(1,"Configurable front limit ignored");
 repeat(25010)''')
 (p/name).write_text(s,encoding='utf-8')
s=(r/'drive_speedup/run_tests.ps1').read_text(encoding='utf-8').replace('drive_speedup.gprj','navigation_tuning.gprj').replace('speedup_97F2','navigation_97F3')
s=s.replace("(Join-Path $testRoot 'hold_top_tb.sv') @rtl", "(Join-Path $testRoot 'hold_top_tb.sv') (Join-Path $testRoot 'frame_tb.v') @rtl")
s=s.replace("'snapshot_tb','hold_top_tb'))", "'snapshot_tb','hold_top_tb','square_frame_tb'))")
s=s.replace('Set-Location -LiteralPath $simRoot', '''New-Item -ItemType Directory -Force -Path (Join-Path $simRoot 'square_nav') | Out-Null
foreach ($f in @('frame_fixture.txt','frame_live.txt','frame_missing.txt')) {
 Copy-Item -LiteralPath (Join-Path $testRoot $f) -Destination (Join-Path $simRoot "square_nav/$f")
}
Set-Location -LiteralPath $simRoot''')
(p/'run_tests.ps1').write_text(s,encoding='utf-8')
s=(r/'square_nav/frame_tb.v').read_text(encoding='utf-8')
s=s.replace('%d %d %d %d\\n','%h %h %h %h\\n')
s=s.replace('wire [9:0] count;', 'wire [3:0] reason;wire [9:0] count;').replace('width,height,quality);','width,height,quality,reason);')
s=s.replace('height<1950 || height>2050','height<1150 || height>1250').replace(' ||\n     correction',' || reason!=9 ||\n     correction')
s=s.replace('PASS: square frame','PASS rectangle frame')
(p/'frame_tb.v').write_text(s,encoding='utf-8')
# Uniform-angle physical rays of a 2m by 1.2m rectangle, heading 7deg left of +Y.
def fixture(x,obstacle=False,missing=False):
 rows=[]
 for i in range(450):
  a=i*2*math.pi/450;theta=math.radians(97)-a;dx,dy=math.cos(theta),math.sin(theta)
  ts=[]
  for pos,coord,d in [(0,x,dx),(2000,x,dx),(0,700,dy),(1200,700,dy)]:
   if d and (pos-coord)/d>0:ts.append((pos-coord)/d)
  t=min(ts)
  if missing and dy>0 and abs((1200-700)/dy-t)<1:t=6000
  if obstacle and 60<i<85:t=min(t,400)
  rows.append(' '.join(f'{v & 65535:04X}' for v in (round(t*math.cos(a)),round(-t*math.sin(a)),i*80,round(t)))+'\n')
 return ''.join(rows)
for name,x,obs,missing in [('frame_fixture.txt',900,False,False),('frame_live.txt',1000,True,False),('frame_missing.txt',900,False,True)]:
 (p/name).write_text(fixture(x,obs,missing),encoding='ascii')
print('Prepared 13 RTL simulations including rectangle fit, BT04 and configurable directional limits.')
