from pathlib import Path
w=Path(__file__).resolve().parents[2];src=w/'麦轮控制台_97F2';dst=w/'麦轮控制台_97F3'
if (dst/'controller.py').exists():raise SystemExit('Refusing to overwrite edited97F3 UI')
dst.mkdir(exist_ok=True)
for name in ['controller.py','protocol.py','transport.py','inputs.py','test_console.py','test_gui.py','test_inputs.py','requirements.txt','启动控制台.cmd','离线演示.cmd']:
 s=(src/name).read_text(encoding='utf-8-sig').replace('97F2','97F3')
 if name=='protocol.py':s=s.replace('def parse_line(line):','def _bt03_parse_line(line):')
 if name=='test_console.py':s=s.replace('97F300000000BB0D0A','97F300000000BC0D0A')
 (dst/name).write_text(s,encoding='utf-8')
print('Prepared97F3 UI baseline; no ports opened.')
