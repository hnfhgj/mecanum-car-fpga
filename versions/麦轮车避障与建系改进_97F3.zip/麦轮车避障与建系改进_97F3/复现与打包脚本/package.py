from pathlib import Path
import hashlib,json,shutil,zipfile
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent;release=p/'release'
m=json.loads((release/'manifest.json').read_text(encoding='utf-8'));sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
assert sha(release/m['firmware'])==m['sha256']
out=w/'麦轮车避障与建系改进_97F3';out.mkdir(exist_ok=True)
def copy(src,rel):
 dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for name,h in m['inputs'].items():assert sha(r/name)==h;copy(r/name,Path('工程/motor')/name)
for name in ['navigation_tuning.gprj','navigation_tuning/build.tcl','pillar_nav/timing_check.tcl']:copy(r/name,Path('工程/motor')/name)
for name,h in m['testInputs'].items():assert sha(p/name)==h;copy(p/name,Path('工程/motor/navigation_tuning')/name)
for name in ['prepare.py','prepare_tests.py','prepare_ui.py','release.py','package.py']:
 copy(p/name,Path('复现与打包脚本')/name)
for f in release.iterdir():
 if f.is_file():copy(f,Path('固件与验证')/f.name)
for f in p.glob('*_tb.log'):copy(f,Path('固件与验证/仿真记录')/f.name)
copy(r/'drive_speedup/release/drive_speedup_97F2.fs','固件与验证/回退_已烧录97F2.fs')
gui=w/'麦轮控制台_97F3'
for name,h in m['guiInputs'].items():assert sha(gui/name)==h;copy(gui/name,Path('电脑控制台_97F3')/name)
for name in ['python_tests.log','gui_smoke.log']:copy(gui/name,Path('固件与验证')/name)
copy(gui/'使用说明.md','先读我.md')
(out/'固件与验证/烧录说明.md').write_text('''# 97F3离线交付

尚未烧录，当前Flash最后核实为97F2。请在用户确认准备好后再下载。
烧录文件 navigation_tuning_97F3.fs；UserCode=000097F3，器件GW5AT-60B、PBGA484A。
芯片型号GW5AT-LV60PG484AC1/I0，实机ID=0x0001481B。
外部Flash擦写、校验、重载，读回真实UserCode后再进行串口无运动检查。

完整工程在 工程/motor/navigation_tuning.gprj，顶层 navigation_tuning/navigation_tuning_top.v。
在工程/motor运行 gw_sh.exe navigation_tuning/build.tcl。布局2/布线2，50MHz，setup/hold违例均须为0。
工程内同时包含之前目录中的依赖RTL，均已按项目清单完整收集。
电脑控制台需与97F3固件配套；当前桌面97F2入口保留，烧录新版后再更新。
回退文件为原97F2已验证固件。摄像头、引脚、轮序、PID、PWM上限与97F2保持一致。
本次仅离线验证，没有连接串口、下载器或发送车辆运动指令。
''',encoding='utf-8')
entries={f.relative_to(out).as_posix():sha(f) for f in out.rglob('*') if f.is_file() and f.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding='utf-8')
archive=w/'麦轮车避障与建系改进_97F3.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in out.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in entries.items():assert hashlib.sha256(z.read(out.name+'/'+name)).hexdigest().upper()==h
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,files=len(entries)+1),ensure_ascii=True,indent=2))
