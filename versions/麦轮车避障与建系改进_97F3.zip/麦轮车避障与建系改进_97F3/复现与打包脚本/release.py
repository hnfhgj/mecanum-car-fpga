"""Strict offline release gate. No port enumeration, programming or motion."""
from pathlib import Path
import hashlib,json,re,shutil,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent;pnr=r/'impl/pnr'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
base=json.loads((r/'drive_speedup/release/manifest.json').read_text(encoding='utf-8'))
for name,h in base['inputs'].items():assert sha(r/name)==h,'97F2 source changed: '+name
assert sha(r/'drive_speedup/release'/base['firmware'])==base['sha256']
tree=ET.fromstring((r/'navigation_tuning.gprj').read_text(encoding='utf-8').replace('version="1"','version="1.0"'))
paths=[f.get('path') for f in tree.findall('.//File') if f.get('enable')=='1']+['src/imu660ra_config.hex','src/dl1b_config.hex']
old={'drive_speedup/drive_speedup_top.v','drive_speedup/pc_ui.v','remote_drive/directional_clearance.v','remote_drive/basic_uart_debug.v','square_nav/square_frame_fit.v'}
new={'navigation_tuning/'+v+'.v' for v in ['navigation_tuning_top','pc_ui','directional_clearance','basic_uart_debug','square_frame_fit']}
assert len(paths)==len(set(paths)) and set(paths)==(set(base['inputs'])-old)|new
tests=['pc_control_tb','pc_bridge_tb','wireless_top_tb','wireless_stream_tb','speed_tb','basic_nav_tb','pc_motor_pipeline_tb','manual_tb','directional_tb','cloud_stream_tb','snapshot_tb','hold_top_tb','square_frame_tb']
for test in tests:
 log=(p/(test+'.log')).read_text(encoding='utf-8-sig');assert 'PASS ' in log and not re.search('Fatal:|ERROR:',log),test
gui=w/'麦轮控制台_97F3'
log=(gui/'python_tests.log').read_text(encoding='utf-8-sig');assert 'Ran 51 tests' in log and re.search(r'\nOK\s*$',log)
assert 'PASS GUI' in (gui/'gui_smoke.log').read_text(encoding='utf-8-sig')
build=(p/'build.log').read_text(encoding='utf-8-sig');assert 'PASS: navigation_tuning setup/hold violations zero' in build
fs=pnr/'navigation_tuning.fs';header='\n'.join(fs.read_text(encoding='ascii').splitlines()[:18])
assert '//Device-package: GW5AT-60B-PBGA484A' in header
assert re.search(r'//UserCode:\s+0x([0-9A-Fa-f]+)',header)[1].upper()=='000097F3'
assert all((r/f).stat().st_mtime<=fs.stat().st_mtime for f in paths),'Source newer than build'
timing=(pnr/'navigation_tuning_tr_content.html').read_text(encoding='utf-8-sig')
for kind in ('Setup','Hold'):assert re.search(r'Numbers of '+kind+r' Violated Endpoints</td>\s*<td[^>]*>([0-9]+)</td>',timing)[1]=='0'
pins=dict(re.findall(r'IO_LOC\s+"([^"]+)"\s+(\w+)\s*;',(r/'basic_tasks/wireless_board.cst').read_text(encoding='utf-8-sig')))
assert len(pins)==56 and len(set(pins.values()))==56
actual={}
for line in (pnr/'navigation_tuning.rpt.txt').read_text(encoding='utf-8-sig').splitlines():
 fields=[s.strip() for s in line.split('|')]
 if len(fields)>4 and fields[0] in pins:
  assert fields[3]=='Y';actual[fields[0]]=fields[2].split('/')[0]
assert actual==pins
top=(p/'navigation_tuning_top.v').read_text(encoding='utf-8')
assert top.count('.MAX_TURN(110)')==3 and '.MAX_DUTY(882)' in top
assert '.NO_FEEDBACK_GUARD(0)' in top and '.FIXED_ENCODER_SIGN(1)' in top
assert '.blocked(manual_blocked)' in top and '.range_fresh(manual_range_fresh)' in top
ui=(p/'pc_ui.v').read_text(encoding='utf-8')
assert '4:if(!motion_ready || !manual_range_ready)' in ui
assert 'stop_fb_mm<=400;stop_lr_mm<=250;cone_mode<=2;' in ui
assert 'ab(fit_w-fit_h)' not in (p/'square_frame_fit.v').read_text(encoding='utf-8')
out=p/'release';out.mkdir(exist_ok=True);dest=out/'navigation_tuning_97F3.fs'
if dest.exists():assert sha(dest)==sha(fs),'Immutable firmware differs'
else:shutil.copy2(fs,dest)
for f,name in [(pnr/'navigation_tuning_tr_content.html','timing.html'),(pnr/'navigation_tuning.rpt.txt','pnr.txt'),(p/'build.log','build.log')]:shutil.copy2(f,out/name)
m=dict(firmware=dest.name,userCode='000097F3',sha256=sha(dest),setup=0,hold=0,ports=56,baseline='97F2',
 hardwareProgrammed=False,integratedHardwareVerified=False,rtlSimulations=len(tests),pythonTests=51,placeOption=2,routeOption=2,
 manualRequiresFieldCalibration=False,staticCalibrationRequiresNavigationClearance=False,staticCalibrationRequiresImuAndFullScan=True,
 coneHalfAngleDegrees=[10.62,20.56,29.36],defaultConeMode=2,frontBackStopMm=400,leftRightStopMm=250,
 obstacleConfigOpcode=16,obstacleConfigVolatile=True,rectangleSideMm=[800,3000],calibrationSearchDegrees=[-20,20],
 radarDisplayRadiiCm=[100,200,300,500],defaultRadarDisplayRadiusCm=300,pointCloudBins=180,pointCloudRangeUnitMm=20,
 speedPercent=[25,50,75,100,125,150],translationDefault=120,spinMaxTurn=110,pwmMaxCounts=882,
 inputs={f:sha(r/f) for f in paths},guiInputs={f.name:sha(f) for f in gui.iterdir() if f.suffix in ('.py','.cmd','.md','.txt')},
 testInputs={f.name:sha(f) for f in p.iterdir() if f.suffix in ('.sv','.v','.ps1','.txt') and not f.name.endswith('.rpt.txt')})
(out/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v for k,v in m.items() if k not in ('inputs','guiInputs','testInputs')},indent=2))
