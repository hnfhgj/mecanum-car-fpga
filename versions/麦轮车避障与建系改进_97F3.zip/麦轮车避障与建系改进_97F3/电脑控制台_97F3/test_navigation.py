"""Offline protocol and own-widget regressions; never enumerates serial ports."""
import math,time,types,tkinter as tk,unittest
from unittest.mock import Mock,patch
from controller import App
from protocol import *
from test_console import FIXTURE

class DiagnosticTests(unittest.TestCase):
 def test_bt04_full_diagnostics(self):
  line='IO HEX=425404'+FIXTURE[6:]+'019000FA0200B4090B'
  kind,t=parse_line(line)
  self.assertEqual(kind,'task');self.assertEqual(t['firmware'],FIRMWARE)
  self.assertEqual((t['stop_fb_cm'],t['stop_lr_cm'],t['cone_mode'],t['fit_quality'],t['fit_reason']),(40,25,2,180,9))
  self.assertTrue(t['map_near']);self.assertTrue(t['nav_range_near']);self.assertTrue(t['wheel_fault']);self.assertFalse(t['heading_fault'])
  self.assertEqual(t['applied_left'],-60)
 def test_bt04_rejects_truncated_and_wrong_marker(self):
  for s in ['425404'+FIXTURE[6:],'425405'+FIXTURE[6:]+'019000FA0200B40900']:
   self.assertEqual(parse_line('IO HEX='+s)[0],'text')
 def test_static_calibration_failure_reason(self):
  r=navigation_blockers(dict(calibrated=False,fit_reason=3,imu_fresh=True,radar=True),dict(ready=True))
  self.assertEqual(len(r),1);self.assertIn('四边框未识别',r[0])
 def test_navigation_near_does_not_claim_manual_cones(self):
  t=dict(calibrated=True,pose=True,imu_fresh=True,heading_ready=True,can_go=True,radar=True,nav_range_near=True)
  self.assertIn('27cm',navigation_blockers(t,dict(ready=True))[0])
  t['nav_range_near']=False;self.assertEqual(navigation_blockers(t,dict(ready=True)),[])

class NavigationGuiTests(unittest.TestCase):
 def setUp(self):
  self.root=tk.Tk();self.root.withdraw();self.a=App(self.root,demo=True,enumerate_ports=False);self.root.update_idletasks()
 def tearDown(self):
  self.assertIsNone(self.a.link.thread)
  for ident in self.root.tk.splitlist(self.root.tk.call('after','info')):
   self.root.after_cancel(ident)
  self.root.destroy()
 def real_ready(self):
  a=self.a;a.demo=False;a.connected=True;a.remote_ready=True;a.last_task=time.monotonic();a.send=Mock();return a
 def test_default_view_and_limits(self):
  self.assertEqual((self.a.radar_radius.get(),self.a.radar_view.get()),('300','车体雷达'))
  self.assertEqual((self.a.obstacle_fb.get(),self.a.obstacle_lr.get()),('40','25'))
 def test_calibration_enabled_with_old_clearance_unready(self):
  a=self.real_ready();a.task.update(calibrated=False,pose=False,near=True,radar=False)
  self.assertTrue(a.available('calibrate'));a.calibrate_frame()
  a.send.assert_called_once_with([(DRIVE,0,0,0),(CALIBRATE,0,0,0)])
  a.task['active']=True;self.assertFalse(a.available('calibrate'))
 def test_calibration_still_requires_fresh_scan(self):
  a=self.real_ready();a.task['manual_range_fresh']=False
  self.assertFalse(a.available('calibrate'));a.calibrate_frame();a.send.assert_not_called()
 def test_config_transaction_and_focus(self):
  a=self.real_ready();a.manual_armed.set(True);a.root.focus_set=Mock();a.held_input=types.SimpleNamespace(foreground=lambda:True)
  a.obstacle_fb.set('50');a.obstacle_lr.set('30');a.obstacle_cone.set('宽 ±29.4°');a.apply_obstacle()
  a.send.assert_called_once_with([(DRIVE,0,0,0),(OBSTACLE,500,300,3)])
  a.on_command_sent(dict(op=OBSTACLE,seq=25));a.on_command_ack(dict(seq=25,status=0))
  self.assertFalse(a.speed_focus_pending);self.assertTrue(a.manual_armed.get());self.assertTrue(a.release_before_drive)
  a.root.focus_set.assert_called_once()
 def test_invalid_config_not_sent(self):
  a=self.real_ready();a.obstacle_fb.set('90')
  with patch('controller.messagebox.showerror') as err:a.apply_obstacle();err.assert_called_once()
  a.send.assert_not_called()
 def test_cone_polygons_match_integer_rtl(self):
  for mode,tan in [(1,3/16),(2,3/8),(3,9/16)]:
   self.a.task['cone_mode']=mode;p=self.a.obstacle_polygons()
   self.assertEqual(p[0],(0,[(0,0),(40,40*tan),(40,-40*tan)]))
   self.assertEqual(p[2][1][1],(-25*tan,25))
 def test_body_click_never_starts_navigation(self):
  a=self.a;a.draw_world(a.radar_canvas);a.click_go.set(True);a.goal=Mock()
  a.map_click(a.radar_canvas,types.SimpleNamespace(x=200,y=200));a.goal.assert_not_called()
 def test_view_radius_changes_scale_without_altering_points(self):
  a=self.a;original=list(a.cloud['points']);c=a.radar_canvas
  a.radar_radius.set('100');a.draw_world(c);s1=c._body_transform[2]
  a.radar_radius.set('500');a.draw_world(c);s2=c._body_transform[2]
  self.assertAlmostEqual(s1/s2,5);self.assertEqual(a.cloud['points'],original)
  self.assertEqual(len(c.find_withtag('obstacle_zone')),4)
 def test_click_arm_selects_field_view(self):
  a=self.a;a.click_go.set(True);a.arm_click();self.assertEqual(a.radar_view.get(),'场地坐标')
 def test_calibration_ack_selects_field_view(self):
  a=self.a;a.on_command_sent(dict(op=CALIBRATE,seq=51));a.on_command_ack(dict(seq=51,status=0))
  self.assertEqual(a.radar_view.get(),'场地坐标');self.assertIsNone(a.calibration_seq)

if __name__=='__main__':unittest.main(verbosity=2)
