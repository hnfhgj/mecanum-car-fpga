"""Freeze protected 97F4 firmware with the R5 recovery client; never program."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
p=Path(__file__).resolve().parent;r=p.parent;w=r.parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper()
base_dir=r/'free_navigation/release';m=json.loads((base_dir/'manifest.json').read_text(encoding='utf-8'))
fw=base_dir/m['firmware'];assert sha(fw)==m['sha256']=='39089FE1A3FD87C4E4D1268607F1C1519711087DD12EAD5D0381842896D8A721'
for name,h in m['inputs'].items():assert sha(r/name)==h,name
assert m['setup']==m['hold']==0 and m['ports']==56 and m['rtlSimulations']==13
gui=w/'麦轮控制台_97F4_保护与重规划_R5';old=w/'麦轮控制台_97F4_矩形导航_R3'
for name in ('protocol.py','transport.py','inputs.py','free_console.py','legacy_console.py','local_navigation.py'):
 assert sha(gui/name)==sha(old/name),name
assert 'self.link.set_drive(mask)' in (gui/'controller.py').read_text(encoding='utf-8')
assert 'planned=True' not in (gui/'controller.py').read_text(encoding='utf-8')
log=(gui/'python_tests.log').read_text(encoding='utf-8-sig');assert 'Ran 124 tests' in log and re.search(r'\nOK\s*$',log)
assert 'PASS field GUI' in (gui/'gui_smoke.log').read_text(encoding='utf-8-sig')
release=p/'release';release.mkdir(exist_ok=True)
dest=release/'free_navigation_97F4_protected.fs'
if dest.exists():assert sha(dest)==sha(fw)
else:shutil.copy2(fw,dest)
record=dict(firmware=dest.name,userCode='000097F4',sha256=sha(dest),client='97F4/R5',basedOn='97F4/R3',
 currentInstalledFirmware='000097F5',currentDesktop='97F5/R4',hardwareProgrammedThisRevision=False,navigationMotionTested=False,
 unchangedFirmware=True,rtlSimulationsReused=13,pythonTests=124,setup=0,hold=0,ports=56,
 task4DirectionalProtection=True,shortSegmentProtection=True,rotationProtection=True,nearObstacleRecovery=True,
 blockedStartEscape=True,blockedDiagonalReleasedEntirely=True,goalRetainedDuringRecovery=True,
 noMovementRetryAfterSeconds=1,avoidFailedDirectionSeconds=3,recoveryPulseSeconds=.12,
 staleSensorsStop=True,leaseMs=300,translationTargets=[52,105,157,210,262,315],spinMaxTurn=110,pwmMaxCounts=882,
 inputs=m['inputs'],guiInputs={f.name:sha(f) for f in gui.iterdir() if f.is_file() and f.suffix in ('.py','.cmd','.md','.txt','.json')})
(release/'manifest.json').write_text(json.dumps(record,indent=2,ensure_ascii=False),encoding='utf-8')
out=w/'保护恢复与受阻重规划_97F4R5';out.mkdir(exist_ok=True)
def cp(src,rel):
 d=out/rel;d.parent.mkdir(parents=True,exist_ok=True)
 if d.exists() and sha(d)==sha(src):return
 shutil.copy2(src,d)
for f in release.iterdir():
 if f.is_file():cp(f,Path('固件与验证')/f.name)
for name,h in record['guiInputs'].items():assert sha(gui/name)==h;cp(gui/name,Path('电脑控制台')/name)
for name in ('python_tests.log','gui_smoke.log','recovery_tests.log'):cp(gui/name,Path('验证记录')/name)
cp(gui/'使用说明.md','先读我.md')
for name in m['inputs']:cp(r/name,Path('工程/motor')/name)
for name in ('free_navigation.gprj','free_navigation/build.tcl','pillar_nav/timing_check.tcl'):
 cp(r/name,Path('工程/motor')/name)
for name in ('timing.html','pnr.txt','build.log'):cp(base_dir/name,Path('验证记录/原97F4硬件构建')/name)
for f in (r/'free_navigation').glob('*_tb.log'):cp(f,Path('验证记录/原97F4仿真')/f.name)
cp(p/'package.py','打包脚本/package.py')
for f in old.iterdir():
 if f.is_file() and f.suffix in ('.py','.cmd','.md','.txt','.json'):cp(f,Path('回退原保护版R3控制台')/f.name)
entries={f.relative_to(out).as_posix():sha(f) for f in out.rglob('*') if f.is_file() and f.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding='utf-8')
archive=w/(out.name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in out.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(w).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in entries.items():assert hashlib.sha256(z.read(out.name+'/'+name)).hexdigest().upper()==h
print(json.dumps(dict(archive=str(archive),sha256=sha(archive),files=len(entries)+1,bytes=archive.stat().st_size),ensure_ascii=True,indent=2))
