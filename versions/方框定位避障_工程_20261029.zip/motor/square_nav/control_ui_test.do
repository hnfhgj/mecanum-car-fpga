onerror {quit -code 1 -f}
set lib [file normalize square_nav/control_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/n10_sincos.v pillar_nav/nav_math.v pillar_nav/nav_buttons.v square_nav/square_project.v square_nav/square_drive.v square_nav/square_ui.v square_nav/control_ui_tb.v
foreach test {square_drive_tb square_ui_tb} {
 vsim -onfinish stop -voptargs=+acc -lib $lib $test
 run -all
 if {[examine -radix unsigned /$test/passed] != 1} {quit -code 1 -f}
 quit -sim
}
quit -code 0 -f
