"""Create an isolated square-nav project; never edits pillar sources or firmware."""
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent.parent
old=(root/'pillar_nav/pillar_nav_top.v').read_text(encoding='utf-8-sig')
old=old.replace('module pillar_nav_top #(', 'module square_nav_top #(')
start=old.index(' wire features_done,features_ok;')
end=old.index(' wire signed [15:0] turn,heading_yaw',start)
old=old[:start]+''' wire calibrate_pulse,go_pulse,stop_pulse;
 wire [15:0] target_x,target_y,width_mm,height_mm,quality;
 wire pose_update,pose_ok,calibrated,scan_ready,release_scan;
 wire signed [15:0] pose_x,pose_y,pose_yaw,correction;
 wire signed [15:0] scan_forward,scan_left;wire [8:0] scan_addr;wire [9:0] scan_count;
 wire active,fresh,can_go;wire [3:0] nav_status;
 assign point_ready=1'b1;
 // Bound the packet validation path before distributing cancellation.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)raw_bad_q<=0;else raw_bad_q<=raw_bad;
 end
 wire stream_bad=raw_bad_q || point_overflow;
 square_frame_fit localization(.clk(clk),.rst_n(rst_n),.bad(stream_bad),.calibrate(calibrate_pulse),
  .point_valid(point_valid),.point_forward(point_x),.point_left(point_y),.point_angle(point_angle),.point_range(point_range),
  .imu_yaw(yaw),.release_scan(release_scan),.read_addr(scan_addr),.read_forward(scan_forward),.read_left(scan_left),
  .point_count(scan_count),.scan_ready(scan_ready),.pose_update(pose_update),.pose_ok(pose_ok),.calibrated(calibrated),
  .pose_x(pose_x),.pose_y(pose_y),.pose_yaw(pose_yaw),.correction(correction),.width_mm(width_mm),.height_mm(height_mm),.quality(quality));
 square_ui ui(.clk(clk),.rst_n(rst_n),.key_n(key_n),.active(active),.calibrated(calibrated),
  .width_mm(width_mm),.height_mm(height_mm),.page(page),.menu_view(menu_view),.cursor(cursor),
  .target_x(target_x),.target_y(target_y),.calibrate_pulse(calibrate_pulse),.go_pulse(go_pulse),.stop_pulse(stop_pulse),
  .gain_selection(gain_selection),.heading_kp(heading_kp),.heading_kd(heading_kd));
 wire map_busy,map_done,map_valid,near_obstacle,map_we,map_free;wire [11:0] map_addr;
 reg scan_owned;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)scan_owned<=0;
  else if(stream_bad || calibrate_pulse || release_scan)scan_owned<=0;
  else if(scan_ready && !scan_owned)scan_owned<=1;
 end
 assign release_scan=map_done;
 square_map map_builder(.clk(clk),.rst_n(rst_n),.cancel(stream_bad || calibrate_pulse),
  .start(scan_ready && !scan_owned),.point_count(scan_count),.read_forward(scan_forward),.read_left(scan_left),.read_addr(scan_addr),
  .pose_x(pose_x),.pose_y(pose_y),.pose_yaw(pose_yaw),.width_mm(width_mm),.height_mm(height_mm),
  .busy(map_busy),.done(map_done),.valid(map_valid),.near_obstacle(near_obstacle),.map_we(map_we),.map_addr(map_addr),.map_free(map_free));
 wire route_busy,route_done,route_found,route_goal,write_rejected;wire [1:0] route_direction;
 wire [11:0] origin_cell=((pose_y/50)<<6)+(pose_x/50),goal_cell=((target_y/50)<<6)+(target_x/50);
 square_grid_route #(.EXPLORE(1)) planner(.clk(clk),.rst_n(rst_n),.cancel(stream_bad || calibrate_pulse || stop_pulse || go_pulse),
  .map_we(map_we),.map_addr(map_addr),.map_free(map_free),.start(map_done && map_valid),.origin(origin_cell),.goal(goal_cell),
  .busy(route_busy),.done(route_done),.found(route_found),.direction(route_direction),.write_rejected(write_rejected),
  .new_goal(go_pulse || calibrate_pulse),.goal_reached(route_goal));
''' +old[end:]
old=old.replace('heading_hold #(.MAX_TURN(150)', 'heading_hold #(.MAX_TURN(80)')
old=old.replace('rst_n && !align_pulse && !learn_req && !clear_cal', 'rst_n && calibrated && !calibrate_pulse')
old=old.replace('.target_yaw(16\'sd0)', '.target_yaw(-correction)')
start=old.index(' nav_control control(')
end=old.index(' genvar w;',start)
old=old[:start]+''' square_drive control(.clk(clk),.rst_n(rst_n),.calibrate(calibrate_pulse),.go(go_pulse),.stop(stop_pulse),.page(page),
  .calibrated(calibrated),.pose_update(pose_update),.pose_ok(pose_ok && lidar_online),
  .pose_x(pose_x),.pose_y(pose_y),.pose_yaw(pose_yaw),.target_x(target_x),.target_y(target_y),.width_mm(width_mm),.height_mm(height_mm),
  .route_done(route_done),.route_found(route_found && !write_rejected),.route_goal(route_goal),.route_direction(route_direction),
  .near_obstacle(near_obstacle),.heading_ready(heading_ready && !heading_fault),.wheel_fault(|faults),.heading_turn(turn),.heading_error(heading_yaw+correction),
  .active(active),.fresh(fresh),.can_go(can_go),.status(nav_status),
  .lf_target(targets[0]),.rf_target(targets[1]),.lb_target(targets[2]),.rb_target(targets[3]));
''' +old[end:]
old=old.replace(' nav_renderer overlay(', ' square_renderer overlay(')
old=old.replace('.aligned(aligned)', '.aligned(calibrated)').replace('.learn_ok(learn_ok)', '.learn_ok(calibrated)')
old=old.replace('.template_valid(template_valid)', '.template_valid(calibrated)').replace('.ambiguous(ambiguous)', ".ambiguous(1'b0)")
old=old.replace('.live_count(candidate_count),.frozen_count(frozen_count),.o_id(o_id),.x_id(x_id),.y_id(y_id),.live_xs(candidate_xs),.live_ys(candidate_ys)',
 ".live_count(4'd0),.frozen_count(4'd0),.o_id(4'd0),.x_id(4'd0),.y_id(4'd0),.live_xs(192'd0),.live_ys(192'd0)")
old=old.replace('.frozen_xs(frozen_xs),.frozen_ys(frozen_ys)', ".frozen_xs(192'd0),.frozen_ys(192'd0)")
old=old.replace('.diameter_mm(diameter)', '.diameter_mm(correction<0?-correction:correction)')
start=old.index(' wire [7:0] flags=')
end=old.index(' uart_enc_debug',start)
old=old[:start]+''' wire [7:0] flags={1'b0,route_busy,calibrated,calibrated,fresh,can_go,active,heading_ready};
 wire [167:0] diagnostics={24'h535101,flags,{4'd0,nav_status},4'd0,scan_count[3:0],{4'd0,cursor},pose_x,pose_y,pose_yaw,target_x,target_y,quality,16'd0};
''' +old[end:]
old=old.replace('.bad(raw_bad),.point_valid(raw_point)', '.bad(raw_bad_q),.point_valid(raw_point)')
old=old.replace(' nav_point_stream stream(', ' reg raw_bad_q;\n nav_point_stream stream(')
(root/'square_nav/square_nav_top.v').write_text(old,encoding='utf-8')

renderer=(root/'pillar_nav/nav_renderer.v').read_text(encoding='utf-8-sig')
renderer=renderer.replace('module nav_renderer(', 'module square_renderer(')
renderer=renderer.replace('row>=3 && row<=12 && row==field+2','row>=5 && row<=8 && row==field+4')
a=renderer.index('   3:begin line=')
b=renderer.index('   default:line=',a)
renderer=renderer[:a]+'''   3:begin line="BOX 000X000 CM      ";line[127-:24]=CM3(bcd[4]);line[95-:24]=CM3(bcd[5]);end
   4:line="HEAD TARGET: +Y     ";
   5:line="1 CALIBRATE FRAME   ";
   6:begin line="2 GOAL X:000 CM     ";line[87-:24]=CM3(bcd[2]);end
   7:begin line="3 GOAL Y:000 CM     ";line[87-:24]=CM3(bcd[3]);end
   8:line=fr_ready?"4 GO / S4 STOP      ":"4 GO: NOT READY     ";
   9:line="STEP:5CM TOL:7.5CM  ";
   10:line="CLEARANCE:27CM      ";
   11:line="OBSERVE / REPLAN    ";
   12:line="S2 NEXT S3+ S4-STOP ";
   13:line="S1 MAP  HOLD:PAGE   ";
   14:line="CAL: FACE ROUGHLY +Y";
   15:line="KEEP STILL TO LEARN ";
''' +renderer[b:]
renderer=renderer.replace('0:line="NAV: LEARN 3 POLES  ";1:line="NAV: ALIGN FRONT +X ";', '0:line="NAV: CALIBRATE FRAME";1:line="NAV: ALIGN FRONT +Y ";')
(root/'square_nav/square_renderer.v').write_text(renderer,encoding='utf-8')
tb=(root/'pillar_nav/tests/renderer_tb.v').read_text(encoding='utf-8-sig')
tb=tb.replace('module renderer_tb;', 'module square_renderer_tb;').replace('nav_renderer dut','square_renderer dut')
tb=tb.replace('.cursor(4\'d8)', ".cursor(4'd2)").replace('pillar_nav/tests/nav_menu_rgb565.hex','square_nav/menu_rgb565.hex')
tb=tb.replace('PASS menu renderer snapshot and RGB565 frame generated','PASS square menu renderer snapshot and RGB565 frame generated')
(root/'square_nav/renderer_tb.v').write_text(tb,encoding='utf-8')

tree=ET.fromstring((root/'pillar_navigation.gprj').read_text(encoding='utf-8-sig').replace('version="1"','version="1.0"'))
files=tree.find('FileList')
for f in files:
    if f.attrib['path'].replace('\\','/').endswith('pillar_nav/pillar_nav_top.v'):
        f.set('path','square_nav/square_nav_top.v')
for name in ('square_project','square_frame_fit','square_map','square_grid_route','square_drive','square_ui','square_renderer'):
    ET.SubElement(files,'File',{'path':f'square_nav/{name}.v','type':'file.verilog','enable':'1'})
ET.ElementTree(tree).write(root/'square_navigation.gprj',encoding='UTF-8',xml_declaration=True)
print('Created isolated square_navigation.gprj and top/renderer; no programming')
