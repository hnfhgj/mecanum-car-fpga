"""Offline reference for square-frame localization and heading-preserving paths.

Inputs are ordered complete LIDAR scans, in mm, right-handed sensor coordinates
(forward, left). No hardware, serial ports, or programming tools are accessed.
Only valid frames can become maps. This is NOT a downloadable FPGA firmware.
"""
from dataclasses import dataclass, field
from collections import deque
import math
from itertools import product

CELL = 50
RADIUS = 170  # sqrt(150**2 + 80**2), user-supplied chassis dimensions
MARGIN = 100


class NotReady(ValueError):
    pass


def rotate(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0]*c-p[1]*s, p[0]*s+p[1]*c)


def nominal(p):
    # Car initially faces +Y; car left is world -X.
    return -p[1], p[0]


def peaks(values, positive):
    bins={}
    for v in values:
        if abs(v)>=150 and (v>0)==positive:
            k=math.floor(v/25);bins[k]=bins.get(k,0)+1
    chosen=[]
    for k in sorted(bins,key=lambda k:sum(bins.get(k+i,0) for i in (-1,0,1)),reverse=True):
        centre=(k+.5)*25
        if any(abs(centre-c)<100 for c in chosen):continue
        near=sorted(v for v in values if abs(v-centre)<=37.5)
        if len(near)>=12:chosen.append(near[len(near)//2])
        if len(chosen)==3:break
    return chosen


@dataclass
class Frame:
    width: float
    height: float
    correction: float
    x: float
    y: float
    residual: float
    vantage: tuple | None = None
    visited: list = field(default_factory=list)

    def localize(self, scan, yaw_delta=0):
        """IMU yaw delta is CCW from calibration; frame must remain fixed."""
        points = [rotate(nominal(p), self.correction+yaw_delta) for p in scan]
        # Each wall votes for the robot coordinate; obstacles cannot become
        # new boundaries. Require all FOUR learned walls, not any two peaks.
        votes_x, votes_y = [], []
        for x, y in points:
            votes_x.extend([-x, self.width-x])
            votes_y.extend([-y, self.height-y])
        def estimate(votes, previous, maximum):
            nearby = [v for v in votes if 0 < v < maximum and abs(v-previous) < 300]
            if not nearby:
                raise NotReady('no position votes near previous fix')
            bins = {}
            for v in nearby:
                k = math.floor(v/25)
                bins[k] = bins.get(k, 0)+1
            k = max(bins, key=lambda k: sum(bins.get(k+i, 0) for i in (-1, 0, 1)))
            cluster = [v for v in nearby if abs(v-(k+.5)*25) < 37.5]
            return sorted(cluster)[len(cluster)//2]
        px = estimate(votes_x, self.x, self.width)
        py = estimate(votes_y, self.y, self.height)
        world = [(x+px, y+py) for x, y in points]
        support, spans = wall_evidence(world, self.width, self.height)
        if min(support) < 12 or min(spans) < min(self.width, self.height)*.4:
            raise NotReady('learned frame obscured or fix inconsistent')
        if min(px, py, self.width-px, self.height-py) < RADIUS+MARGIN:
            raise NotReady('robot footprint too close to boundary')
        self.x, self.y = px, py
        return world, math.pi/2+self.correction+yaw_delta


def wall_evidence(points, w, h):
    groups = [[], [], [], []]
    for x, y in points:
        if -50 <= y <= h+50:
            if abs(x) < 45: groups[0].append(y)
            if abs(x-w) < 45: groups[1].append(y)
        if -50 <= x <= w+50:
            if abs(y) < 45: groups[2].append(x)
            if abs(y-h) < 45: groups[3].append(x)
    return ([len(g) for g in groups],
            [max(g)-min(g) if g else 0 for g in groups])


def calibrate(scan):
    if len(scan) < 120:
        raise NotReady('not enough valid returns')
    options = []
    # Heading convention breaks the square's 90-degree ambiguity. No compass
    # north is inferred. Operator must initially face within 20 deg of +Y.
    for step in range(-40, 41):
        angle = math.radians(step*.5)
        points = [rotate(nominal(p), angle) for p in scan]
        for xl,xr,yb,yt in product(peaks([x for x,y in points],False),peaks([x for x,y in points],True),
                                   peaks([y for x,y in points],False),peaks([y for x,y in points],True)):
            w, h = xr-xl, yt-yb
            if not (800 <= w <= 3000 and 800 <= h <= 3000 and abs(w-h) < 150):
                continue
            world = [(x-xl, y-yb) for x, y in points]
            support, spans = wall_evidence(world, w, h)
            if min(support) < 12 or min(spans) < min(w, h)*.6:
                continue
            errors = [min(abs(x), abs(x-w), abs(y), abs(y-h)) for x, y in world]
            residual = sum(e for e in errors if e < 45) / max(1, sum(e < 45 for e in errors))
            score = min(support)*4 + sum(min(s, 100) for s in support) - residual
            options.append((score, Frame(w, h, angle, -xl, -yb, residual)))
    if not options:
        raise NotReady('no supported square inside 0.8..3 m; face roughly +Y')
    options.sort(key=lambda t: t[0], reverse=True)
    best = options[0][1]
    # Reject spatially distinct, equally convincing enclosing squares.
    for score, other in options[1:]:
        if options[0][0]-score < 20 and abs(other.width-best.width) > 150:
            raise NotReady('ambiguous enclosing frame')
    if min(best.x, best.y, best.width-best.x, best.height-best.y) < RADIUS+MARGIN:
        raise NotReady('insufficient chassis clearance during calibration')
    return best


def cells_on_ray(start, end):
    x, y = start; tx, ty = end
    dx, dy = abs(tx-x), -abs(ty-y)
    sx, sy = (1 if x < tx else -1), (1 if y < ty else -1)
    err = dx+dy
    while True:
        yield x, y
        if (x, y) == (tx, ty): break
        e = 2*err
        if e >= dy: err += dy; x += sx
        if e <= dx: err += dx; y += sy


def plan(frame, points, goal, radius=RADIUS, margin=MARGIN):
    """50mm observed-free grid, circular footprint inflation, four-neighbour BFS.

    Unknown cells are blocked. A path can terminate at a visible intermediate
    vantage point; caller must stop/replan on a new scan before continuing.
    """
    clearance = radius+margin
    w, h = math.ceil(frame.width/CELL), math.ceil(frame.height/CELL)
    cell = lambda p: (math.floor(p[0]/CELL), math.floor(p[1]/CELL))
    inside = lambda p: (clearance <= p[0] <= frame.width-clearance and
                        clearance <= p[1] <= frame.height-clearance)
    if not inside(goal): raise NotReady('goal footprint crosses frame')
    start, target = cell((frame.x, frame.y)), cell(goal)
    free, occupied = set(), set()
    for p in points:
        # Out-of-frame returns are not obstacle landmarks. They still reveal
        # traversed free space only up to the learned boundary.
        ray = list(cells_on_ray(start, cell(p)))
        for q in ray[:-1]:
            if 0 <= q[0] < w and 0 <= q[1] < h: free.add(q)
        # Boundary clearance is applied analytically below. Avoid inflating
        # noisy boundary endpoints a second time as interior obstacles.
        if 70 < p[0] < frame.width-70 and 70 < p[1] < frame.height-70:
            occupied.add(cell(p))
    # Cover whole grid cells, not just their centres, for conservative clearance.
    inflate = math.ceil((clearance+CELL*math.sqrt(2))/CELL)
    blocked = set()
    for x, y in occupied:
        for dx in range(-inflate, inflate+1):
            for dy in range(-inflate, inflate+1):
                if math.hypot(dx, dy)*CELL <= clearance+CELL*math.sqrt(2):
                    blocked.add((x+dx, y+dy))
    allowed = {q for q in free if q not in blocked and inside(((q[0]+.5)*CELL, (q[1]+.5)*CELL))}
    if start not in allowed: raise NotReady('current footprint occupied or unobserved')
    previous = {start: None}; todo = deque([start])
    while todo:
        q = todo.popleft()
        for dx, dy in ((1, 0), (0, 1), (-1, 0), (0, -1)):
            nxt = q[0]+dx, q[1]+dy
            if nxt in allowed and nxt not in previous:
                previous[nxt] = q; todo.append(nxt)
    reached = target in previous
    if reached:
        end = target
        frame.vantage = None
    else:
        # No blind travel behind an obstacle. Choose an observed vantage only
        # if it makes at least one cell of progress toward the target.
        if frame.vantage is not None and math.dist(start,frame.vantage)<2:
            frame.visited.append(frame.vantage); frame.vantage=None
        if frame.vantage not in previous: frame.vantage=None
        if frame.vantage is None:
            frontiers=[q for q in previous if math.dist(q,start)>=3 and
                       all(math.dist(q,v)>=3 for v in frame.visited)]
            if not frontiers: raise NotReady('blocked: no observed safe vantage')
            frame.vantage=min(frontiers,key=lambda q:math.dist(q,target))
        end=frame.vantage
    route = []
    while end is not None:
        route.append(((end[0]+.5)*CELL, (end[1]+.5)*CELL)); end = previous[end]
    route.reverse()
    if reached: route[-1] = goal
    return route, reached, allowed, occupied


def mecanum(vx_world, vy_world, yaw, turn):
    f = math.cos(yaw)*vx_world + math.sin(yaw)*vy_world
    left = -math.sin(yaw)*vx_world + math.cos(yaw)*vy_world
    return f-left-turn, f+left+turn, f+left-turn, f-left+turn
