# Offline build only. Programming requires a separate explicit operation.
set root [file normalize [file join [file dirname [info script]] ..]]
cd $root
open_project [file join $root square_navigation.gprj] -pn GW5AT-LV60PG484AC1/I0 -device_version B
set_option -top_module square_nav_top
set_option -output_base_name square_navigation
set_option -use_sspi_as_gpio 1
set_option -place_option 1
set_option -route_option 1
set_option -timing_driven 1
run all
set build_name square_navigation
source [file join $root pillar_nav timing_check.tcl]
exit
