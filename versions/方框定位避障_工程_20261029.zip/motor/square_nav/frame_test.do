onerror {quit -code 1 -f}
set lib [file normalize square_nav/frame_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/n10_sincos.v pillar_nav/nav_math.v square_nav/square_project.v square_nav/square_frame_fit.v square_nav/frame_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib square_frame_tb
run -all
if {[examine -radix unsigned /square_frame_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
