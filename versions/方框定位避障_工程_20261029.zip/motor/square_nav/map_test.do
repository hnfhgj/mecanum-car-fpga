onerror {quit -code 1 -f}
set lib [file normalize square_nav/map_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/n10_sincos.v pillar_nav/nav_math.v square_nav/square_project.v square_nav/square_map.v square_nav/map_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib square_map_tb
run -all
if {[examine -radix unsigned /square_map_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
