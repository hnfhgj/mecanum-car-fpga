onerror {quit -code 1 -f}
set lib [file normalize square_nav/top_work]
if {![file isdirectory $lib]} {vlib $lib}
eval vlog -sv -work $lib [glob src/*.v] [glob pillar_nav/*.v] [glob square_nav/*.v]
vsim -voptargs=+acc -gUSE_EXTERNAL_OSC=1 -lib $lib square_nav_top
force -freeze /square_nav_top/clk 0 0ns,1 10ns -repeat 20ns
force -freeze /square_nav_top/rst_n 0
force -freeze /square_nav_top/key_n 1111
run 100ns
force -freeze /square_nav_top/rst_n 1
run 1000ns
foreach pin {lf_pwm rf_pwm lb_pwm rb_pwm} {
 if {[examine -radix unsigned /square_nav_top/$pin] != 0} {error "Unexpected boot motor output"}
}
puts "PASS square navigation top elaborates; all boot motor outputs zero"
quit -code 0 -f
