`timescale 1ns/1ps
module square_route_tb;
 reg clk=0,rst_n=0,cancel=0,we=0,free=0,start=0;
 reg [5:0] addr=0,origin=9,goal=14;
 wire busy,done,found,rejected;wire [1:0] direction;
 integer i,j,cycles;integer passed=0;
 always #10 clk=~clk;
 square_grid_route #(.SIDE_BITS(3)) dut(clk,rst_n,cancel,we,addr,free,start,origin,goal,
  busy,done,found,direction,rejected,1'b0,);
 task write_cell(input integer a,input integer v);begin
  @(negedge clk);we=1;addr=a;free=v;@(negedge clk);we=0;
 end endtask
 task run_route;begin
  @(negedge clk);start=1;@(negedge clk);start=0;
  cycles=0;while(!done && cycles<1000)begin @(negedge clk);cycles=cycles+1;end
  if(!done)$fatal(1,"BFS timeout");
 end endtask
 initial begin
  #51;rst_n=1;
  for(i=0;i<64;i=i+1)write_cell(i, (i%8>0 && i%8<7 && i/8>0 && i/8<7));
  run_route();if(!found || direction!=0)$fatal(1,"Direct +X route failed");
  // Vertical barrier forces +Y first; only gap is at row 5.
  for(j=1;j<5;j=j+1)write_cell(j*8+2,0);
  run_route();if(!found || direction!=1)$fatal(1,"Detour failed");
  write_cell(5*8+2,0);write_cell(6*8+2,0);
  run_route();if(found)$fatal(1,"Closed barrier accepted");
  write_cell(9,0);run_route();if(found)$fatal(1,"Blocked origin accepted");
  write_cell(9,1);write_cell(14,0);run_route();if(found)$fatal(1,"Blocked goal accepted");
  origin=9;goal=9;run_route();if(!found)$fatal(1,"Same cell failed");
  @(negedge clk);goal=14;start=1;@(negedge clk);start=0;
  write_cell(14,1);if(!rejected)$fatal(1,"Busy map mutation accepted");
  cancel=1;@(negedge clk);cancel=0;@(negedge clk);
  if(busy || found)$fatal(1,"Cancel failed");
  passed=1;$display("PASS: square BFS direct/detour/blocked/zero-step/cancel/map ownership");$finish;
 end
endmodule
