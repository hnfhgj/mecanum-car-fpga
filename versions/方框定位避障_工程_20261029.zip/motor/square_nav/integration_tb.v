`timescale 1ns/1ps
module square_integration_tb;
 reg clk=0,rst_n=0,cal=0,pv=0,owned=0;
 reg signed [15:0] f=0,l=0;reg [15:0] angle=0,range_mm=0;
 wire signed [15:0] read_f,read_l,x,y,yaw,correction;
 wire [8:0] ra;wire [9:0] count;
 wire ready,update,ok,calibrated,mb,md,mv,nearby,we,free;
 wire [15:0] width,height,quality;wire [11:0] wa;
 wire pb,pd,found,rejected,goal_reached;wire [1:0] direction;
 wire [11:0] origin=((y/50)<<6)+(x/50);
 integer passed=0,fd,i,j,ret,af,al,aa,ar,cycles;
 always #10 clk=~clk;
 always @(posedge clk)if(!rst_n || md)owned<=0;else if(ready)owned<=1;
 square_frame_fit fit(clk,rst_n,1'b0,cal,pv,f,l,angle,range_mm,16'sd0,md,ra,
  read_f,read_l,count,ready,update,ok,calibrated,x,y,yaw,correction,width,height,quality);
 square_map map(clk,rst_n,1'b0,ready&&!owned,count,read_f,read_l,ra,x,y,yaw,width,height,
  mb,md,mv,nearby,we,wa,free);
 square_grid_route #(.EXPLORE(1)) planner(clk,rst_n,1'b0,we,wa,free,md&&mv,origin,12'd1300,
  pb,pd,found,direction,rejected,cal,goal_reached);
 initial begin
  #51;rst_n=1;@(negedge clk);cal=1;@(negedge clk);cal=0;
  for(j=0;j<3;j=j+1)begin
   fd=$fopen("square_nav/frame_fixture.txt","r");
   for(i=0;i<450;i=i+1)begin
    ret=$fscanf(fd,"%d %d %d %d\n",af,al,aa,ar);if(ret!=4)$fatal(1,"Fixture");
    @(negedge clk);f=af;l=al;angle=aa;range_mm=ar;pv=1;@(negedge clk);pv=0;
   end
   $fclose(fd);
  end
  cycles=0;while(!pd && cycles<9000000)begin @(negedge clk);cycles=cycles+1;end
  if(!pd || !found || !goal_reached || !ok || !calibrated || !mv || nearby || rejected)
   $fatal(1,"Frame/map/planner integration failed");
  if(direction>1)$fatal(1,"Empty goal route goes wrong way");
  passed=1;$display("PASS: full frame + retained synchronous scan + map + BFS integration");$finish;
 end
endmodule
