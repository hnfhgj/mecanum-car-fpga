onerror {quit -code 1 -f}
set lib [file normalize square_nav/renderer_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib src/tft180_font.v square_nav/square_renderer.v square_nav/renderer_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib square_renderer_tb
run -all
if {[examine -radix unsigned /square_renderer_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
