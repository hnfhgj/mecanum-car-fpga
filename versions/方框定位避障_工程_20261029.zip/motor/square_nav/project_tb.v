`timescale 1ns/1ps
module square_project_tb;
 reg clk=0,rst_n=0,cancel=0,start=0;reg signed [15:0] f,l,angle;
 wire busy,done;wire signed [15:0] x,y;integer passed=0,case_id,cycles;
 integer fx,lx,ang,expected_x,expected_y;real a;
 always #10 clk=~clk;
 square_project dut(clk,rst_n,cancel,start,f,l,angle,busy,done,x,y);
 initial begin
  #51;rst_n=1;
  for(case_id=0;case_id<121;case_id=case_id+1)begin
   fx=(case_id*107)%6001-3000;lx=(case_id*293)%6001-3000;ang=(case_id*317)%36000-18000;
   // RTL lookup table is at 0.5-degree steps; compare independent real trig.
   a=$itor($rtoi($floor(($itor(ang)+36000.0+25.0)/50.0))%720)*0.5*3.141592653589793/180;
   expected_x=$rtoi(-fx*$sin(a)-lx*$cos(a));expected_y=$rtoi(fx*$cos(a)-lx*$sin(a));
   @(negedge clk);f=fx;l=lx;angle=ang;start=1;@(negedge clk);start=0;
   cycles=0;while(!done && cycles<300)begin @(negedge clk);cycles=cycles+1;end
   if(!done || x-expected_x>3 || x-expected_x< -3 || y-expected_y>3 || y-expected_y< -3)
    $fatal(1,"Projection mismatch case %d x/y %d %d expected %d %d",case_id,x,y,expected_x,expected_y);
   @(negedge clk);
  end
  passed=1;$display("PASS: square world projection 121 independent trig cases");$finish;
 end
endmodule
