"""Independent ray-cast scenes. Synthetic data, never a live vehicle test."""
import math
import random
from pathlib import Path
from reference import calibrate, plan, mecanum, NotReady, CELL, RADIUS, MARGIN


def scene(position=(900, 700), yaw=90, boxes=(), missing=(), noise=2):
    rng = random.Random(20261028)
    lines = [((0,0),(2000,0)), ((2000,0),(2000,2000)),
             ((2000,2000),(0,2000)), ((0,2000),(0,0))]
    lines = [v for i,v in enumerate(lines) if i not in missing]
    for x0,y0,x1,y1 in boxes:
        lines += [((x0,y0),(x1,y0)), ((x1,y0),(x1,y1)),
                  ((x1,y1),(x0,y1)), ((x0,y1),(x0,y0))]
    result=[]
    for i in range(900):
        a=math.radians(i*.4+yaw); dx,dy=math.cos(a),math.sin(a)
        distances=[]
        for (x0,y0),(x1,y1) in lines:
            if x0==x1 and abs(dx)>1e-8:
                t=(x0-position[0])/dx; hit=position[1]+t*dy
                if t>0 and min(y0,y1)-1e-5<=hit<=max(y0,y1)+1e-5: distances.append(t)
            if y0==y1 and abs(dy)>1e-8:
                t=(y0-position[1])/dy; hit=position[0]+t*dx
                if t>0 and min(x0,x1)-1e-5<=hit<=max(x0,x1)+1e-5: distances.append(t)
        if distances:
            r=min(distances)+rng.uniform(-noise,noise)
            local=math.radians(i*.4)
            result.append((r*math.cos(local),r*math.sin(local)))
    return result


def tests():
    for yaw in (73, 83, 90, 97, 108):
        frame=calibrate(scene(yaw=yaw))
        assert abs(frame.width-2000)<20 and abs(frame.height-2000)<20, frame
        assert abs(frame.x-900)<20 and abs(frame.y-700)<20, frame
        assert abs(math.degrees(frame.correction)-(yaw-90))<1, frame
    print('PASS: four-wall calibration, heading corrections -17..+18 deg')
    frame=calibrate(scene())
    for x,y,yaw in ((950,750,93),(1100,900,88),(1250,1000,90)):
        world, heading=frame.localize(scene((x,y),yaw), math.radians(yaw-90))
        assert abs(frame.x-x)<25 and abs(frame.y-y)<25, frame
    print('PASS: moving localization with independent IMU yaw')
    try: calibrate(scene(missing=(2,)))
    except NotReady: pass
    else: raise AssertionError('three walls accepted as complete frame')
    print('PASS: missing wall prevents calibration')
    frame=calibrate(scene())
    world,_=frame.localize(scene())
    route,reached,allowed,occupied=plan(frame,world,(1400,1400))
    assert reached and len(route)>5
    print('PASS: unobstructed target reached in observed free space')
    try: plan(frame,world,(100,100))
    except NotReady: pass
    else: raise AssertionError('goal outside footprint margin accepted')
    print('PASS: boundary clearance rejects unsafe goal')
    # Obstacle in front of the robot; preserve an unobstructed lateral route.
    box=(950,1050,1050,1150)
    frame=calibrate(scene((1000,500),boxes=(box,)))
    world,_=frame.localize(scene((1000,500),boxes=(box,)))
    route,reached,allowed,occupied=plan(frame,world,(1000,1600))
    assert max(abs(x-1000) for x,y in route)>RADIUS+MARGIN, route
    assert all((math.floor(x/CELL),math.floor(y/CELL)) in allowed for x,y in route)
    print('PASS: obstacle causes lateral detour; hidden cells stay blocked')
    # Execute a receding-horizon reference walk, rebuilding the observed map
    # from freshly ray-cast scans at each short step, never unseen shortcuts.
    trace=[(1000,500)]; pos=trace[0]; success=False
    for step in range(100):
        world,_=frame.localize(scene(pos,boxes=(box,)))
        route,reached,_,_=plan(frame,world,(1000,1600))
        if math.dist(pos,(1000,1600))<75: success=True;break
        pos=route[min(2,len(route)-1)];trace.append(pos)
    assert success,trace
    assert all(math.hypot(max(box[0]-x,0,x-box[2]),max(box[1]-y,0,y-box[3]))>=RADIUS+MARGIN for x,y in trace)
    print('PASS: receding-horizon detour reaches goal with fixed 90 deg heading')
    frame=calibrate(scene((1000,500)))
    # Wall occlusion must stop localization, not be relabelled as a new frame.
    try: frame.localize(scene((1000,500),boxes=((0,950,2000,1050),)))
    except NotReady: pass
    else: raise AssertionError('occluded learned boundary accepted')
    print('PASS: full-width blockage loses fix and stops')
    wheels=mecanum(100,0,math.pi/2,0)
    assert all(abs(a-b)<1e-6 for a,b in zip(wheels,(100,-100,-100,100)))
    print('PASS: +X strafe uses X-mecanum mixing without heading change')
    render(trace,box)


def render(trace,box):
    from PIL import Image,ImageDraw
    im=Image.new('RGB',(680,720),'white');d=ImageDraw.Draw(im)
    def p(q): return (40+q[0]*.3,650-q[1]*.3)
    d.rectangle([p((0,2000)),p((2000,0))],outline='black',width=4)
    d.rectangle([p((box[0],box[3])),p((box[2],box[1]))],fill='#aa4444')
    clearance=RADIUS+MARGIN
    d.rounded_rectangle([p((box[0]-clearance,box[3]+clearance)),p((box[2]+clearance,box[1]-clearance))],radius=clearance*.3,outline='#cc8888',width=2)
    d.line([p(q) for q in trace],fill='#2277cc',width=4)
    for q in trace[::4]:
        x,y=p(q);d.line((x,y,x,y-18),fill='#228833',width=2)
    d.text((40,15),'SYNTHETIC OFFLINE REFERENCE: square frame, fixed +Y heading',fill='black')
    d.text((40,680),f'Blue: receding-horizon path. Red: obstacle. Outline: {clearance} mm clearance.',fill='black')
    im.save(Path(__file__).with_name('reference_detour.png'))


if __name__=='__main__': tests()
