`timescale 1ns/1ps
module square_drive_tb;
 reg clk=0,rst_n=0,cal=0,go=0,stop=0,calibrated=0,pu=0,ok=1;
 reg [2:0] page=5;reg signed [15:0] x=900,y=700,yaw=9000,turn=0;
 reg [15:0] tx=1200,ty=1200;reg signed [15:0] heading_error=0;
 reg rd=0,rf=1,rg=1;reg [1:0] direction=1;reg near_obstacle=0,heading_ready=1,fault=0;
 wire active,fresh,can_go;wire [3:0] status;wire signed [15:0] lf,rfr,lb,rb;
 integer passed=0;
 always #10 clk=~clk;
 square_drive #(.CLK_HZ(100000)) dut(clk,rst_n,cal,go,stop,page,calibrated,pu,ok,x,y,yaw,tx,ty,16'd2000,16'd2000,
  rd,rf,rg,direction,near_obstacle,heading_ready,fault,turn,heading_error,active,fresh,can_go,status,lf,rfr,lb,rb);
 task feed;begin @(negedge clk);pu=1;@(negedge clk);pu=0;repeat(200)@(negedge clk);end endtask
 task command;begin @(negedge clk);go=1;@(negedge clk);go=0;repeat(3)@(negedge clk);end endtask
 task route;begin @(negedge clk);rd=1;@(negedge clk);rd=0;repeat(200)@(negedge clk);end endtask
 task stopped;begin repeat(4)@(negedge clk);if(active || lf || rfr || lb || rb)$fatal(1,"Expected stopped outputs");end endtask
 initial begin
  #51;rst_n=1;command();stopped();calibrated=1;
  repeat(5)feed();if(!can_go)$fatal(1,"Not ready after stable pose");
  tx=250;
  @(negedge clk);if(can_go)$fatal(1,"Unsafe target accepted after settling");
  tx=300;@(negedge clk);if(!can_go)$fatal(1,"30cm target rejected for measured chassis");tx=1200;
  command();route();if(!active || lf!=60 || rfr!=60 || lb!=60 || rb!=60)$fatal(1,"+Y forward mix failed %d %d %d %d",lf,rfr,lb,rb);
  direction=0;route();if(lf!=60 || rfr!= -60 || lb!= -60 || rb!=60)$fatal(1,"+X strafe failed");
  yaw=9700;feed();route();
  if(lf<49 || lf>55 || rfr< -70 || rfr> -64 || lb!=rfr || rb!=lf)$fatal(1,"World/body yaw projection failed");
  yaw=9000;feed();route();
  turn=20;repeat(4)@(negedge clk);if(lf!=40 || rfr!=-40 || lb!=-80 || rb!=80)$fatal(1,"Heading superposition failed");
  heading_error=700;repeat(4)@(negedge clk);if(lf!=-20 || rfr!=20 || lb!=-20 || rb!=20)$fatal(1,"Initial heading alignment failed");
  heading_error=0;
  near_obstacle=1;stopped();near_obstacle=0;turn=0;repeat(4)feed();command();route();
  rf=0;route();stopped();rf=1;repeat(4)feed();command();route();
  ok=0;feed();stopped();ok=1;repeat(4)feed();command();route();
  stop=1;@(negedge clk);stop=0;stopped();repeat(4)feed();command();route();
  page=0;stopped();page=5;repeat(4)feed();command();route();
  x=tx;y=ty;repeat(3)feed();stopped();if(status!=5)$fatal(1,"Arrival status missing");
  // Freshness expiry must stop even if the route reports a valid old path.
  x=900;y=700;repeat(4)feed();command();route();repeat(34000)@(negedge clk);stopped();
  passed=1;$display("PASS: square drive +Y/+X/heading/near/blocked/bad/stop/page/arrival/stale");$finish;
 end
endmodule

module square_ui_tb;
 reg clk=0,rst_n=0,active=0,calibrated=1;reg [3:0] keys=15;
 wire [2:0] page;wire menu;wire [3:0] cursor,gain;
 wire [15:0] tx,ty;wire cal,go,stop;wire [31:0] kp,kd;
 integer passed=0,ncal=0,ngo=0,nstop=0;
 always #10 clk=~clk;
 square_ui #(.CLK_HZ(10000)) dut(clk,rst_n,keys,active,calibrated,16'd2000,16'd2000,
  page,menu,cursor,tx,ty,cal,go,stop,gain,kp,kd);
 always @(posedge clk)begin if(cal)ncal=ncal+1;if(go)ngo=ngo+1;if(stop)nstop=nstop+1;end
 task key(input integer index);begin
  @(negedge clk);keys[index]=0;repeat(250)@(negedge clk);keys[index]=1;repeat(250)@(negedge clk);
 end endtask
 initial begin
  #51;rst_n=1;repeat(10)@(negedge clk);
  if(page!=5 || !menu || cursor!=1)$fatal(1,"Wrong boot menu");
  key(2);if(ncal!=1)$fatal(1,"CAL button failed");
  key(1);key(2);if(cursor!=2 || tx!=1050)$fatal(1,"X +5cm failed");
  key(3);if(tx!=1000)$fatal(1,"X -5cm failed");
  key(1);key(2);if(cursor!=3 || ty!=1050)$fatal(1,"Y +5cm failed");
  key(1);key(2);if(ngo!=1)$fatal(1,"GO failed");
  active=1;key(3);if(nstop!=1)$fatal(1,"STOP failed");active=0;
  key(0);if(menu)$fatal(1,"MAP toggle failed");
  key(1);key(1);repeat(20)key(3);if(tx!=300)$fatal(1,"Measured-chassis lower target bound");
  repeat(35)key(2);if(tx!=1700)$fatal(1,"Measured-chassis upper target bound");
  keys[0]=0;repeat(8100)@(negedge clk);keys[0]=1;repeat(250)@(negedge clk);
  if(page!=0)$fatal(1,"Long page switch failed");
  passed=1;$display("PASS: square UI real debounced keys CAL/X/Y/GO/STOP/map/long-page");$finish;
 end
endmodule
