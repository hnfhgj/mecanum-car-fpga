onerror {quit -code 1 -f}
set lib [file normalize square_nav/route_work]
if {![file isdirectory $lib]} {vlib $lib}
vlog -sv -work $lib square_nav/square_grid_route.v square_nav/route_tb.v
vsim -onfinish stop -voptargs=+acc -lib $lib square_route_tb
run -all
if {[examine -radix unsigned /square_route_tb/passed] != 1} {quit -code 1 -f}
quit -code 0 -f
