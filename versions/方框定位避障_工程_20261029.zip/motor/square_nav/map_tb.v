`timescale 1ns/1ps
module square_map_tb;
 reg clk=0,rst_n=0,cancel=0,start=0;
 reg signed [15:0] f[0:511],l[0:511];wire [8:0] addr;
 wire busy,done,valid,nearby,we;wire [11:0] wa;wire free;
 reg grid[0:4095];reg seen[0:4095];
 integer passed=0,fd,ret,i,j,k,af,al,aa,ar,cycles,writes,mode;
 always #10 clk=~clk;
 square_map dut(clk,rst_n,cancel,start,10'd450,f[addr],l[addr],addr,
  16'sd1000,16'sd500,16'sd9000,16'd2000,16'd2000,busy,done,valid,nearby,we,wa,free);
 always @(posedge clk)if(we)begin grid[wa]<=free;seen[wa]<=1;writes=writes+1;end
 task run_map;begin
  for(k=0;k<4096;k=k+1)seen[k]=0;writes=0;
  @(negedge clk);start=1;@(negedge clk);start=0;
  cycles=0;while(!done && cycles<2000000)begin @(negedge clk);cycles=cycles+1;end
  if(!done || !valid || nearby || writes!=4096)$fatal(1,"Map commit failed %d",writes);
  for(k=0;k<4096;k=k+1)if(!seen[k])$fatal(1,"Partial map");
 end endtask
 initial begin
  #51;rst_n=1;
  for(mode=0;mode<2;mode=mode+1)begin
   fd=$fopen(mode==0?"square_nav/map_empty.txt":"square_nav/map_obstacle.txt","r");
   if(!fd)$fatal(1,"Missing fixture");
   for(i=0;i<450;i=i+1)begin ret=$fscanf(fd,"%d %d\n",af,al);if(ret!=2)$fatal(1,"Fixture error");f[i]=af;l[i]=al;end
   $fclose(fd);run_map();
   for(j=0;j<64;j=j+1)for(i=0;i<64;i=i+1)begin
    if((i*50+25<270 || j*50+25<270 || i*50+25+270>2000 || j*50+25+270>2000) && grid[j*64+i])
     $fatal(1,"Boundary footprint accepted");
    if(mode==1 && (i*50+25-1000)*(i*50+25-1000)+(j*50+25-1100)*(j*50+25-1100)<270*270 && grid[j*64+i])
     $fatal(1,"Obstacle inflation missing");
   end
   if(!grid[10*64+20])$fatal(1,"Robot start not observed free");
   if(mode==0 && !grid[5*64+20])$fatal(1,"Measured chassis should fit 275mm from wall");
   if(mode==0 && !grid[30*64+20])$fatal(1,"Empty goal not free");
   if(mode==1 && grid[30*64+20])$fatal(1,"Unobserved obstacle shadow accepted");
  end
  @(negedge clk);cancel=1;@(negedge clk);cancel=0;@(negedge clk);if(valid)$fatal(1,"Cancelled map stayed valid");
  passed=1;$display("PASS: square map 8192 writes, boundary/inflation/unknown shadow/cancel");$finish;
 end
endmodule
