`timescale 1ns/1ps
// Real 50MHz clock / approximately 10Hz scan cadence. Stationary synthetic
// scene: tests ownership, continuous pose/map refresh and controller freshness,
// not physical motion or raw UART decoding.
module square_cadence_tb;
 reg clk=0,rst_n=0,cal=0,pv=0,owned=0,go=0,started=0;
 reg signed [15:0] f=0,l=0;reg [15:0] angle=0,range_mm=0;
 wire signed [15:0] read_f,read_l,x,y,yaw,correction;
 wire [8:0] ra;wire [9:0] count;
 wire ready,update,ok,calibrated,mb,md,mv,nearby,we,free;
 wire [15:0] width,height,quality;wire [11:0] wa;
 wire pb,pd,found,rejected,goal_reached;wire [1:0] direction;
 wire [11:0] origin=((y/50)<<6)+(x/50);
 wire active,fresh,can_go;wire [3:0] status;
 wire signed [15:0] lf,rf,lb,rb;
 integer passed=0,fd,i,j,ret,af,al,aa,ar,fixes=0,plans=0,age=0;
 always #10 clk=~clk;
 always @(posedge clk)begin
  if(!rst_n || md)owned<=0;else if(ready)owned<=1;
  go<=rst_n && can_go && !started;
  if(go)started<=1;
  if(rst_n && update && ok)begin
   if(fixes>0 && age>16666666)$fatal(1,"Pose cadence exceeds freshness limit");
   fixes=fixes+1;age=0;
  end else if(fixes>0)age=age+1;
  if(pd)begin plans=plans+1;if(!found || rejected)$fatal(1,"Continuous plan lost");end
  if(started && !active && !go)$fatal(1,"Controller stopped at real scan cadence status=%d",status);
 end
 square_frame_fit fit(clk,rst_n,1'b0,cal,pv,f,l,angle,range_mm,16'sd0,md,ra,
  read_f,read_l,count,ready,update,ok,calibrated,x,y,yaw,correction,width,height,quality);
 square_map map(clk,rst_n,1'b0,ready&&!owned,count,read_f,read_l,ra,x,y,yaw,width,height,
  mb,md,mv,nearby,we,wa,free);
 square_grid_route #(.EXPLORE(1)) planner(clk,rst_n,go,we,wa,free,md&&mv,origin,12'd1820,
  pb,pd,found,direction,rejected,go,goal_reached);
 square_drive drive(clk,rst_n,cal,go,1'b0,3'd5,calibrated,update,ok,x,y,yaw,
  16'd1400,16'd1400,width,height,pd,found,goal_reached,direction,nearby,1'b1,1'b0,
  16'sd0,16'sd0,active,fresh,can_go,status,lf,rf,lb,rb);
 initial begin
  #51;rst_n=1;@(negedge clk);cal=1;@(negedge clk);cal=0;
  for(j=0;j<16;j=j+1)begin
   fd=$fopen("square_nav/frame_fixture.txt","r");
   for(i=0;i<450;i=i+1)begin
    ret=$fscanf(fd,"%d %d %d %d\n",af,al,aa,ar);if(ret!=4)$fatal(1,"Fixture");
    @(negedge clk);f=af;l=al;angle=aa;range_mm=ar;pv=1;@(negedge clk);pv=0;
    repeat(11109)@(negedge clk);
   end
   $fclose(fd);
  end
  if(fixes<5 || plans<5 || !active || !fresh || !(lf || rf || lb || rb))$fatal(1,"Insufficient continuous refresh");
  passed=1;$display("PASS: 10Hz scan cadence localization/map/planner/drive freshness fixes=%d plans=%d",fixes,plans);$finish;
 end
endmodule
