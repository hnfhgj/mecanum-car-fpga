`timescale 1ns/1ps
module square_renderer_tb;
 reg clk=0,rst_n=0,frame_start=0;reg [7:0] x=0;reg [6:0] y=0;
 wire [15:0] pixel;integer passed=0,fd,i,j;
 always #10 clk=~clk;
 square_renderer dut(.clk(clk),.rst_n(rst_n),.frame_start(frame_start),.pixel_x(x),.pixel_y(y),.raw_pixel(16'd0),
  .menu_view(1'b1),.cursor(4'd2),.status(4'd3),.aligned(1'b1),.can_go(1'b1),.learn_ok(1'b1),.template_valid(1'b1),.ambiguous(1'b0),
  .live_count(4'd3),.frozen_count(4'd3),.o_id(4'd0),.x_id(4'd1),.y_id(4'd2),.live_xs(192'd0),.live_ys(192'd0),
  .frozen_xs(192'd0),.frozen_ys(192'd0),.pose_x(16'sd1200),.pose_y(16'sd800),.target_x(16'd1000),.target_y(16'd950),
  .width_mm(16'd2000),.height_mm(16'd1900),.diameter_mm(16'd100),.quality(16'd2),.pixel(pixel));
 initial begin
  #51;rst_n=1;@(negedge clk);frame_start=1;@(negedge clk);frame_start=0;
  repeat(200)@(negedge clk);
  fd=$fopen("square_nav/menu_rgb565.hex","w");
  for(j=0;j<128;j=j+1)for(i=0;i<160;i=i+1)begin
   x=i;y=j;repeat(2)@(negedge clk);$fwrite(fd,"%04x\n",pixel);
   if(i==0 && j%8==0)$display("ROW %d %s",j/8,dut.line);
  end
  $fclose(fd);passed=1;$display("PASS square menu renderer snapshot and RGB565 frame generated");$finish;
 end
endmodule
