`timescale 1ns/1ps
// Closed map/planner loop; independent ray caster, ideal 50mm grid plant.
module square_detour_tb;
 reg clk=0,rst_n=0,start=0,new_goal=0,cancel=0;
 reg signed [15:0] f[0:511],l[0:511];wire [8:0] ra;
 reg signed [15:0] robot_x=1025,robot_y=525;
 wire mb,md,mv,nearby,we;wire [11:0] wa;wire free;
 wire pb,pd,found,rejected,goal_reached;wire [1:0] direction;
 wire [11:0] origin=((robot_y/50)<<6)+(robot_x/50);
 reg allowed[0:4095];
 integer passed=0,i,j,steps,cycles,next_x,next_y,visited=0,fd;
 real angle,dx,dy,distance,hit,t,rx,ry;
 always #10 clk=~clk;
 square_map map(clk,rst_n,cancel,start,10'd450,f[ra],l[ra],ra,robot_x,robot_y,16'sd9000,16'd2000,16'd2000,
  mb,md,mv,nearby,we,wa,free);
 square_grid_route #(.EXPLORE(1)) route(clk,rst_n,cancel,we,wa,free,md&&mv,origin,12'd2068,
  pb,pd,found,direction,rejected,new_goal,goal_reached);
 // goal_cell=32*64+20 = (1025,1625), behind the obstacle.
 always @(posedge clk)if(we)allowed[wa]<=free;
 task vertical(input real x,input real low,input real high);begin
  if((dx<0?-dx:dx)>0.000001)begin t=(x-robot_x)/dx;hit=robot_y+t*dy;
   if(t>0 && hit>=low && hit<=high && t<distance)distance=t;
  end
 end endtask
 task horizontal(input real y,input real low,input real high);begin
  if((dy<0?-dy:dy)>0.000001)begin t=(y-robot_y)/dy;hit=robot_x+t*dx;
   if(t>0 && hit>=low && hit<=high && t<distance)distance=t;
  end
 end endtask
 task scan;begin
  for(i=0;i<450;i=i+1)begin
   angle=i*0.8*3.141592653589793/180;
   // Native angle CCW; f=world +Y, l=world -X.
   dx=-$sin(angle);dy=$cos(angle);distance=10000;
   vertical(0,0,2000);vertical(2000,0,2000);horizontal(0,0,2000);horizontal(2000,0,2000);
   vertical(950,1050,1150);vertical(1050,1050,1150);horizontal(1050,950,1050);horizontal(1150,950,1050);
   f[i]=$rtoi(distance*$cos(angle));l[i]=$rtoi(distance*$sin(angle));
  end
 end endtask
 initial begin
  #51;rst_n=1;new_goal=1;@(negedge clk);new_goal=0;
  fd=$fopen("square_nav/rtl_detour_trace.txt","w");
  for(steps=0;steps<100;steps=steps+1)begin
   $fdisplay(fd,"%d %d",robot_x,robot_y);
   if(robot_x==1025 && robot_y==1625)begin
    $fclose(fd);passed=1;$display("PASS: square map + BFS closed loop detour in %d 50mm steps; fixed +Y heading",steps);$finish;
   end
   scan();@(negedge clk);start=1;@(negedge clk);start=0;
   cycles=0;while(!pd && cycles<1700000)begin @(negedge clk);cycles=cycles+1;end
   if(!pd || !found || nearby || rejected)$fatal(1,"No safe detour step %d xy %d %d",steps,robot_x,robot_y);
   next_x=robot_x;next_y=robot_y;
   case(direction)0:next_x=next_x+50;1:next_y=next_y+50;2:next_x=next_x-50;3:next_y=next_y-50;endcase
   if(!allowed[(next_y/50)*64+(next_x/50)])$fatal(1,"Planner entered unknown/blocked cell");
   if(next_x<270 || next_y<270 || next_x>1730 || next_y>1730)$fatal(1,"Boundary crossed");
   rx=next_x<950?950-next_x:(next_x>1050?next_x-1050:0);
   ry=next_y<1050?1050-next_y:(next_y>1150?next_y-1150:0);
   if(rx*rx+ry*ry<270*270)$fatal(1,"Footprint collision");
   robot_x=next_x;robot_y=next_y;repeat(3)@(negedge clk);
  end
  $fclose(fd);$fatal(1,"No arrival within bounded exploration budget");
 end
endmodule
